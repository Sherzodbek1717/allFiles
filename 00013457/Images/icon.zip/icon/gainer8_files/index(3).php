@font-face {
    font-family: Cutest;
    src: url(/templates/lifesport/fonts/cutest-light.woff2) format("woff2"),url(/templates/lifesport/fonts/cutest-light.woff) format("woff");
    font-weight: 300;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Cutest;
    src: url(/templates/lifesport/fonts/cutest-regular.woff2) format("woff2"),url(/templates/lifesport/fonts/cutest-regular.woff) format("woff");
    font-weight: 400;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Cutest;
    src: url(/templates/lifesport/fonts/cutest-regular.woff2) format("woff2"),url(/templates/lifesport/fonts/cutest-regular.woff) format("woff");
    font-weight: 500;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Cutest;
    src: url(/templates/lifesport/fonts/cutest-semibold.woff2) format("woff2"),url(/templates/lifesport/fonts/cutest-semibold.woff) format("woff");
    font-weight: 700;
    font-style: normal;
    font-display: swap
}



:root {
	--color-primary-p3: #000;
	--color-primary-p3-light: #0078ac;
	--color-primary-p3-dark:  #000;
	--color-primary-text-p3: #0080ff
}


html,
body {
	height: 100%;
	-webkit-text-size-adjust: 100%;
	background-color: #fdfdfd;
	font-family: "Cutest", sans-serif;
}

* {font-family: "Cutest", sans-serif; }


body.overflow-hidden {
	overflow: hidden;
	height: 100%;
	padding-right: 16px;
}


html,
body,
div,
span,
object,
iframe,
h1,
h2,
h3,
h4,
h5,
h6,
p,
blockquote,
pre abbr,
address,
cite,
code,
del,
dfn,
em,
img,
ins,
kbd,
q,
samp,
sub,
sup,
var,
dl,
dt,
dd,
ol,
ul,
li,
fieldset,
form,
label,
legend,
table,
caption,
tbody,
tfoot,
thead,
tr,
th,
td {
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	font: inherit;
}

article,
aside,
details,
figcaption,
figure,
footer,
header,
hgroup,
menu,
nav,
section,
main {
	display: block;
}

img,
fieldset {
	border: none;
}

a,
a:visited {
	text-decoration: none;
}

a:hover,
a:active {
	outline: none;
}


a img {
	border: 0em;
	vertical-align: middle;
}

legend,
caption {
	display: none;
}

abbr,
acronym {
	cursor: help;
	border-bottom: 1px dotted  var(--color-primary-p3-dark);
}

table {
	border-collapse: collapse;
	border-spacing: 0;
}

th,
td {
	text-align: left;
}

address {
	display: block;
	font-style: normal;
}

blockquote,
q {
	quotes: none;
}

blockquote:before,
blockquote:after,
q:before,
q:after {
	content: '';
	content: none;
}

input.submit,
.cpointer {
	cursor: pointer;
}

 :focus {
	outline: 0;
}

a:hover {
	cursor: pointer;
}

ins {
	text-decoration: none;
}

del {
	text-decoration: line-through;
}

textarea {
	resize: none;
}

body {
	font-size: 100%;
	line-height: 18px;
}

input,
textarea,
select,
option,
optgroup,
button {
	font-size: 1em;
	vertical-align: middle;
	margin: 0px;
}



pre {
	white-space: pre;
	white-space: pre-wrap;
	word-wrap: break-word;
	padding: 15px;
	background: #fafafa;
	border: 1px solid #ccc;
}

sub,
sup {
	font-size: 75%;
	line-height: 0;
	position: relative;
	vertical-align: baseline;
}

sup {
	top: -0.5em;
}

sub {
	bottom: -0.25em;
}




		
	* {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box
}

*:before,
*:after {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box
}







body,
button,
input,
optgroup,
option,
select,
textarea {
	
}

body {
	color: #3f4c52;
}



.headroom {display: none;}




.wrapper {
    max-width: 1066px;
    min-width: 320px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    padding-left: 16px;
    padding-right: 16px;
}



.jZapKD {
    display: none;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    -webkit-tap-highlight-color: transparent;
}




.lghidenmenu {
    display: none;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    -webkit-tap-highlight-color: transparent;
}



.svg1:hover svg, .svg1:hover .iQUpZw {fill:#d7f0f0;color: #719dc1;}
.svg2:hover svg, .svg2:hover .iQUpZw {fill:#c8e6ff;color:#719dc1;}
.svg3:hover svg, .svg3:hover .iQUpZw {fill:#ffd1de;color:#e0a1b3;}
.svg4:hover svg, .svg4:hover .iQUpZw {fill:#f0e6d7;color:#bc975b;}
.svg5:hover svg, .svg5:hover .iQUpZw {fill:#e1d7f0;color:#b69fd8;}
.svg6:hover svg, .svg6:hover .iQUpZw {fill:#f0e1d7;color:#bc967d;}
.svg7:hover svg, .svg7:hover .iQUpZw {fill:#d0d8fa;color:#94a2de;}
.svg8:hover svg, .svg8:hover .iQUpZw {fill:#d7e6f0;color:#548db3;}
.svg9:hover svg, .svg9:hover .iQUpZw {fill:#f0d7d7;color:#bc6666;}
.svg10:hover svg, .svg10:hover .iQUpZw {fill:#f4b4ff;color:#f4b4ff;}









@media screen and (max-width:868px) {
	.wrapper {
	max-width: 766px;
    min-width: 320px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    padding-left: 16px;
    padding-right: 16px;
	}

}




#footer-container {
    width: 1066px;
    padding: 0 32px;
    margin: 0 auto;
    position: relative;
    margin-top: 55px;
}


.footerbox {
	background: #fff;
	box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
	border-radius: 25px 25px 0px 0px;
	padding: 24px 16px 40px;
	}



@media screen and (max-width:868px) {
#footer-container {
	background: #fff;
	box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
}	
	
	
.footerbox {
    border-radius: 0px;
	box-shadow: none;
	padding: 0;
}

}


@media screen and (max-width:1063px) {


#footer-container {
	width: 768px;
	padding: 0 20px
}

}

@media screen and (max-width:868px) {

#footer-container {
   width: 100%;
   padding: 0 20px
}

}


.header__logo {width: 160px;}

.euzVCd:hover .header__logo {opacity: 0.8;}












.hamburger {
	font: inherit;
	display: none;
	overflow: visible;
	margin: 0;
	cursor: pointer;
	transition-timing-function: linear;
	transition-duration: .15s;
	transition-property: opacity, filter;
	text-transform: none;
	color: inherit;
	border: 0;
	background-color: transparent;
	padding: 15px 0 15px 15px;
	-webkit-tap-highlight-color: rgba(0, 0, 0, 0)
}

@media screen and (max-width:868px) {
	.hamburger {
		display: flex
	}
}

@media screen and (max-width:868px) {
	.hamburger_hidden {
		display: none
	}
}

.hamburger.is-active:hover,
.hamburger:hover {
	opacity: .7
}

.hamburger.is-active .hamburger-inner,
.hamburger.is-active .hamburger-inner:after,
.hamburger.is-active .hamburger-inner:before {
	background-color: #333
}

.hamburger.hamburger_white.is-active .hamburger-inner,
.hamburger.hamburger_white.is-active .hamburger-inner:after,
.hamburger.hamburger_white.is-active .hamburger-inner:before {
	background-color: #fff
}

.hamburger-box {
	position: relative;
	display: inline-block;
	width: 20px;
	height: 24px
}

.hamburger-inner {
	top: 50%;
	display: block;
	margin-top: -2px
}

.hamburger-inner,
.hamburger-inner:after,
.hamburger-inner:before {
	position: absolute;
	width: 20px;
	height: 2px;
	transition-timing-function: ease;
	transition-duration: .15s;
	transition-property: transform;
	border-radius: 4px;
	background-color: #333
}

.hamburger_white .hamburger-inner,
.hamburger_white .hamburger-inner:after,
.hamburger_white .hamburger-inner:before {
	background: #fff
}

.hamburger-inner:after,
.hamburger-inner:before {
	display: block;
	content: ""
}

.hamburger-inner:before {
	top: -6px
}

.hamburger-inner:after {
	bottom: -6px
}

.hamburger--3dx .hamburger-box {
	perspective: 80px
}

.hamburger--squeeze .hamburger-inner {
	transition-timing-function: cubic-bezier(.55, .055, .675, .19);
	transition-duration: 75ms
}

.hamburger--squeeze .hamburger-inner:before {
	transition: top 75ms ease .12s, opacity 75ms ease
}

.hamburger--squeeze .hamburger-inner:after {
	transition: bottom 75ms ease .12s, transform 75ms cubic-bezier(.55, .055, .675, .19)
}

.hamburger--squeeze.is-active .hamburger-inner {
	transition-delay: .12s;
	transition-timing-function: cubic-bezier(.215, .61, .355, 1);
	transform: rotate(45deg)
}

.hamburger--squeeze.is-active .hamburger-inner:before {
	top: 0;
	transition: top 75ms ease, opacity 75ms ease .12s;
	opacity: 0
}

.hamburger--squeeze.is-active .hamburger-inner:after {
	bottom: 0;
	transition: bottom 75ms ease, transform 75ms cubic-bezier(.215, .61, .355, 1) .12s;
	transform: rotate(-90deg)
}

.backdrop {
	position: fixed;
	height: 100vh;
	width: 100vw;
	background: #333;
	opacity: 0;
	z-index: -1;
	display: block;
	visibility: hidden;
	transition: .3s
}

@media screen and (max-width:868px) {
	.backdrop.opened {
		visibility: visible;
		opacity: .5
	}
}

.submenu {
	padding: 20px 16px 32px;
	background: #fff;
	border-radius: 0 0 16px 16px;
	display: flex;
	visibility: hidden;
	flex-direction: column;
	position: fixed;
	left: 0;
	transition: .3s;
	right: 0;
	top: 68px;
	transform: translateY(-100%)
}

@media screen and (max-width:868px) {
	.submenu.opened {
		visibility: visible;
		transform: translateY(0)
	}
}

.submenu__nameContainer {
	display: flex;
	flex-direction: column;
	align-items: flex-start;
	background: #f4f5f7;
	border-radius: 12px;
	padding: 12px 20px
}

.submenu__name {
	font-size: 16px;
	line-height: 18px;
	color: #333
}

.submenu__status {
	font-size: 13px;
	line-height: 18px
}

.submenu .t-header-link {
	margin: 20px 0 0;
	font-size: 16px;
	line-height: 16px
}

.submenu .t-header-link_first {
	margin-top: 0
}

.submenu .icon-lk-header {
	margin-right: 14px
}

header.mg-header-lk {
	z-index: 100;
	background: #fff
}










.header {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	height: 64px;
	background: #fff;
	z-index: 100000;
	transition: transform 0.5s cubic-bezier(0.8, 0.2, 0.2, 0.8);
}



.header.out {
  transform: translateY(-550%);
}



.mode-right .header {
	position: relative;
	top: 0;
	left: 0;
	right: 0;
	height: auto;
	background: #fff;
	z-index: 1;
	transition: transform 0.5s cubic-bezier(0.8, 0.2, 0.2, 0.8);
}

.mode-right .header.out {
    transform: none;
    transform: translateY(-40%);
}




@media screen and (max-width:1063px) {
.mode-right .header.out {
    transform: none;
    transform: translateY(0%);
}
}

@media screen and (max-width:868px) {
.mode-right .header.out {
    transform: none;
    transform: translateY(0%);
}
}














.header__submenuButton {
	font-size: 16px;
	color: #6d7885;
	transition: .3s;
	background: transparent;
	border: none;
	cursor: pointer;
	padding: 0;
	margin-left: 32px
}

.header__submenuButton:hover {
	color:  var(--color-primary-p3-dark);
	text-decoration: none
}

.header__submenuButton.is-active .header__dropdownArrow {
	transform: rotate(180deg)
}

.header__dropdownArrow {
	margin-left: 6px
}

.header__container {
	display: flex;
	flex-direction: row;
	justify-content: space-between;
}


.header__link {
	font-size: 16px;
	font-weight: 600;
	color:  var(--color-primary-p3-dark);
	transition: .3s;
	display: -ms-flexbox;
    display: flex;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-pack: center;
    justify-content: center;
    height: 100%;
    position: relative;
	padding: 0px 10px;
  -webkit-touch-callout: none; /* iOS Safari */
  -webkit-user-select: none;   /* Chrome/Safari/Opera */
  -khtml-user-select: none;    /* Konqueror */
  -moz-user-select: none;      /* Firefox */
  -ms-user-select: none;       /* Internet Explorer/Edge */
  user-select: none;           /* Non-prefixed version, currently
                                  not supported by any browser */ 
}



.header__link.select {
	background-color: #eff1fb;
	text-decoration: none
}






.header__link:hover {
	background-color: #aeb7c21f;
	text-decoration: none
}

.header__link:last-child {
	margin-right: 0
}

.header__link_desktopIn {
	margin-right: 0;
	cursor: pointer
}

.header__burger {
	display: none;
	align-items: center
}

@media screen and (max-width:1063px) {
	.header__burger {
		display: flex
	}
}

.header__desktopMenu {
	display: flex;
	flex-direction: row;
	align-items: center
}

@media screen and (max-width:1063px) {
	.header__desktopMenu {
		display: none
	}
}

.header__submenu {
	display: none;
	position: absolute;
	background: #fff;
	top: 64px;
	box-shadow: 0 5px 25px rgba(0, 0, 0, .15);
	border-radius: 0 0 15px 15px;
	width: 100%;
	transition: .3s;
	transform: translateY(-120%)
}

@media screen and (max-width:1063px) {
	.header__submenu {
		display: block;
		background: #fff
	}
}

.header__submenu.opened {
	transform: translateY(0)
}

.header__line {
	width: 100%;
	height: 100%;
	z-index: 100;
	border-bottom: 1px solid #e7e8ec
}

.header__line,
.header__menu {
	background: #fff;
	position: absolute;
	box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px;
	
}

.header__menu {
	top: 64px;
	box-shadow: 0 5px 25px rgba(0, 0, 0, .15);
	border-radius: 0 0 15px 15px;
	width: 373px;
	box-sizing: border-box;
	padding: 15px;
	right: 32px;
	display: flex;
	flex-direction: column;
	transition: .4s;
	transform: translateY(-170%)
}

@media screen and (max-width:1063px) {
	.header__menu {
		display: none
	}
}

.header__menu.opened {
	transform: translateY(0)
}

@media screen and (max-width:1063px) {
	.header__menu.opened {
		display: none
	}
}

.submenu__container {
	display: flex;
	flex-direction: column;
	padding-top: 30px;
	padding-bottom: 30px
}

.submenu__line {
	height: 28px;
	margin-top: 20px
}

.submenu__line:first-child {
	margin-top: 0
}

.submenu__profile {
	min-height: 70px;
	background: #f4f5f7;
	border-radius: 15px;
	padding: 15px
}

.submenu__ava {
	border-radius: 50%;
	height: 40px;
	width: 40px
}

.submenu__link {
	height: 28px;
	display: inline-flex;
	flex-direction: row;
	color: #222;
	font-size: 16px;
	font-weight: 400;
	align-items: center;
	cursor: pointer
}

.submenu__link img {
	margin-right: 13px
}






.header__container .headhover {display:none}
.header__container .noheadhover {display:block}
.header__container a:hover .noheadhover {display:none}
.header__container a:hover .headhover {display:block}




.pagination__pages {text-align: center;padding: 20px 0 0 0;}
.pagination {text-align: center; margin: 0 var(--indent-negative); padding: 20px var(--indent); padding-bottom: 0; 
	border-top: 1px solid var(--color-primary-p3-dark); box-shadow: inset 0 1px var(--color-primary-p3-dark);}
.pagination__btn-loader a, .pagination__btn-loader > span {display: inline-flex; justify-content: center; align-items: center; 
	height: 44px; padding: 0 40px; max-width: 400px; background: var(--color-primary-p3-dark); color: #fff; width: 100%;
	font-weight: 600; text-transform: uppercase; font-size: 12px; letter-spacing: 1px; 
	margin-bottom: 10px; border-radius: 3px; border: 1px solid var(--color-primary-p3-dark); box-shadow: inset 0 0 0 1px var(--color-primary-p3-dark);}
.pagination__pages a, .pagination__pages span {display: inline-block; margin: 10px 5px 0 5px; line-height: 38px; 
	padding: 0 10px; min-width: 40px; font-size: 16px; border: 1px solid var(--color-primary-p3-light); border-radius: 3px;}
.pagination__pages span:not(.nav_ext), .pagination__pages a:hover, .pagination__btn-loader a:hover  
{background: var(--color-primary-p3-dark);; color: #fff; border-color: var(--color-primary-p3-dark);}




h1,
h2,
h3,
h4,
h5,
h6 {
	color: #2B2B2B;
	font-weight: 400;
	padding: 0
}



h1 {
	font-size: 21px;
	font-weight: 700;
	line-height: 30px !important;
}



.cat-sortlist h1 {
		font-size: 28px;
		margin: 20px 0;
		font-weight: bold;
}



.cat-sortlist h1 {
	font-size: 22px;
	margin: 0 0 20px 0;
	font-weight: bold;
}

.cat-desc {    
	display: inline-block;
    width: 100%;
    word-wrap: break-word;}



.cat-desc h2 {
font-size: 20px;
margin: 20px 0;
font-weight: bold;
}

.cat-desc h3 {
font-size: 18px;
margin: 15px 0;
font-weight: bold;
}

.cat-desc p {
	font-size: 14px;
	margin: 10px 0;
    line-height: 20px;
}

.cat-desc ul {
    margin: 0 0 27px;
}

.cat-desc ul li, .cat-desc ol li {
	margin: 0 0 10px;
    padding-left: 20px;
    position: relative;
	list-style-type: none;
}


.cat-desc ul li:before, .cat-desc ol li:before {
    padding: 0px;
    margin-left: 0px;
    width: 20px;
    display: inline-block;
    vertical-align: top;
    zoom: 1;
    position: absolute;
    top: 0px;
    left: 0px;
}


.cat-desc ul li::before {
    content: "●";
    color: var(--color-primary-p3);
}


.desc-full h2 {
	font-size: 20px;
	margin: 20px 0;
	font-weight: bold;
}
	
.desc-full p {
		font-size: 14px;
		margin: 10px 0;
		line-height: 20px;
}

.desc-full ul {
    margin: 20px 0;
}

.desc-full ul li, .desc-full ol li {
	margin: 0 0 5px;
    padding-left: 20px;
    position: relative;
	list-style-type: none;
}


.desc-full ul li:before, .desc-full ol li:before {
    padding: 0px;
    margin-left: 0px;
    width: 20px;
    display: inline-block;
    vertical-align: top;
    zoom: 1;
    position: absolute;
    top: 0px;
    left: 0px;
}

.desc-full ul li::before {
    content: "●";
    color: var(--color-primary-p3-light);;
}


.cat-bott .xxauthor i {
     position: absolute;
    top: 6px !important;
    left: 6px !important;
}


.clr:after {
	clear: both;
	content: ".";
	display: block;
	height: 0;
	overflow: hidden;
	visibility: hidden;
}

.clrleft {
	clear: left;
}

.icon {
	text-indent: -1000em;
	overflow: hidden;
	display: inline-block;
}

.fright {
	float: right;
}

.fleft {
	float: left;
}

.tcenter {
	text-align: center;
}

.tleft {
	text-align: left;
}

.tright {
	text-align: right;
	padding-right: 15px;
}

.tjustify {
	text-align: justify;
}

.tunder {
	text-decoration: underline !important;
}

.tdel {
	text-decoration: line-through;
}

.overh {
	overflow: hidden;
}

.overv {
	overflow: visible;
}

.overa {
	overflow: auto;
}

.vishid {
	visibility: hidden;
}

.rel {
	position: relative;
}

.abs {
	position: absolute;
}

.fix {
	position: fixed;
}

.button {
	display: -moz-inline-box;
	display: inline-block;
	zoom: 1;
	white-space: nowrap;
}

.button:hover,
.tdnone {
	text-decoration: none !important;
}

.full {
	width: 100% !important;
}

.block {
	display: block;
    font-weight: bold;
}

.inlblk {
	display: -moz-inline-box;
	display: inline-block;
	zoom: 1;
}

.icon.inlblk,
.icon.textin {
	text-indent: 0;
}

.icon.inlblk span {
	visibility: hidden;
}

.visible,
.visible>* {
	visibility: visible !important;
}

.inline {
	display: inline;
}

.dnone {
	display: none;
}

.ellipsis {
	text-overflow: ellipsis;
}

.xx-small {
	font-size: 9px;
}

.x-small {
	font-size: 10px;
}

.small {
	font-size: 11px !important;
}

.normal {
	font-size: 12px;
	line-height: 16px;
}

.x-normal {
	font-size: 13px;
}

.large {
	font-size: 14px;
	line-height: 18px;
}

.medium {
	font-size: 15px;
}

.x-large {
	font-size: 16px;
}

.x-large2 {
	font-size: 17px;
}

.xx-large {
	font-size: 18px;
}

.xx-large2 {
	font-size: 19px;
}

.xxx-large {
	font-size: 20px;
}

.xxxx-large {
	font-size: 22px;
}

.x-big {
	font-size: 24px;
}

.x-big2 {
	font-size: 26px;
}

.xx-big {
	font-size: 30px;
}

.cfff {
	color: #fff;
}

.c000 {
	color:  var(--color-primary-p3-dark);
}

.bgfff {
	background: #fff;
}

.bg000 {
	background:  var(--color-primary-p3-dark);
}

.bgnone {
	background: none !important;
}

.fnormal {
	font-weight: normal !important;
}

.fsnormal {
	font-style: normal !important;
}

.fbold {
	font-weight: bold;
}

.fitalic {
	font-style: italic;
}

.vbase {
	vertical-align: baseline;
}

.vmiddle {
	vertical-align: middle;
}

.vtop {
	vertical-align: top;
}

.vbottom {
	vertical-align: bottom;
}

.vtextbott {
	vertical-align: text-bottom;
}

.brnone {
	border: none !important;
}

.nowrap {
	white-space: nowrap
}

.br2 {
	-webkit-border-radius: 2px;
	-moz-border-radius: 2px;
	border-radius: 2px;
}

.br3 {
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}

.br4 {
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
}

.br5 {
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
}

.marker {
	background: #FFFABE;
	color: #111111;
	padding: 4px 6px;
}


.collection {margin-top: 10px;}




.separate {
	margin-top: 20px;
}

.ttupper {
	text-transform: uppercase;
}

.ttnone {
	text-transform: none;
}

.margin0_a {
	margin: 0 auto;
}

.margin0 {
	margin: 0px !important;
}

.margin1 {
	margin: 1px !important;
}

.margin10 {
	margin: 10px !important;
}

.margin5_0 {
	margin: 5px 0px !important;
}

.margin10_0 {
	margin: 10px 0px !important;
}

.margin0_5 {
	margin: 0px 5px !important;
}

.margin0_10 {
	margin: 0px 10px !important;
}

.margin0_20 {
	margin: 0px 20px !important;
}

.margin0_30 {
	margin: 0px 30px !important;
}

.margin20_30 {
	margin: 20px 30px !important;
}

.margin0_50 {
	margin: 0px 50px !important;
}

.margin10_0_0 {
	margin: 10px 0px 0px !important;
}

.margin20_0 {
	margin: 20px 0px !important;
}

.margin15_0 {
	margin: 15px 0px !important;
}

.margin20_auto {
	margin: 20px auto !important;
}

.marginbott2 {
	margin-bottom: 2px !important;
}

.marginbott3 {
	margin-bottom: 3px !important;
}

.marginbott5 {
	margin-bottom: 5px !important;
}

.marginbott10 {
	margin-bottom: 10px !important;
}

.marginbott15 {
	margin-bottom: 15px !important;
}

.marginbott20 {
	margin-bottom: 20px !important;
}

.marginbott25 {
	margin-bottom: 25px !important;
}

.marginbott30 {
	margin-bottom: 30px !important;
}

.marginbott40 {
	margin-bottom: 40px !important;
}

.marginbott50 {
	margin-bottom: 50px !important;
}

.marginbott60 {
	margin-bottom: 60px !important;
}

.marginbott100 {
	margin-bottom: 100px !important;
}

.marginbott-5 {
	margin-bottom: -5px !important;
}

.marginbott-10 {
	margin-bottom: -10px !important;
}

.margintop0 {
	margin-top: 0 !important;
}

.margintop1 {
	margin-top: 1px !important;
}

.margintop2 {
	margin-top: 2px !important;
}

.margintop3 {
	margin-top: 3px !important;
}

.margintop4 {
	margin-top: 4px !important;
}

.margintop5 {
	margin-top: 5px !important;
}

.margintop6 {
	margin-top: 6px !important;
}

.margintop7 {
	margin-top: 7px !important;
}

.margintop8 {
	margin-top: 8px !important;
}

.margintop9 {
	margin-top: 9px !important;
}

.margintop10 {
	margin-top: 10px !important;
}

.margintop12 {
	margin-top: 12px !important;
}

.margintop15 {
	margin-top: 15px !important;
}

.margintop25 {
	margin-top: 25px !important;
}

.margintop45 {
	margin-top: 45px !important;
}

.margintop-3 {
	margin-top: -3px !important;
}

.margintop-4 {
	margin-top: -4px !important;
}

.margintop-5 {
	margin-top: -5px !important;
}

.marginright1 {
	margin-right: 1px !important;
}

.marginright2 {
	margin-right: 2px !important;
}

.marginright3 {
	margin-right: 3px !important;
}

.marginright5 {
	margin-right: 5px !important;
}

.marginright7 {
	margin-right: 7px !important;
}

.marginright10 {
	margin-right: 10px !important;
}

.marginright15 {
	margin-right: 15px !important;
}

.marginright20 {
	margin-right: 20px !important;
}

.marginright30 {
	margin-right: 30px !important;
}

.marginright75 {
	margin-right: 75px !important;
}

.marginright280 {
	margin-right: 280px !important;
}

.marginleft0 {
	margin-left: 0px !important;
}

.marginleft-1 {
	margin-left: -1px !important;
}

.marginleft-10 {
	margin-left: -10px !important;
}

.marginleft-25 {
	margin-left: -25px !important;
}

.marginleft-30 {
	margin-left: -30px !important;
}

.marginleft3 {
	margin-left: 3px !important;
}

.marginleft5 {
	margin-left: 5px !important;
}

.marginleft7 {
	margin-left: 7px !important;
}

.marginleft10 {
	margin-left: 10px !important;
}

.marginleft14 {
	margin-left: 14px !important;
}

.marginleft15 {
	margin-left: 15px !important;
}

.marginleft20 {
	margin-left: 20px !important;
}

.marginleft25 {
	margin-left: 25px !important;
}

.marginleft30 {
	margin-left: 30px !important;
}

.marginleft40 {
	margin-left: 40px !important;
}

.marginleft70 {
	margin-left: 70px !important;
}

.marginleft75 {
	margin-left: 75px !important;
}

.marginleft205 {
	margin-left: 205px !important;
}

.marginleft230 {
	margin-left: 230px !important;
}

.margintop20 {
	margin-top: 20px !important;
}

.margintop30 {
	margin-top: 30px !important;
}

.margintop35 {
	margin-top: 35px !important;
}

.margintop40 {
	margin-top: 40px !important;
}

.margintop50 {
	margin-top: 50px !important;
}

.margintop60 {
	margin-top: 60px !important;
}

.margintop65 {
	margin-top: 65px !important;
}

.margintop-30 {
	margin-top: -30px !important;
}

.margintop-10 {
	margin-top: -10px !important;
}

.margintop-2 {
	margin-top: -2px !important;
}

.margintop-1 {
	margin-top: -1px !important;
}

.h100 {
	height: 100%;
}

.zi2 {
	z-index: 2;
}

.zi3 {
	z-index: 3;
}

.zi4 {
	z-index: 4;
}

.zi5 {
	z-index: 5;
}

.zi6 {
	z-index: 6;
}

.breaklist>*:before {
	content: "|";
	color: #999999;
	padding: 0 .4em 0 .2em;
}

.breaklist>*:first-child:before,
.breaklist>*.noslash:before {
	content: " ";
	padding: 0px;
}

.halfgrid .half {
	width: 50%;
}

.halfgrid .half>div.inner {
	padding-left: 10px;
}

.halfgrid .half:first-child>div.inner {
	padding: 0px;
	padding-right: 10px;
}

.part60 {
	width: 60%;
}

.part50 {
	width: 50%;
}

.part33 {
	width: 33%;
}

.part25 {
	width: 25%;
}

.part40 {
	width: 40%;
}

.pding0 {
	padding: 0px !important;
}

.pding3 {
	padding: 3px !important;
}

.pding7 {
	padding: 7px !important;
}

.pding6_10 {
	padding: 6px 10px;
}

.pding8_15 {
	padding: 8px 15px;
}

.pding5 {
	padding: 5px !important;
}

.pding10 {
	padding: 10px !important;
}

.pding15 {
	padding: 15px !important;
}

.pding20 {
	padding: 20px !important;
}

.pding25 {
	padding: 25px !important;
}

.pding30 {
	padding: 30px !important;
}

.pding20_0 {
	padding: 20px 0 !important;
}

.pding20_10 {
	padding: 20px 10px !important;
}

.pding30_0 {
	padding: 30px 0 !important;
}

.pding30_10 {
	padding: 30px 10px !important;
}

.pding10_20 {
	padding: 10px 20px !important;
}

.pding10_0 {
	padding: 10px 0px;
}

.pding0_5 {
	padding: 0px 5px !important;
}

.pding0_10 {
	padding: 0px 10px;
}

.pding0_15 {
	padding: 0px 15px;
}

.pding0_20 {
	padding: 0px 20px !important;
}

.pding0_25 {
	padding: 0px 25px;
}

.pding0_40 {
	padding: 0px 40px;
}

.pding20_0_10 {
	padding: 20px 0px 10px;
}

.pding25_0_10 {
	padding: 25px 0px 10px;
}

.pding0_0_10 {
	padding: 0px 0px 10px;
}

.pding0_0_20 {
	padding: 0px 0px 20px;
}

.pding5_0 {
	padding: 5px 0px;
}

.pding15_0 {
	padding: 15px 0px;
}

.pding15_30 {
	padding: 15px 30px;
}

.pding5_10 {
	padding: 5px 10px;
}

.pding5_0_10 {
	padding: 5px 0px 10px;
}

.pdingtop5 {
	padding-top: 5px;
}

.pdingtop6 {
	padding-top: 6px !important;
}

.pdingtop7 {
	padding-top: 7px !important;
}

.pdingtop10 {
	padding-top: 10px;
}

.pdingtop15 {
	padding-top: 15px;
}

.pdingtop16 {
	padding-top: 16px !important;
}

.pdingbott0 {
	padding-bottom: 0 !important;
}

.pdingbott1 {
	padding-bottom: 1px !important;
}

.pdingbott2 {
	padding-bottom: 2px !important;
}

.pdingbott3 {
	padding-bottom: 3px !important;
}

.pdingbott5 {
	padding-bottom: 5px;
}

.pdingbott10 {
	padding-bottom: 10px;
}

.pdingbott13 {
	padding-bottom: 13px !important;
}

.pdingbott15 {
	padding-bottom: 15px;
}

.pdingbott20 {
	padding-bottom: 20px;
}

.pdingbott50 {
	padding-bottom: 50px;
}

.pdingtop20 {
	padding-top: 20px;
}

.pdingtop30 {
	padding-top: 30px;
}

.pdingtop40 {
	padding-top: 40px;
}

.pdingleft5 {
	padding-left: 5px;
}

.pdingleft8 {
	padding-left: 8px;
}

.pdingleft10 {
	padding-left: 10px;
}

.pdingleft20 {
	padding-left: 20px !important;
}

.pdingleft25 {
	padding-left: 25px !important;
}

.pdingleft30 {
	padding-left: 30px !important;
}

.pdingright0 {
	padding-right: 0px !important;
}

.pdingright5 {
	padding-right: 5px !important;
}

.pdingright7 {
	padding-right: 7px !important;
}

.pdingright10 {
	padding-right: 10px !important;
}

.pdingright20 {
	padding-right: 20px !important;
}

.pdingright30 {
	padding-right: 30px !important;
}

.brkall {
	word-break: break-all;
}

table.fixed {
	table-layout: fixed;
}

table.breakword td,
.brkword {
	word-wrap: break-word;
}

table.tcenter th,
table.tcenter td {
	text-align: center;
}



.link.spoiler {
	text-decoration: none;
}

a.link:hover span.icon,
a.link:hover img {
	background-color: transparent;
}


.no-stock {    
	-webkit-filter: grayscale(100%);
    filter: grayscale(100%);
}

.brtop0 {
	border-top: none !important;
}

.brright0 {
	border-right: none !important;
}

.brbottom0 {
	border-bottom: none !important;
}

.brleft0 {
	border-left: none !important;
}

.lheight65 {
	line-height: 65px;
}

.lheight45 {
	line-height: 45px;
}

.lheight40 {
	line-height: 40px;
}

.lheight35 {
	line-height: 35px;
}

.lheight32 {
	line-height: 32px;
}

.lheight30 {
	line-height: 30px;
}

.lheight28 {
	line-height: 28px;
}

.lheight26 {
	line-height: 26px;
}

.lheight24 {
	line-height: 24px;
}

.lheight22 {
	line-height: 22px;
}

.lheight20 {
	line-height: 20px;
}

.lheight18 {
	line-height: 18px;
}


.lheight15 {
	line-height: 15px;
}

.lheight14 {
	line-height: 14px;
}

.lheight13 {
	line-height: 13px;
}

.lheight12 {
	line-height: 12px;
}

.height14 {
	height: 14px;
}

.height16 {
	height: 16px;
}

.minheight22 {
	min-height: 22px;
}

.width80 {
	width: 80px;
}

.wwnormal {
	word-wrap: normal !important;
}

.mheight1 {
	min-height: 1px !important;
}

.mheight16 {
	min-height: 16px !important;
}

.mheight18 {
	min-height: 18px !important;
}

.ffarial {
	
}

.table {
	display: table;
}

.hidden {
	display: none;
}

.hidden-focus {
	opacity: 0;
	font-size: 0 !important;
	filter: alpha(opacity=0);
}

.hidden-focus+.cityfield {
	visibility: hidden;
}

.left50 {
	left: 50%
}

.left-50 {
	left: -50%
}

#main-container {
    padding: 20px 0;
    border-bottom: 1px solid #e7e7e7;
    margin-bottom: 30px;
}


#main-menu  {
    padding: 1px 0 20px;
    border-bottom: 1px solid #e7e7e7;
    margin-bottom: 30px;
}





#main-banner {
	background-color: #eff1fb;
	padding: 20px 0 10px;
}



#main-cat {
	padding: 0px 0 25px;
}









.cat-speedbar {padding: 5px 0 5px;
    font-size: 18px;
    line-height: 28px;}




ul.categorySelectList {
	top: 100%;
	left: 0;
	width: 277px;
	z-index: 50;
	text-shadow: none!important;
	overflow: auto;
	background: #fff;
	border: none!important;
	box-shadow: 0 0 6px 0 rgba(0, 0, 0, .3)
}

.pricelabel,
.suggest.photos,
.suggest.readonly,
.suggestsearchmain li label.title,
div.pageinfo {
	text-shadow: 0 1px 0 #fff
}

form.search ul.categorySelectList,
form.searchmain ul.categorySelectList {
	font-size: 14px;
	line-height: 18px
}

ul.categorySelectList li {
	background: #fff;
	border: none
}

ul.categorySelectList li a {
	padding: 4px 60px 4px 14px;
	color: #5b5b5b
}

ul.categorySelectList li a .counter {
	color: #686666!important;
	background: #f4f3f1;
	font-size: 10px;
	right: 24px;
	top: 5px;
	line-height: 14px;
	padding: 2px 8px;
	border-radius: 10px
}

ul.categorySelectList li li a .counter {
	right: 8px
}

ul.categorySelectList li .category-icon:before {
	position: absolute;
	left: 13px;
	top: 5px;
	font-size: 20px;
	color: #aaa
}

ul.categorySelectList li a .caticongray {
	left: 13px;
	top: 3px
}

ul.categorySelectList li a [data-icon] {
	font-size: 14px;
	right: 10px;
	top: 7px;
	position: absolute;
	color: #333333
}

ul.categorySelectList li.hover .category-icon:before,
ul.categorySelectList li.hover li:hover>a,
ul.categorySelectList li.hover li:hover>a .counter,
ul.categorySelectList li.hover>a,
ul.categorySelectList li.hover>a .counter,
ul.categorySelectList li.selected>a,
ul.categorySelectList li.selected>a .counter,
ul.categorySelectList>li.hover>a [data-icon],
ul.categorySelectList>li.selected>a [data-icon] {
	color: #fff
}

ul.categorySelectList li ul {
	display: none;
	overflow: auto;
	width: 277px;
	-webkit-box-shadow: 0 0 6px 0 rgba(0, 0, 0, .3);
	-moz-box-shadow: 0 0 6px 0 rgba(0, 0, 0, .3);
	-ms-box-shadow: 0 0 6px 0 rgba(0, 0, 0, .3);
	-o-box-shadow: 0 0 6px 0 rgba(0, 0, 0, .3);
	box-shadow: 0 0 6px 0 rgba(0, 0, 0, .3)
}

form.search .combospace ul.categorySelectList li ul,
ul.categorySelectList.regionsList li ul {
	width: 250px
}

ul.categorySelectList li.hover,
ul.categorySelectList li.hover li:hover,
ul.categorySelectList li.selected {
	background: #333333
}

ul.categorySelectList li.hover>ul {
	left: 100%;
	top: 0;
	display: block
}

ul.categorySelectList>li>a {
	padding: 6px 90px 6px 43px
}

form.search .combospace ul.categorySelectList {
	min-width: 290px
}

.smallscreen form.search .combospace ul.categorySelectList li.hover>ul {
	left: auto;
	right: 100%
}

ul.categorySelectList.regionsList {
	min-width: 305px
}

ul.categorySelectList.regionsList li a {
	padding-left: 17px;
	padding-right: 17px
}

ul.categorySelectList.regionsList li.hover,
ul.categorySelectList.regionsList li.hover li:hover,
ul.categorySelectList.regionsList li.selected {
	background-image: none
}



.button {
	font-weight: 700;
	border: 1px solid #333333;
	background-color: #333333;
	-webkit-box-shadow: 0 0 0 2px #fff;
	-moz-box-shadow: 0 0 0 2px #fff;
	-ms-box-shadow: 0 0 0 2px #fff;
	-o-box-shadow: 0 0 0 2px #fff;
	box-shadow: 0 0 0 2px #fff;
	height: 28px
}

.button:hover {
	background-color: #3ba8de;
	border-color: #3ba8de
}

.button.sec {
	background-color: #e5e5e5;
	border-color: #e5e5e5
}

.button.sec:hover {
	background-color: #ededed;
	border-color: #ededed
}

.button.gp {
	border: 1px solid #b3b3b3;
	background-color: #fdfdfd;
	background-image: -webkit-gradient(linear, left top, left bottom, from(#fdfdfd), to(#ccc));
	background-image: -webkit-linear-gradient(top, #fdfdfd, #ccc);
	background-image: -moz-linear-gradient(top, #fdfdfd, #ccc);
	background-image: -ms-linear-gradient(top, #fdfdfd, #ccc);
	background-image: -o-linear-gradient(top, #fdfdfd, #ccc);
	background-image: linear-gradient(top, #fdfdfd, #ccc);
	filter: progid:DXImageTransform.Microsoft.gradient(start-colourStr='#fdfdfd', end-colourStr='#cccccc')
}



.cards__img {
    display: block;
    width: 88px;
    height: 31px;
    margin: auto;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
}




.c2b {
	color: #2b2b2b
}

.c62 {
	color: #626262
}

.c27 {
	color: #272727
}


.c72 {
    color: #0cc320;
    font-size: 16px;
    font-weight: bold;
}

.c73 {
	color:  var(--color-primary-p3-dark);
	font-size: 13px;
}

.c41 {
	color: #414141
}

.ca6 {
	color: #A6A6A6
}

.ca2 {
	color: #a2a2a2
}

.c6f {
	color: #6f6f6f
}

.c68 {
	color: #686868
}

.cc914 {
	color: #C91414
}

.cd0 {
	color: #D0D0D0
}

.cb00c01 {
	color: #b00c01
}

.cab {
	color: #ababab
}

.c83 {
	color: #838383
}

.c6e754f {
	color: #6e754f
}

.c97 {
	color: #979797
}

.cb90404 {
	color: #b90404
}

.bgd9 {
	background: #D9D9D9
}

.bgf9 {
	background: #F9F9F9
}

.bgf6f5 {
	background: #F6F5F0
}

.bgf3 {
	background: #F3F3F3
}

.bgf2 {
	background: #F2F2F2
}

.bgef {
	background: #EFEFEF
}

.bgff5a00 {
	background: #ff5a00
}

.bgfffb8b {
	background: #fffb8b
}

.bgfff9ef {
	background: #fff9ef
}

.bgfef8b5 {
	background: #fef8b5
}

.brc8 {
	border: 1px solid #C8C8C8
}

.bre3 {
	border: 1px solid #e3e3e3
}

.bre4 {
	border: 1px solid #e4e4e4
}

.brf3 {
	border: 1px solid #f3f3f3
}

.brc4 {
	border: 1px solid #C4C4C4
}

.color-1 {
	color: #a0a0a0
}

.color-2 {
	color: #909090
}

.color-3 {
	color: #333333
}

.color-4 {
	color: #9f9e9e
}

.color-5 {
	color: #525252
}

.color-6 {
	color: #616161
}

.color-7 {
	color: #959595
}

.color-8 {
	color: #a5a5a5
}

.color-9 {
	color: #b4b4b4
}

.color-10 {
	color: #8a8a8a
}

.color-11 {
	color: #646464
}

.color-16 {
	color: #4e4e4e
}

.color-17 {
	color: #ac0901
}

.color-18 {
	color: #797979
}

.color-19 {
	color: #636363
}

.color-20 {
	color: red
}

.color-21 {
	color: #090
}

.bg-1 {
	background: #fbfbfb
}

.bg-2 {
	background: #fafafa
}

.bg-3 {
	background: #fff7c5
}

.bg-4 {
	background: #f8f8f7
}

.bg-7 {
	background: #f7f7f7
}

.bg-8 {
	background: #fffbe0
}

.bg-9 {
	background: #fffde5
}

.br-1 {
	border: 1px solid #d7d7d7
}

.br-3 {
	border: 1px solid #ccc
}

.br-4 {
	border: 1px solid #dfdfdf
}

.br-5 {
	border: 1px solid grey
}

.brbott-1 {
	border-bottom: 1px solid #dfdedd
}

.brbott-3 {
	border-bottom: 1px solid #d8d8d4
}

.brbott-4 {
	border-bottom: 1px solid #cacaca
}

.brbott-5 {
	border-bottom: 1px solid #e3e3e3
}

.brbott-6 {
	border-bottom: 1px solid #e5e5e5
}

.brbott-7 {
	border-bottom: 1px solid #dadada
}

.brbott-8 {
	border-bottom: 1px solid #e8e8e8
}

.brbott-12 {
	border-bottom: 1px solid #fff
}

.brbottdash-1 {
	border-bottom: 1px dashed #e3e3e3
}

.brbottdash-2 {
	border-bottom: 1px dashed #b4b4b4
}

.brtop-1 {
	border-top: 1px solid #e3e3e3
}

.brtop-2 {
	border-top: 1px solid #fff
}

.brtop-4 {
	border-top: 1px solid #dfdedd
}

.brtop-5 {
	border-top: 1px solid #ccc
}

.brd1ce81 {
	border: 1px solid #d1ce81
}

.brbotte9 {
	border-bottom: 1px solid #e9e9e9
}

.brbottd4 {
	border-bottom: 1px solid #d4d4d4
}

.brbottdashb1 {
	border-bottom: 1px dashed #B1B1AC
}

.brbottdashc8 {
	border-bottom: 1px dashed #c8c8c8
}

.brtopdashc8 {
	border-top: 1px dashed #c8c8c8
}

.brleftdashc8 {
	border-left: 1px dashed #c8c8c8
}

.brbottdashd7 {
	border-bottom: 1px dashed #d7d7d1
}

.brbottdashd9 {
	border-bottom: 1px dashed #d9d9d9
}

.brtopdashd7 {
	border-top: 1px dashed #d7d7d1
}

.brtope5 {
	border-top: 1px solid #e5e5e5
}

.brtope9 {
	border-top: 1px solid #e9e9e9
}

.brbotte5 {
	border-bottom: 1px solid #e5e5e5
}

.brlefte5 {
	border-left: 1px solid #e5e5e5
}

.brrighte5 {
	border-right: 1px solid #E5E5E5
}

.dborder {
	border-bottom: 1px dashed #dfdfdf
}

.dborder>div {
	border-bottom: 1px dashed #fff;
	margin: 0
}

.dborder.top {
	border: none;
	border-top: 1px dashed #dfdfdf
}

.dborder.top>div {
	border: none;
	border-top: 1px dashed #fff;
	margin: 0
}

.website.big {
	height: 70px;
	width: 70px;
	background: url(/templates/lifesport/images/logobrain.png) no-repeat;
	background-size: 100%;
	text-indent: -1000em;
	overflow: hidden;
	display: inline-block
}



.link,
a {
	color: #333333
}




a {
	outline: 0
}

.link:hover,
a.tdnone:hover .link {
	color: #dd6f78
}



.link:hover>p {
	color: #333;
}





a.link.hn:hover,
a.tdnone:hover .link.hn {
	color: #b8e0f4
}

a.link.hn:hover>*,
a.tdnone:hover .link.hn>* {
	color: #333333;
	background-color: transparent
}

.link.spoiler {
	border-bottom: 1px dotted #ACCAEE
}

.link.spoiler.graydot {
	color: #c8c8c8;
	border-bottom: 1px dotted #c8c8c8
}

.link.spoiler.graydot>* {
	color: #414141
}

a.link.spoiler.graydot:hover,
a.tdnone:hover .link.spoiler.graydot {
	border-color: #b8e0f4
}

a.link.spoiler.graydot:hover>*,
a.tdnone:hover .link.spoiler.graydot>* {
	color: #333333;
	background-color: transparent
}

.link.report {
	color: #fcaeae
}

.link.report>* {
	color: #c00
}

.link.report:hover,
.link.report:hover>*,
a.tdnone:hover .link.report,
a.tdnone:hover .link.report>* {
	color: #fff!important
}

.link.reporthov {
	color: #fcaeae
}

.link.reporthov>* {
	color: #c00
}

a.link.reporthov:hover,
a.tdnone:hover .link.reporthov {
	color: #fff;
	text-decoration: none
}

a.link.reporthov:hover>*,
a.tdnone:hover .link.reporthov>* {
	color: #fff;
	background-color: #c00
}

.link.gray {
	color: #c8c8c8
}

.link.gray>* {
	color: #414141;
	font-size: 14px;
    font-weight: 400;
    line-height: 30px;
}

.link.gray:hover,
a.tdnone:hover .link.gray {
	color: #b8e0f4
}

.link.gray:hover>*,
a.tdnone:hover .link.gray>* {
	color: #cd6f77;
	background-color: transparent
}

.link.gray.hn:hover,
a.tdnone:hover .link.gray.hn {
	color: #c8c8c8
}

.link.gray.hn:hover>*,
a.tdnone:hover .link.gray.hn>* {
	color: #414141
}

.link.gray .label-changes {
	position: absolute;
	left: 100%;
	top: -2px;
	margin-left: 6px;
	background: #fffdc2;
	color: #897f00;
	padding: 2px 4px;
	font-size: 10px
}

.link.gray2 {
	color: #D0D0D0
}

.link.gray2>* {
	color: #626262
}

.link.gray2:hover,
a.tdnone:hover .link.gray2 {
	color: #b8e0f4
}

.link.gray2:hover>*,
a.tdnone:hover .link.gray2>* {
	color: #333333;
	background-color: transparent
}

.link.gray3 {
	color: #737373
}

.link.gray3:hover,
a.tdnone:hover .link.gray3 {
	color: #333333
}

.link.gray4 {
	color: #d4d4d4
}

.link.gray4>* {
	color: #959595
}

.link.gray4:hover,
a.tdnone:hover .link.gray4 {
	color: #b8e0f4
}

.link.gray4:hover>*,
a.tdnone:hover .link.gray4>* {
	color: #333333;
	background-color: transparent
}

.link.impt,
.link.impt>* {
	color: #ff5050
}

a.link.hover {
	color: #fff
}

a.link.hover>* {
	color: #fff;
	background-color: #333333
}

.similarads a.link:visited,
table.gallerybig a.link:visited,
table.offers a.link:visited,
ul.gallerywide a.link:visited {
	color: #e0bae6
}

.similarads a.link:visited>*,
table.gallerybig a.link:visited>*,
table.offers a.link:visited>*,
ul.gallerywide a.link:visited>* {
	color:  var(--color-primary-p3-dark);
}

.similarads a.link:visited:hover>*,
table.gallerybig a.link:visited:hover>*,
table.offers a.link:visited:hover>*,
ul.gallerywide a.link:visited:hover>* {
	color: #dd6f78
}

.user-box__photo {
	width: 32px;
	height: 32px;
	border-radius: 50%;
	box-sizing: border-box;
	display: inline-block;
	vertical-align: middle;
	background: #efefef;
	margin: -20px 5px 0px 0
}

.user-box__photo [data-icon] {
	margin: 8px 0 0!important;
	color: #333333;
	font-size: 16px!important
}

.user-box__photo img {
	width: 30px;
	height: 30px;
	border: 1px solid #b4bfc5;
	border-radius: 50%
}

#cookiesBar {
	padding: 20px 70px 20px 40px;
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
	background: rgba(0, 0, 0, .7);
	z-index: 100
}

#cookiesBar .close {
	top: 50%;
	right: 30px;
	margin-top: -8px;
	color: #fff
}


@media screen and (max-device-width:480px),
screen and (max-device-width:960px) and (-webkit-min-device-pixel-ratio:2) {
	.rightBranding {
		display: none
	}
	form.search a.select {
		line-height: 16px;
		height: 16px;
		padding-top: 10px;
		padding-bottom: 9px
	}
}

@media screen and (max-width:1080px) {
	#mobileAppsbadge {
		display: none!important
	}
}

.bodyIndent #mobileAppsbadge {
	display: none!important
}


#container_top {
	margin: 0 auto;
	width: 890px
}


#footer-container .box {
	margin: 15px 0;
	color:  var(--color-primary-p3-dark);
}

#footer-container .partners.box {
	margin: 0
}

#footer-container .static.box {
	width: 31%;
    margin: 0 10px 0 0;
}




@media screen and (max-width: 900px) {
#footer-container .static.box {
     width: 100%;
    margin: 0 10px 0 0;
}


#footer-container .fright {
       float: left;
    margin-top: 20px;
}


#footer-container .block {
    display: block;
    font-weight: 500;
    font-size: 15px;
    line-height: 25px;
    border-bottom: 1px solid #ebebeb;
}


}












#footer-container .static.box li {
	margin: 3px 0
}

#footer-container .footer-partners span:after {
	width: 0;
	height: 0;
	margin-left: 5px;
	display: inline-block;
	vertical-align: middle;
	border-style: solid;
	border-width: 6px 4px 0;
	border-color:  var(--color-primary-p3-dark) transparent transparent;
	content: ''
}

#footer-container .footer-partners.active span:after {
	border-width: 0 4px 6px;
	border-color: transparent transparent  var(--color-primary-p3-dark);
}


#footer-container .siteinfobox .socialsbox {
	min-height: 66px;
	float: right;
	position: relative
}


#footer-container #lastwrapper {
	min-height: 135px
}



.footerapps {
	margin-top: 4px;
	position: relative
}

.footerapps .icon {
	width: 125px;
	height: 45px;
	margin: 0 3px;
	background: 50% 50% no-repeat;
	-webkit-filter: grayscale(100%);
	-moz-filter: grayscale(100%);
	-ms-filter: grayscale(100%);
	-o-filter: grayscale(100%);
	filter: grayscale(100%);
	opacity: .8;
	background-size: 100%
}

.footerapps a:hover .icon {
	-webkit-filter: grayscale(0);
	-moz-filter: grayscale(0);
	-ms-filter: grayscale(0);
	-o-filter: grayscale(0);
	filter: grayscale(0);
	opacity: 1
}

.footerapps .icon.googleplay {
	background-image: url(/templates/lifesport/images/gp.png);
	width: 135px
}

.footerapps .icon.appstore {
	background-image: url(/templates/lifesport/images/ap.svg)
}

.footerapps>.tag-line {
	white-space: nowrap;
	color: #8E8E8E;
	font-size: 12px;
	line-height: 16px;
	margin-top: 3px
}

.footerapps>a:hover .tag-line {
	display: block;
	position: absolute;
	left: 0;
	width: 100%;
	right: 0;
	top: 53px;
	color: #8E8E8E;
	font-size: 12px;
	line-height: 16px
}

.footerapps>a:hover .tag-line .block {
	color: #333333
}


.hlabel {
	-webkit-box-shadow: 0 -3px 3px -3px rgba(0, 0, 0, .3);
	-moz-box-shadow: 0 -3px 3px -3px rgba(0, 0, 0, .3);
	-ms-box-shadow: 0 -3px 3px -3px rgba(0, 0, 0, .3);
	-o-box-shadow: 0 -3px 3px -3px rgba(0, 0, 0, .3);
	box-shadow: 0 -3px 3px -3px rgba(0, 0, 0, .3)
}

.hlabel .inner {
	background: #feef8f;
	padding: 9px 0;
	color: #574c00;
	-webkit-box-shadow: inset 0 -3px 3px -3px rgba(0, 0, 0, .4);
	-moz-box-shadow: inset 0 -3px 3px -3px rgba(0, 0, 0, .4);
	-ms-box-shadow: inset 0 -3px 3px -3px rgba(0, 0, 0, .4);
	-o-box-shadow: inset 0 -3px 3px -3px rgba(0, 0, 0, .4);
	box-shadow: inset 0 -3px 3px -3px rgba(0, 0, 0, .4)
}

.hlabel .iconcont {
	width: 116px;
	margin-left: 10px;
	margin-right: 10px;
	height: 10px
}

.hlabel .icon.close {
	width: 9px;
	height: 9px;
	right: 14px;
	top: 15px;
	background-position: -34px 0
}




.columnsgrid {
	border-top: 1px solid #e9e9e9;
	min-height: 350px
}

.columnsgrid .col {
	margin: 0 0 15px 10px
}

.columnsgrid .col .box {
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	-ms-border-radius: 0;
	-o-border-radius: 0;
	border-radius: 0;
	width: 276px;
	margin: 12px 0 0;
	-webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .15);
	-moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .15);
	-ms-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .15);
	-o-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .15);
	box-shadow: 0 0 4px 0 rgba(0, 0, 0, .15)
}

.columnsgrid .col .box .mheight {
	min-height: 178px;
	line-height: 178px;
	background: #fff
}

.columnsgrid .col .box .thumb.scale1 {
	width: 100%;
	height: 178px;
	line-height: 178px
}

.columnsgrid .col .box .thumb.scale1.nophoto .alt-text {
	font-size: 14px;
	padding: 7px 0
}

.columnsgrid .col .box .price {
	font-size: 18px;
	line-height: 22px;
	margin-top: 2px
}

.headinfobox a,
.maincategories .maincategories-list .li .item a>span {
	font-weight: 700
}





.headinfobox a,
.maincategories .maincategories-list .li .item a>p {
	font-size: 11px;
    line-height: 11px;
}




.headinfobox a,
.maincategories .maincategories-list2 .li .item a>span {
	font-weight: 700
}


.headinfobox a,
.maincategories .maincategories-list2 .li .item a>p {
	font-size: 11px;
    line-height: 11px;
}






.headinfobox a,
.maincategories .maincategories-list3 .li .item a>span {
	font-weight: 700
}


.headinfobox a,
.maincategories .maincategories-list3 .li .item a>p {
	font-size: 11px;
    line-height: 11px;
}







.columnsgrid .col .box .details {
	padding: 10px;
	background: #fff;
	border-bottom: 1px solid #e7e7e7
}

.columnsgrid .col .box .details p {
	margin-top: 7px
}

.columnsgrid .col .box .details p:first-child {
	margin-top: 0
}

.columnsgrid .col .box .bg-3 .mheight {
	background-color: #FFF7C5
}

.columnsgrid .col .box .favtab {
	border: 1px solid #dfdfdf;
	right: 8px;
	top: -3px;
	padding: 5px 5px 6px;
	background: #fff;
	-webkit-box-shadow: 0 2px 2px -2px rgba(0, 0, 0, .3);
	-moz-box-shadow: 0 2px 2px -2px rgba(0, 0, 0, .3);
	-ms-box-shadow: 0 2px 2px -2px rgba(0, 0, 0, .3);
	-o-box-shadow: 0 2px 2px -2px rgba(0, 0, 0, .3);
	box-shadow: 0 2px 2px -2px rgba(0, 0, 0, .3)
}

.columnsgrid .col .box .note {
	border-top: 1px solid #dfdfdf;
	margin: 12px 0 0;
	padding: 7px 0 0;
	-webkit-box-shadow: inset 0 1px 0 0 #fff;
	-moz-box-shadow: inset 0 1px 0 0 #fff;
	-ms-box-shadow: inset 0 1px 0 0 #fff;
	-o-box-shadow: inset 0 1px 0 0 #fff;
	box-shadow: inset 0 1px 0 0 #fff
}

.columnsgrid .col .box:hover .onhover {
	visibility: visible
}

.columnsgrid .col .box .alert-options li {
	color: #898989;
	margin-top: 3px
}

.columnsgrid .col .box .alert-options li:first-child {
	margin-top: 0
}

.columnsgrid .col .box .alert-options .icon.f_checkbox {
	margin: 4px 6px 0 0
}



.favgallerybox .detailsLink .delivery-gallery-badge {
	position: absolute;
	right: 0;
	bottom: 0
}

.headinfobox {
	background: #95b4e3;
	color: #fff
}

.headinfobox .flexline>div:first-child,
.headinfobox.flexline>div:first-child {
	width: 32px
}

.headinfobox a {
	color: #fff
}

.headinfobox .link {
	color: #b8e0f4
}

.headinfobox .link>* {
	color: #fff
}

.headinfobox .link:hover>* {
	color: #95b4e3;
	background-color: #fff
}

.headinfobox [data-icon=circle_info] {
	font-size: 32px;
	display: inline-block
}

.headinfobox-warning {
	background: #fee9a8;
	color: #8a6a08
}

.headinfobox-warning a {
	color: #8a6a08;
	font-weight: 700
}













.maincategories .maincategories-list .li,
.maincategories .subcategories-list li {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	-ms-box-sizing: border-box;
	-o-box-sizing: border-box;
	box-sizing: border-box
}

.maincategories .maincategories-list {
	margin-top: 20px;
    border-top: 1px solid #e7e7e7;
    padding: 15px 0 0px;
}

.maincategories .maincategories-list .li {
	width: 25%;
	padding-right: 12px;
	padding-left: 60px;
	position: relative
}




.datamob {display: none}


@media screen and (max-width: 1063px) {
.maincategories .maincategories-list .li {
	width: 50%;
	padding-right: 12px;
	padding-left: 60px;
	position: relative
}



.datamob {display: none}



}



.lheight16 {
	line-height: 16px;
	display: flex;
    align-items: center;
}





@media screen and (max-width: 767px) {
.maincategories .maincategories-list .li {
	width: 100%;
	padding-right: 12px;
	padding-left: 60px;
	position: relative
}

.datamob {display:block;}



.datanonemob {display: none;}


.title-cell {width: 100%;}


.tright {
    text-align: right;
    padding-right: 26px;
    right: 35px;
    position: relative;
}



.lheight16 {width: 90%;line-height: 25px;
	display: block;
    align-items: center;}





}





.maincategories .maincategories-list .li.selected {
	text-decoration: none;
	cursor: default
}

.maincategories .maincategories-list .li .item {
	display: table;
	width: 100%;
	height: 48px
}

.maincategories .maincategories-list .li .item a {
	display: table-cell;
	vertical-align: middle;
	font-size: 15px;
	line-height: 20px
}

.maincategories .maincategories-list .li .item a.selected:before {
	width: 25px;
	height: 12px;
	content: '';
	background: url(/templates/lifesport/images/topselect.png) no-repeat 0 0;
	bottom: -25px;
	left: 12px;
	position: absolute
}

.maincategories .maincategories-list .li .item .cat-icon {
	width: 48px;
	height: 48px;
	border-radius: 25%;
	position: absolute;
	left: 0;
	top: 0;
	background-color: #fff
}

.maincategories .maincategories-list .li:hover .item .cat-icon {
box-shadow: 2px 4px 20px -4px rgba(0, 0, 0, .1);
}


.hoverico {display:none;}
.maincategories .maincategories-list .li:hover .item .nohoverico {display:none;}
.maincategories .maincategories-list .li:hover .item .hoverico {display:block;}


.maincategories .maincategories-list2 .li:hover .item .nohoverico {display:none;}
.maincategories .maincategories-list2 .li:hover .item .hoverico {display:block;}

.maincategories .maincategories-list3 .li:hover .item .nohoverico {display:none;}
.maincategories .maincategories-list3 .li:hover .item .hoverico {display:block;}

.hvmore-op {color: #333333;}
.hvmore-cl {color: #0cc320;}
.hvmore-op:hover {color: #0cc320;}
.hvmore-cl:hover {color: #333333;}








.maincategories .maincategories-list .li .item .selected .cat-icon {
	-webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-ms-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-o-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08)
}










.maincategories .maincategories-list2 .li,
.maincategories .subcategories-list2 li {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	-ms-box-sizing: border-box;
	-o-box-sizing: border-box;
	box-sizing: border-box
}

.maincategories .maincategories-list2 {
	margin-top: 20px;
    border-top: 1px solid #e7e7e7;
    padding: 15px 0 0px;
}

.maincategories .maincategories-list2 .li {
	width: 100%;
	padding-right: 12px;
	padding-left: 60px;
	position: relative
}














.maincategories .maincategories-list2 .li.selected {
	text-decoration: none;
	cursor: default
}

.maincategories .maincategories-list2 .li .item {
	display: table;
	width: 100%;
	height: 48px
}

.maincategories .maincategories-list2 .li .item a {
	display: table-cell;
	vertical-align: middle;
	font-size: 14px;
	line-height: 20px
}

.maincategories .maincategories-list2 .li .item a.selected:before {
	width: 25px;
	height: 12px;
	content: '';
	background: url(/templates/lifesport/images/topselect.png) no-repeat 0 0;
	bottom: -41px;
	left: 12px;
	position: absolute
}

.maincategories .maincategories-list2 .li .item .cat-icon {
	width: 48px;
	height: 48px;
	border-radius: 25%;
	position: absolute;
	left: 0;
	top: 0;
	background-color: #fff;
	overflow: hidden;
}

.maincategories .maincategories-list2 .li .item .cat-icon img {
	height: 40px;
	margin-bottom: 15px;
}

.maincategories .maincategories-list2 .li:hover .item .cat-icon {
box-shadow: 2px 4px 20px -4px rgba(0, 0, 0, .1);
}

.maincategories .maincategories-list2 .li .item .selected .cat-icon {
	-webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-ms-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-o-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08)
}








.maincategories .maincategories-list3 .li,
.maincategories .subcategories-list3 li {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	-ms-box-sizing: border-box;
	-o-box-sizing: border-box;
	box-sizing: border-box
}

.maincategories .maincategories-list3 {
	margin-top: 20px;
    border-top: 1px solid #e7e7e7;
    padding: 15px 0 0px;
}

.maincategories .maincategories-list3 .li {
	width: 50%;
	padding-right: 12px;
	padding-left: 60px;
	position: relative
}



.maincategories .maincategories-list3 .li.selected {
	text-decoration: none;
	cursor: default
}

.maincategories .maincategories-list3 .li .item {
	display: table;
	width: 100%;
	height: 48px
}

.maincategories .maincategories-list3 .li .item a {
	display: table-cell;
	vertical-align: middle;
	font-size: 14px;
	line-height: 20px
}

.maincategories .maincategories-list3 .li .item a.selected:before {
	width: 25px;
	height: 12px;
	content: '';
	background: url(/templates/lifesport/images/topselect.png) no-repeat 0 0;
	bottom: -41px;
	left: 12px;
	position: absolute
}

.maincategories .maincategories-list3 .li .item .cat-icon {
	width: 48px;
	height: 48px;
	border-radius: 25%;
	position: absolute;
	left: 0;
	top: 0;
	background-color: #fff
}

.maincategories .maincategories-list3 .li:hover .item .cat-icon {
box-shadow: 2px 4px 20px -4px rgba(0, 0, 0, .1);
}

.maincategories .maincategories-list3 .li .item .selected .cat-icon {
	-webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-ms-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-o-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08)
}









.maincategories .subcategories-list {
	background: #fff;
	border: 1px solid #efefef;
	padding: 23px 26px;
	margin-top: 24px;
	-webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-ms-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	-o-box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08);
	box-shadow: 0 0 4px 0 rgba(0, 0, 0, .08)
}

.maincategories .subcategories-title {
	border-bottom: 1px solid #e8e8e8;
	padding: 0 0 18px;
	margin-bottom: 20px;
	font-size: 15px;
	line-height: 20px;
	color: #ababab;
	margin-top: -3px
}

.maincategories .subcategories-list ul {
	margin-top: -20px;
	font-size: 15px;
	line-height: 19px
}

.maincategories .subcategories-list ul .fleft {
	width: 312px;
	margin-top: 20px;
}

@media screen and (max-width:1063px) {
.maincategories .subcategories-list ul .fleft {
	width: 312px;
	margin-top: 20px;
}
}

@media screen and (max-width:868px) {
.maincategories .subcategories-list ul .fleft {
	width: 100%;
	margin-top: 20px;
}
}







.maincategories .subcategories-list a.inlblk {
	padding-left: 24px;
	background: no-repeat;
	position: relative
}


.maincategories .subcategories-list .linksub i {
	position: absolute;
	left: 5px;
	top: 2px
}


.maincategories .subcategories-list .link-relatedcategory i {
    position: absolute;
    left: 0px;
    top: 1px;
}

.linksub:hover>*, a.tdnone:hover .linksub>* {
    color: #dd6f78;
}


.linksub:hover i {
    color: #333;
}


.maincategories .subcategories-list .clear {
	display: block;
	clear: both;
	font-size: 0;
	line-height: 0
}

.maincategories .subcategories-list [id^=subcatLink_] .link,
.maincategories .subcategories-list [id^=subcatLink_] .link>span {
	color: #df0000
}

.maincategories .subcategories-list [id^=subcatLink_] .link:hover>span {
	background-color: #df0000;
	color: #fff
}

.maincategories .subcategories-list #subcatLink_carAudio a {
	color: #333333!important
}

.maincategories .subcategories-list #subcatLink_carAudio a>span {
	color: #333333!important;
	padding-bottom: 2px
}

.maincategories .subcategories-list #subcatLink_carAudio a:hover>span {
	background-color: #333333;
	color: #fff!important;
	padding-bottom: 2px
}

.maincategories .subcategories-list #subcatLink_automobile_deals a,
.maincategories .subcategories-list #subcatLink_automobile_deals_trade a {
	color: #333333!important
}

.maincategories .subcategories-list #subcatLink_automobile_deals a>span,
.maincategories .subcategories-list #subcatLink_automobile_deals_trade a>span {
	color: #B9C806!important;
	border-bottom: 2px solid transparent;
	padding-bottom: 2px
}

.maincategories .subcategories-list #subcatLink_automobile_deals a:hover>span,
.maincategories .subcategories-list #subcatLink_automobile_deals_trade a:hover>span {
	background-color: #B9C806;
	color: #fff!important;
	border-bottom: 2px solid transparent;
	padding-bottom: 2px
}

.maincategories #bottom619.subcategories-list ul li a {
	color: #333333!important
}

.maincategories #bottom619.subcategories-list ul li a>span {
	color: #333333!important;
	padding-bottom: 2px
}

.maincategories #bottom619.subcategories-list ul li a:hover>span {
	background-color: #333333;
	color: #fff!important;
	padding-bottom: 2px
}


.maincategories .maincategories-list .li .item .cat-icon-circle {
	font-size: 28px;
	text-align: center;
	line-height: 55px;
	font-weight: 400!important;
	    color: #333333;
}

.maincategories .maincategories-list .li .item .cat-icon-circle:before {
	line-height: inherit
}



.maincategories .maincategories-list2 .li .item .cat-icon-circle {
	font-size: 28px;
	text-align: center;
	line-height: 55px;
	font-weight: 400!important;
	    color: #333333;
}

.maincategories .maincategories-list2 .li .item .cat-icon-circle:before {
	line-height: inherit
}




.maincategories .maincategories-list3 .li .item .cat-icon-circle {
	font-size: 28px;
	text-align: center;
	line-height: 55px;
	font-weight: 400!important;
	    color: #333333;
}

.maincategories .maincategories-list3 .li .item .cat-icon-circle:before {
	line-height: inherit
}








/*---Выпадающее меню кнопки редактировать---*/
#dropmenudiv {
    border: 1px solid #cbdfe8;
    background-color: #fbfdfe;
    font-size: 11px;
    line-height: 20px;
    margin: 2px 0;
    padding: 5px;
    opacity:0.9;
    -moz-opacity:0.9;
    filter:alpha(opacity=90);
}

#dropmenudiv a {
    display: block;
    text-indent: 3px;
    text-decoration: none;
    color: #3f4b51;
    padding: 1px 0;
    width: 100%;
}

#dropmenudiv a:hover {
    color: #2d8edd;
}




.form-control,
.ui-widget .ui-widget-content input,
.ui-widget .ui-widget-content select,
.ui-widget .ui-widget-content textarea,
.ui-widget .ui-widget-content button {
	display: block;
	width: 100%;
	padding: 10px 12px;
	font-size: 18px;
	line-height: 1.42857143;
	background-image: none;
	border-radius: 4px;
	-webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
	-o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
	transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s
}

#dle-promt-email {
	display: inline-block
}


.more-actor {
	margin-top: 20px
}

.btn-primary,
.more-actor,


.rating-grid {
	display: none
}

.btn-primary,
.ui-dialog .ui-dialog-buttonpane button {
	padding: 8px 20px
}

.sh-right-block {
	padding: 0 0 0 240px
}

.more-actor:before,


.ui-helper-clearfix:after {
	clear: both;
	content: ".";
	display: block;
	height: 0;
	visibility: hidden
}

.ui-helper-clearfix {
	display: inline-block
}

* html .ui-helper-clearfix {
	height: 1%
}

.ui-helper-clearfix {
	display: block
}

.ui-icon {
	background-repeat: no-repeat;
	display: block;
	overflow: hidden;
	text-indent: -99999px
}

.ui-widget-header {
	font-size: 22px
}

.ui-icon-close {
	background-position: -80px -128px
}

.ui-icon-closethick {
	background-position: -98px -130px
}

.ui-button .ui-button-text {
	display: block
}

input.ui-button {
	padding: .4em 1em
}

.ui-button-set {
	margin-right: 7px
}

.ui-button-set .ui-button {
	margin-left: 0;
	margin-right: -.3em
}

button.ui-button::-moz-focus-inner {
	border: 0;
	padding: 0
}

.ui-button .ui-button-text {
    display: block;
}

.btn-primary:hover, .more-actor:hover, .ui-dialog .ui-dialog-buttonpane button {
    background: #1856a9;
    border: 1px solid #1a5cb5;
    color: #fff;
}
.btn-primary, .more-actor, .ui-dialog .ui-dialog-buttonpane button {
    border: 1px solid #292d43;
    color: #fff;
}
.form-control, .ui-widget .ui-widget-content input, .ui-widget .ui-widget-content select, .ui-widget .ui-widget-content textarea, .ui-widget .ui-widget-content button {
    color: #c5cbdb;
    border: 1px solid #1D65C8;
}
.btn-primary, .more-actor, .ui-dialog .ui-dialog-buttonpane button {
    display: block;
    padding: 8px 10px;
    text-decoration: none;
    font-size: 15px;
    text-transform: uppercase;
    border-radius: 6px;
    background-color: transparent;
    border: 0;
    width: 100%;
}
.btn-primary, .more-actor, .ui-dialog .ui-dialog-buttonpane button {
    display: block;
    margin-top: 10px;
    text-align: center;
}

.ui-dialog .ui-dialog-buttonpane button {
    cursor: pointer;
    margin: .5em .4em .5em 0;
    overflow: visible;
    padding: .2em .6em .3em .6em;
    width: auto;
}
button {
    color: #fff;
}
input, button, select, textarea {
    
    font-size: inherit;
    line-height: inherit;
}
button, html input[type="button"], input[type="reset"], input[type="submit"] {
    -webkit-appearance: button;
    cursor: pointer;
}
button, select {
    text-transform: none;
}
button, input, optgroup, select, textarea {
    margin: 0;
    font: inherit;
}



.ui-dialog .ui-dialog-buttonpane button {
    background: rgb(24, 86, 169);
    border: 1px solid rgb(26, 92, 181);
    color: rgb(255, 255, 255);
}
.ui-dialog .ui-dialog-buttonpane button {
    border: 1px solid rgb(41, 45, 67);
    color: rgb(255, 255, 255);
}






.ui-dialog {
      background: #eff1fb;
    color:  var(--color-primary-p3-dark);
    -moz-box-shadow: 0 0 15px 0 rgba(0,0,0,0.6);
    -webkit-box-shadow: 0 0 15px 0 rgba(0,0,0,0.6);
    box-shadow: 0 0 15px 0 rgba(0,0,0,0.6);
}




.ui-dialog {
	display: none !important;
}

.ui-dialog .ui-dialog-titlebar {
	position: relative;
}

.ui-dialog .ui-dialog-titlebar-close {
	background: transparent;
    position: absolute;
    border: 0;
    right: 5px;
    top: 30px;
}

.ui-dialog .ui-dialog-titlebar-close span {
	display: none
}


.ui-dialog .ui-dialog-content {
	background: none;
	overflow: hidden !important;
	padding: 0 20px;
	position: relative;
	font-size: 14px;
	text-align: center;
	zoom: 1
}

.ui-dialog .ui-dialog-buttonpane {
	background-image: none;
	padding: 10px 0;
	text-align: left
}

.ui-dialog .ui-dialog-buttonpane button {
cursor: pointer;
    overflow: visible;
    padding: 5px;
    margin-right: 5px;
}

.ui-dialog .ui-resizable-se {
	bottom: 3px;
	height: 14px;
	right: 3px;
	width: 14px
}

.ui-draggable .ui-dialog-titlebar {
	cursor: move
}

.ui-autocomplete {
	position: absolute;
	cursor: default
}

* html .ui-autocomplete {
	width: 1px
}

.ui-menu {
	list-style: none;
	padding: 2px;
	margin: 0;
	display: block;
	float: left
}

.ui-menu .ui-menu {
	margin-top: -3px
}

.ui-menu .ui-menu-item {
	margin: 0;
	padding: 0;
	zoom: 1;
	float: left;
	clear: left;
	width: 100%
}

.ui-menu .ui-menu-item a {
	text-decoration: none;
	display: block;
	padding: .2em .4em;
	line-height: 1.5;
	zoom: 1
}

.ui-menu .ui-menu-item a.ui-state-hover,
.ui-menu .ui-menu-item a.ui-state-active {
	font-weight: normal;
	margin: -1px
}

pre code {
	display: block;
	padding: 0.5em;
	overflow: auto;
	white-space: pre
}




/*---подсветка текста в теге [code]---*/
pre code {
    display: block;
    padding: 0.5em;
    background: #f9fafa;
    border: 1px solid #dce7e7;
    overflow:auto;
    white-space: pre;
}

pre .comment,pre .template_comment,pre .diff .header,pre .doctype,pre .lisp .string,pre .javadoc {
    color: #93a1a1;
    font-style: italic;
}

pre .keyword,pre .css .rule .keyword,pre .winutils,pre .javascript .title,pre .method,pre .addition,pre .css .tag,pre .lisp .title {
    color: #859900;
}

pre .number,pre .command,pre .string,pre .tag .value,pre .phpdoc,pre .tex .formula,pre .regexp,pre .hexcolor {
    color: #2aa198;
}

pre .title,pre .localvars,pre .function .title,pre .chunk,pre .decorator,pre .builtin,pre .built_in,pre .lisp .title,pre .identifier,pre .title .keymethods,pre .id {
    color: #268bd2;
}

pre .tag .title,pre .rules .property,pre .django .tag .keyword {
    font-weight: bold;
}

pre .attribute,pre .variable,pre .instancevar,pre .lisp .body,pre .smalltalk .number,pre .constant,pre .class .title,pre .parent,pre .haskell .label {
    color: #b58900;
}

pre .preprocessor,pre .pi,pre .shebang,pre .symbol,pre .diff .change,pre .special,pre .keymethods,pre .attr_selector,pre .important,pre .subst,pre .cdata {
    color: #cb4b16;
}

pre .deletion {
    color: #dc322f;
}

pre .tex .formula {
    background: #eee8d5;
}


/* --- Сортировка статей --- */
.sort { list-style: none; padding: 0; margin: 0; }
  .sort > li, .sort { display: inline; }
  .sort > li { margin: 0 0 0 3%; }
  .sort > li a { color: #353535; }
  .sort > li.asc a, .sort > li.desc a { color: #3394e6; }
  .sort > li.asc a:after, .sort > li.desc a:after {
    content: "";
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAsBAMAAACj90TiAAAAG1BMVEUAAAAzlOYzlOYzlOYzlOYzlOYzlOYzlOYzlOar6gzlAAAACHRSTlMAjesv90eHRuQt1XUAAABSSURBVBjTzdCxDQAhDENRSyzAEFdQ0zDB9axEgzw2DokEI1A9/S4OyAxADEcpPGlpFKWoSpEKp0Dlb6SvG2jY4Fka4tw4PqbEsDNTcb8gn/d4LPQHQDdjhblbAAAAAElFTkSuQmCC);
    display: inline-block;
    vertical-align: middle;
    margin: -1px 0 0 .4em;
    width: 6px; height: 11px;
    -webkit-background-size: 6px auto; background-size: 6px auto;
}
.sort > li.asc a:after { background-position: 0 -11px; }

/*---Дополнительные поля---*/
.xfieldsrow {
  padding-top:5px;
  clear: both;
}
.xfieldscolleft {
  float: left;
  width: 30%;
}
.xfieldscolright {
  float: left;
  width: 70%;
}
.file-box {
  width: 95%;
  max-width: 437px;
  border:1px solid #B3B3B3;
  -moz-border-radius: 3px; -webkit-border-radius: 3px; border-radius: 3px;
  background-color: #F5F5F5;
  padding: 10px;
  margin-top: 10px;
}

.qq-uploader { position:relative; width: 100%;}

.qq-upload-button {
  display:inline-block;
  padding:4px 10px 4px 10px;
  margin-top:5px;
  font: bold 11px/1.5em Verdana;color: var(--color-primary-p3-dark);
  border:1px solid #CACACA;
  cursor:pointer;
}
.qq-upload-drop-area {
  position:absolute; top:0; left:0; width:100%; height:100%; z-index:2;
  max-width: 437px;
  background:#FF9797; text-align:center; 
}
.qq-upload-drop-area span {
    display:block; position:absolute; top: 50%; width:100%; margin-top:-8px; font-size:16px;
}

.qq-upload-drop-area-active {background:#FF7171;}
.uploadedfile {
    width: 115px;
    height: 130px;
    margin: 10px 5px 5px 5px;
    border:1px solid #B3B3B3;
    box-shadow: 0px 1px 4px rgba(0,0,0,0.3);
    -moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
    text-align: center;
    background:#ffffff;

}

.uploadedfile .uploadimage {
    margin-top: 5px;
    width: 115px;
    height: 90px;
    display: table-cell;
    text-align: center;
    vertical-align:middle;
}

.uploadedfile .info {
    text-align: left;
    white-space: nowrap;
    margin: 0px 5px 0px 5px;
    overflow: hidden;
}

.progress {
    overflow:hidden;
    margin-top:10px;
  margin-bottom:10px;
    background-color:whitesmoke;
    height:10px;
    -webkit-border-radius:8px;
    -moz-border-radius:8px;
    -ms-border-radius:8px;
    -o-border-radius:8px;
    border-radius:8px;
    background:#eee;
    -webkit-box-shadow:0 1px 0 white, 0 0px 0 1px rgba(0, 0, 0, 0.1) inset, 0 1px 4px rgba(0, 0, 0, 0.2) inset;
    box-shadow:0 1px 0 white, 0 0px 0 1px rgba(0, 0, 0, 0.1) inset, 0 1px 4px rgba(0, 0, 0, 0.2) inset;
}
 .progress .progress-bar {
    float:left;
    width:0%;
    font-size:12px;
    line-height:20px;
    color:white;
    text-align:center;
    background-color:#428bca;
    -webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    box-shadow:inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    -webkit-transition:width 0.6s ease;
    transition:width 0.6s ease;
    -webkit-border-radius:8px;
    -moz-border-radius:8px;
    -ms-border-radius:8px;
    -o-border-radius:8px;
    border-radius:8px;
    -webkit-box-shadow:none;
    box-shadow:none;
    height:8px;
}
.progress-bar span{
    position:absolute;
    width:1px;
    height:1px;
    margin:-1px;
    padding:0;
    overflow:hidden;
    clip:rect(0 0 0 0);
    border:0;
}
.progress-blue {
    background-image:-webkit-gradient(linear, left 0%, left 100%, from(#9bcff5), to(#6db9f0));
    background-image:-webkit-linear-gradient(top, #9bcff5, 0%, #6db9f0, 100%);
    background-image:-moz-linear-gradient(top, #9bcff5 0%, #6db9f0 100%);
    background-image:linear-gradient(to bottom, #9bcff5 0%, #6db9f0 100%);
    background-repeat:repeat-x;
    border:1px solid #55aeee;
}

.xfieldimagegallery {
  margin: 0;
  padding: 0;  
  list-style: none;
  clear: both;
}

.xfieldimagegallery li {
  list-style: none;
  margin: 0;
  padding: 0;  
}

.xfieldimagegallery li img {
  float: left;
  margin-right: 5px;
  border: 5px solid #fff;
  width: 100px;
  height: 100px;
  transition: box-shadow 0.5s ease;
}

.xfieldimagegallery li img:hover {
  box-shadow: 0px 0px 7px rgba(0,0,0,0.4);
}

.btn.disabled, .btn[disabled], fieldset[disabled] .btn {
    cursor:not-allowed;
    pointer-events:none;
    opacity:0.65;
    filter:alpha(opacity=65);
    -webkit-box-shadow:none;
    box-shadow:none;
}





.lbContainer img {max-width: 100%;}
      
 .seoPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #c30042;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}  

.bizPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #8bc34a;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}

.trafficPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #ff9800;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}

.smmPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #673ab7;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
	 
	 
	 
.vkPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #6e81ec;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
} 



.inPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #ff7aa7;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}



.tgPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #03a9f4;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
	 
	 
 
	 
.okPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #ff9800;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}



.ytPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #ff0000;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}


.twPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #00bcd4;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}


.fbPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #3f51b5;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}


.tkPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #060606;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}



.disPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #b52b00;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}




.picPrefix {
	vertical-align: 1px;
	
	font-size: 13px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #607d8b;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}


.artPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #7c59c0;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
.trmatPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #025356;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
.fontsPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #44494c;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
.shabPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #a5320e;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
.addonsPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #168e1b;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}

.webdevPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:   var(--color-primary-p3-dark);
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}


.webdeviPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #333;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}


.langPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #36a6ff;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}

.langcPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #9bc0dd;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
	
	
	
.progPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #9C27B0;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
.adminPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #a70404;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
.scriptsPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #0097a7;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}
.dbPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #9C27B0;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}



.sportPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #26a308;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	
	
	
.investPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #006064;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	
	
	
.foodPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #4c7b92;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	
	


.razvitiePrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #3082c3;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	
	
	
.psiholPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #e91e63;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	

	
.schoolPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  brown;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	

	
.raznoePrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #333;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}		
	
	
	
.vospPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}		
	
	
	
.putPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	
	

.avtoPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}		
	
	
	

.freePrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	
	
.kriptaPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #928e0c;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	


.remontPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	


.azartPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	


.literPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	


.kopirPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	


.imidjPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	


.fokusPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	



.musicPrefix  {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}		




.ezokPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}		
	
	
	
	
	
.pickupPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #E53935;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	




.ezokPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #90a4ae;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	



.infoPrefix {
	vertical-align: 1px;
	
	font-size: 11px;
	text-decoration: none;
	color: #ffffff;
	position: relative;
	padding: 3px 6px;
	font-weight: 400;
	margin-bottom: 5px;
	background:  #F44336;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px !important;
}	






	
	 
.caticon i {
	color: #ffffff !important;
}  
	   
	  
.favspan {    position: relative;
    top: 5px;
    text-align: center;
    font-size: 14px;
    font-weight: bold;}  

	

.favmod.active,
.favmod:hover {
	opacity: 1;
}
.favmod.active:hover{
	opacity: .7;
}
.favmod .favmod-add { display: block !important;}
.favmod .favmod-unset {display: none !important;}

	
.favmod.active .favmod-add {display: none !important;}	
.favmod.active .favmod-unset {display: block !important;color:red;}


/*navigation*/
.pages {margin:0 0 20px 0px; position:relative; }
.pages b {display:none}
.pages-prev, .pages-next {text-align:center;display:block; position:absolute; top:0; left:0; width:36px; height:36px; line-height:36px;font-size: 28px;}
.pages-next {left:auto; right:0}
.pages-prev > a, .pages-next > a, .pages-prev > span, .pages-next > span {display:block; border-radius:3px;}
.pages-prev > a, .pages-next > a {background: #eee0; border: 1px solid #939393; color:  var(--color-primary-p3-dark); border-radius: 25px; font-size: 22px;}
	
.pages-prev > a:hover, .pages-next > a:hover {background:#ffa7a7}


 .pages-prev > span i, .pages-next > span i {top: 2px;position: relative;}
 .pages-prev > a i, .pages-next > a i {top: 2px;position: relative;}
.pages-prev > span, .pages-next > span {background: #eee0; border: 1px solid #939393; color:  var(--color-primary-p3-dark); border-radius: 25px; font-size: 22px;}
.pages-numbers {text-align:center;}
.pages-numbers > a, .pages-numbers > span {display:inline-block; margin:0 2px; margin-bottom:2px;line-height: 36px; width:36px; height:36px;	text-align:center; border-radius:25px;font-size: 13px;}
.pages-numbers > span {       
    background: #e1ffe3;
    border: 1px solid #aeffb3;
    color:  var(--color-primary-p3-dark);}
.pages-numbers > a {       
    color:  var(--color-primary-p3-dark);
    background-color: #eee0;
    border: 1px solid #9f9f9f;}
.pages-numbers > a:hover {background: #ffa7a7;}

.pages-numbers-m {display: inline-block;margin: 0 2px;margin-bottom: 2px;line-height: 36px;text-align: center;border-radius: 25px;font-size: 16px;padding-right: 7px;padding-left: 7px;width: auto;height: auto;background: #eff1fb;border: 1px solid #eff1fb;font-weight: bold;}


.bbCodeSpoiler-button {display: none;}

.link--internal {display: none;}






@media screen and (max-width:868px) {
.pages-prev, .pages-next {
    text-align: center;
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    width: 28px;
    height: 28px;
    line-height: 28px;
}

.pages-prev > a, .pages-next > a {
    background: #eee0;
    border: 1px solid #939393;
    color:  var(--color-primary-p3-dark);
    border-radius: 25px;
    font-size: 18px;
}

.pages-numbers > a, .pages-numbers > span {
    display: inline-block;
    margin: 0 2px;
    margin-bottom: 2px;
    line-height: 28px;
    width: 28px;
    height: 28px;
    text-align: center;
    border-radius: 25px;
    font-size: 13px;
}


.pages-next {
    left: auto;
    right: 0;
}


}








.xauthor 
    {   
    border: 1px solid #e7e7e7;
    border-bottom-width: 2px;
    border-radius: 4px;
    margin-right: 5px;
    padding: 15px 10px;
	}
	
	
	
.xauthor:nth-child(3n) 
    {
	border: 1px solid #e7e7e7;
    border-bottom-width: 2px;
    border-radius: 4px;
	margin-right: 0px;
    padding: 15px 10px;	
	}
	
.xauthor:hover {box-shadow: 2px 4px 20px -4px rgba(0, 0, 0, .1);}
.title-autor {margin-left: 30px;font-size: 16px;}


 .lheight16 .author {
	 background-size: 16px 16px;
    height: 16px;
    width: 16px;
	top: 0px !important;
    left: 0px !important;}


	
	 .author-school-jandekspraktikum {
    background: url(/templates/lifesport/images/school/jandekspraktikum.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-skillfactory {
    background: url(/templates/lifesport/images/school/skillfactory.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-mann {
    background: url(/templates/lifesport/images/school/mann.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-kovpak {
    background: url(/templates/lifesport/images/school/kovpak.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-nilova {
    background: url(/templates/lifesport/images/school/nilova.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-revitonika {
    background: url(/templates/lifesport/images/school/revitonika.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-mironova {
    background: url(/templates/lifesport/images/school/mironova.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-baranova {
    background: url(/templates/lifesport/images/school/baranova.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-mitroshina {
    background: url(/templates/lifesport/images/school/mitroshina.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-kurilov {
    background: url(/templates/lifesport/images/school/kurilov.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-lesli {
    background: url(/templates/lifesport/images/school/lesli.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	 .author-school-pak {
    background: url(/templates/lifesport/images/school/pak.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}




  .author-school-lynda {
    background: url(/templates/lifesport/images/school/90_1.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}





    .author-school-udemy {
    background: url(/templates/lifesport/images/school/udemy.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-biznes {
    background: url(/templates/lifesport/images/school/168_1.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-neo {
    background: url(/templates/lifesport/images/school/171_1.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-geek {
    background: url(/templates/lifesport/images/school/geekbraind.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-like {
    background: url(/templates/lifesport/images/school/like1.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	.author-school-otus {
    background: url(/templates/lifesport/images/school/otus.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-ilya {
    background: url(/templates/lifesport/images/school/triski.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-taras {
    background: url(/templates/lifesport/images/school/taras.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-lilia {
    background: url(/templates/lifesport/images/school/lili.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	.author-school-andrey {
    background: url(/templates/lifesport/images/school/112_1.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	.author-school-roman {
    background: url(/templates/lifesport/images/school/puzat.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	.author-school-radis {
    background: url(/templates/lifesport/images/school/radis.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	.author-school-web {
    background: url(/templates/lifesport/images/school/web.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	

	
	.author-school-sales {
    background: url(/templates/lifesport/images/school/sales.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	.author-school-con {
    background: url(/templates/lifesport/images/school/176_1.jpg) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	
	
	.author-school-andreyz {
    background: url(/templates/lifesport/images/school/andreyz.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	
	.author-school-skill {
    background: url(/templates/lifesport/images/school/skill.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
		
	.author-school-maria {
    background: url(/templates/lifesport/images/school/maria.png) no-repeat;
    background-size: 36px 36px;
    height: 36px;
    width: 36px;
    top: -8px !important;
    left: 5px !important;
	}
	
	
	
		

.gamburger:hover{
	cursor: pointer;
}

.gamburger span {
display: block;
    width: 18px;
    height: 1.5px;
    background-color:  var(--color-primary-p3-dark);
    margin: 2px 0px 4px 0px;
    transition: 0.4s;
}

.gamburger span:nth-child(2n) {
    background-color: #333;
}
.firstx{
    -webkit-transform: rotate(-45deg) translate(-3px, 5px);
    transform: rotate(-45deg) translate(-3px, 5px);
}
.middlex{
	opacity: 0;
}
.lastx{
    -webkit-transform: rotate(45deg) translate(-3px, -5px);
    transform: rotate(45deg) translate(-3px, -5px);
}

.dZUe5 {
	opacity: 0;
    visibility: hidden;
    transform: translate3d(0px, -8px, 0px);
    overflow: hidden;
    transition: opacity 0.1s linear 0s, transform 0.1s linear 0s, visibility 0s linear 0.1s;
}

.menu-active{
	visibility: visible;
    opacity: 1;
    transform: translate3d(0px, 0px, 0px);
    overflow: hidden;
    transition: opacity 0.2s linear 0s, transform 0.2s linear, visibility 0s linear;
}





.Gbzyj {
    color:  var(--color-primary-p3-dark);
    background-color: #ffffff;
    position: relative;
    z-index: 99;
    align-items: center;
    left: 0;
    right: 0;
    margin: 0px auto;
    padding: 30px 20px;
    top: -5px;
    border-top: 1px solid #e7e7e7;
    border-bottom: 1px solid #e7e7e7;
	box-shadow: rgba(0, 0, 0, 0.08) 0px 8px 16px 0px;
}



.nav-menu-user-g {
    width: 890px;
    position: relative;
    margin: 0 auto;
	margin-bottom: 25px;
    padding-bottom: 20px;
	border-bottom: 1px solid #e7e7e7;
}

.nav-menu-user-l {
    width: 390px;
    position: relative;
    margin: 0 auto;
	border-bottom: 1px solid #e7e7e7;
}

.nav-menu-user-g ul {
  display: table;
  margin: 0 auto;
  cursor: default;
}

.nav-menu-user-g li {
    float:left;
	margin: 0px 2px;
}



.nav-menu-user {
    width: 890px;
    position: relative;
    margin: 0 auto;
}


.nav-menu-user ul {
  display: table;
    margin: 0 auto;
}

.nav-menu-user li {
    float:left;
	margin: 0px 2px;
}


.lbContainer  {text-align: center;
    align-items: center;}

._1OBDW {
    padding: 35px 40px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 1px 4px 0 rgba(0,0,0,.1);
}

.QnuBX {
    font-size: 16px;
    line-height: 24px;
    
    -webkit-font-smoothing: auto;
    box-sizing: border-box;
    width: 100%;
    background: none;
    padding-left: 10px;
    height: 50px;
    color:  var(--color-primary-p3-dark);
    border: 1px solid #dedde1;
    border-radius: 4px;
}



.QnuBX:focus {
    border-color: #6c43bf;
}

	
._3dpzr {
    font-size: 22px;
    line-height: 30px;
    margin: 0 0 6px;
}


._3YXtk {
    font-size: 14px;
    line-height: 18px;
    margin-bottom: 10px;
}
	
	
	
.DQNDW {
    box-sizing: border-box;
    min-height: 40px;
	height: 45px;
    position: relative;
    margin-bottom: 10px;
}	


._3isCU {
    background-color: #21a038;
}


._3isCU:hover {
    background-color: #137e26;
}



._1APp2 {
    color: #fff;
}


._2h3YP {
    font-size: 16px;
    line-height: 22px;
    
    letter-spacing: 1px;
}
._2h3YP {
    position: relative;
    z-index: 0;
    display: inline-block;
    box-sizing: border-box;
    height: 40px;
    padding: 9px 16px 7px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    line-height: 22px;
    
    letter-spacing: .5px;
    text-decoration: none;
    text-transform: uppercase;
    vertical-align: middle;
    white-space: nowrap;
}

._2SiGN {
    height: 40px;
    padding: 10px 20px;
}





.rn-in-cat-box * {
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
}



.collapse {
  position: relative;
  height: 0;
  overflow: hidden;
  -webkit-transition: height 0.35s ease;
  -moz-transition: height 0.35s ease;
  -o-transition: height 0.35s ease;
  transition: height 0.35s ease;
}
.collapse.show {
  height: auto;
}


.ico-center {display: flex;align-items: center;}
.ico-center i {margin-right: 5px}



.rn-in-more{width:100%;text-align:center;position:relative;margin-top: 25px;}
.rn-in-more:before{content:'';position:absolute;border-bottom:1px solid #e7e7e7;right:0;left:0;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)}
.rn-in-more .rn-in-more-show{display:none}
.rn-in-more a{position:relative;background:#fafafa;display:inline-block;padding:0 20px;font-size: 18px;}
.rn-in-more a:hover{text-decoration: none;}
.rn-in-more a.collapsed .rn-in-more-show{display:inline-block}
.rn-in-more a.collapsed .rn-in-more-hide{display:none}


.mainpage-gallery {
	font-size: 13px;
    margin-top: 15px;
    margin-bottom: 25px;}
	
	

	
.noborder {border-bottom: none !important;}


.headinfobox a, .maincategories .bigsizecat .li .item a>span {font-size: 16px !important;}

.maincategories .bigsizecat .li .item .cat-icon-circle {font-size: 28px !important;}

.cat-bott {margin-bottom: 15px;}

.main-cat h2 {font-size: 14px;}



/* =========== © 2016 Centroarts.com =========== */

.wseditor table, .bb-editor table { margin: 0px; }



/* Частые стили */
.strike { text-decoration: line-through; }
.nobr { white-space: nowrap; }
.hide { display: none; }

.uline { text-decoration: underline; }
.strike { text-decoration: line-through; }
.justify { text-align: justify; }
.center { text-align: center; }
.left { float: left; }
.right { float: right; }
	fieldset { border: 1px solid rgba(0,0,0,0.1); padding: 15px; margin-bottom: 1.5em; }
	fieldset legend { font-weight: bold; }

	.grey { color: #999; }
	.grey a { color: inherit; }
	.grey a:hover { color: #1a1a1a; }

	.green { color: #95c00e; }

sup { vertical-align: super; font-size: smaller; } 
.over { display: inline-block; vertical-align: middle; max-width: 100%; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }
a .over { cursor: pointer; }

.cover { background-position: 50% 50%; background-repeat: no-repeat; -webkit-background-size: cover; background-size: cover; }


/* --- Деление на колонки --- */
@media only screen and (min-width: 701px) {
.grid_1_2, .grid_1_4 {
	float: left; margin-right: 4%;
	-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
	.grid_1_2 { width: 48%; }
	.grid_1_4 { width: 22%; }
	.grid_last { margin-right: 0; }
}

/* --- Работа вкладок --- */
.tab-content > .tab-pane { display: none; }
	.tab-content > .active { display: block; }

/* --- Иконки --- */
.icon {
	display: inline-block;
	width: 32px;
	height: 32px;
	fill: #1a1a1a;
	vertical-align: middle;
}
	.icon-logo { width: 40px; height: 40px; }

	.icon-vk { width: 10px; height: 1em; }
	.icon-tw { width: 14px; height: 1em; }
	.icon-fb { width: 8px; height: 1em; }
	.icon-gp { width: 18px; height: 1em; }
	.icon-ya { width: 7px; height: 1em; }
	.icon-od { width: 10px; height: 1em; }
	.icon-mail { width: 16px; height: 1em; }

	.icon-coms { width: 17px; height: 16px; }
	.icon-view { width: 17px; height: 15px; }
	.icon-author { width: 13px; height: 14px; }
	.icon-reply { width: 17px; height: 15px; }
	.icon-compl { width: 17px; height: 9px; }
	.icon-del { width: 13px; height: 13px; }
	.icon-loc, .icon-phone { width: 21px; height: 27px; }
	.icon-login { width: 34px; height: 38px; }
	.icon-login_m, .icon-sort_m { width: 24px; height: 26px; }
	.icon-sort { width: 30px; height: 31px; }
	.icon-arrow_left, .icon-arrow_right { width: 12px; height: 21px; }
	.icon-left, .icon-right { width: 36px; height: 21px; }


	/* Редактировал... */
	.editdate {
		
		font-style: italic;
	}

	


	/* Вложения */
	.attachment > a { color: inherit; display: block; margin: .4em 0; }
	.attachment > a > .icon { fill: #95c00e; width: 16px; height: 17px; margin: -.2em .6em 0 0; }

	/* Важная новость */
	.fixed_label {
		font-size: 11px;
		font-weight: bold;
		text-transform: uppercase;
		border-radius: 3px;
		padding: 4px 7px;
		background-color: #fcf5d1;
		color: #976318;
		margin-right: 1em;
	}


		.rate_like > a, .rate_like-dislike {
			float: left;
			height: 23px; line-height: 23px;
			padding: 6px;
			text-decoration: none !important;
			font-weight: bold;
			color: #999;
			-webkit-transition: all ease .2s; transition: all ease .2s;
		}
		.rate_like .icon { width: 15px; height: 14px; margin: -2px .3em 0 0; }
		.rate_like > a { color: #95c00e; }
		.rate_like > a .icon { fill: #95c00e; }
		.rate_like > a:hover { opacity: .8; }

		.rate_like-dislike > a {
			display: inline-block;
			width: 23px; height: 23px;
			text-align: center;
			opacity: .6;
		}
		.rate_like-dislike > a:hover { opacity: 1; }
		.rate_like-dislike .ratingplus { color: #95c00e; }
		.rate_like-dislike .ratingminus { color: #e75820; }
		.rate_like-dislike > span { vertical-align: middle; cursor: default; padding: 2px; }

		/* Иконки Плюс и Минус */
		.plus_icon, .plus_icon > span { width: 15px; height: 15px; }
		.plus_icon { border: 4px solid transparent; display: inline-block; vertical-align: middle; position: relative; }
		.plus_icon > span, .plus_icon > span:before, .plus_icon > span:after {
			overflow: hidden;
			text-indent: -9999px;
			white-space: nowrap;
			position: absolute;
			border-radius: 2px;
		}
		.plus_icon > span:before, .plus_icon > span:after { background-color: #1a1a1a; content: ""; }
		.plus_icon > span { left: 0; top: 0; }
		.plus_icon > span:after {
			left: 0; top: 0;
			width: 100%; height: 3px;
			margin-top: 6px;
		}
		.plus_icon > span:before {
			left: 0; top: 0; 
			width: 3px; height: 100%;
			margin-left: 6px;
		}
		.plus_icon.minus > span:before { display: none; }

		
/* --- Комментарии --- */
/* Формы на UL */
ul.ui-form { list-style: none; padding: 0; margin: 0; }
	ul.ui-form > li { margin-bottom: 20px; }
	ul.ui-form > li:last-child { margin-bottom: 0; }
	.form-group { margin-bottom: 20px; }
	.form-group > label { display: block; margin-bottom: 20px; }
	.form-group.imp > label:after { content: "*"; margin: 0 0 0 10px; color: #e85319; }

	@media only screen and (min-width: 601px) {
		.form-group.combo:after { clear: both; display: table; content: ""; }
		.form-group.combo > .combo_field { width: 50%; float: left;
			-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
		}
		.form-group.combo > .combo_field:last-child { padding-left: 10px; }
		.form-group.combo > .combo_field:first-child { padding-right: 10px; }
	}
	@media only screen and (max-width: 600px) {
		.combo_field { margin-bottom: 20px; }
	}
	.form_submit { margin-top: 20px; }
	.form-sep { border-top: 1px solid #efefef; }

	/* Модификация BB редактора для комментариев */
	#comment-editor .bb-editor textarea { height: 140px; }
	.addpm #comment-editor .bb-editor textarea { height: 340px; }

	/* Страницы с формами */
	.regtext { margin-bottom: 1.5em; }
	.login_check { position: relative; }
	.login_check > input { padding-right: 120px; }
	.login_check > .btn {
		width: 100px;
		height: 28px;
		padding: 2px 8px;
		position: absolute;
		right: 0;
		top: -3px;
		font-weight: bold;
		font-size: 11px;
		margin: 5px;
		background: #fff;
		color: #3d55ef !important;
	}
	
	.login_check > .btn:hover {
    color: #fff !important;
    text-decoration: none;
    background-color: #95c00e;
}

/* Комментарии: Оформление блока со списком комментариев */
.comments_box { background-color: #95c00e; padding: 13px; position: relative; }
	.comments_box_in {
		border-radius: 8px;
		background-color: #fff;
		padding: 37px;
		box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
		position: relative;
	}
	.comments_box_in:after, .comments_box:after { content: ""; position: absolute; top: 0; left: 0; margin-left: 288px; border: solid transparent; border-width: 0 31px 31px 0; }
	.comments_box:after { margin-top: -31px; border-bottom-color: #95c00e; }
	.comments_box_in:after { margin-top: -13px; border-bottom-color: #fff; }
	.comments_box_in .block { padding: 0; margin-top: 37px; margin-bottom: 0; }

	.comments_box_in > .title { text-transform: uppercase; margin-top: 0; }

/* Комментарии: Оформление */

#dle-comments-list 
{
	margin-top: 40px;
}


#addcomment h4 {
	font-size: 18px;
	margin-top: 20px;
    margin-bottom: 20px;
    font-weight: bold;
	}

.comment {
    margin-bottom: 50px;
    position: relative;
    border: solid 1px #ebebeb;
    padding: 0px;
}

	.comments_box_in .comment { margin-top: 37px; margin-bottom: 0; }

	/* Аватарка */
	.avatar { display: inline-block; }
	.avatar .cover {
		width: 100px; height: 100px;
		border-radius: 50%;
		white-space: nowrap;
		text-indent: -9999px;
		display: inline-block;
	}

	/* Верхняя часть комментария */
	.com_info {
	    border: 1px solid #eaeaea;
        height: 35px;
        margin-bottom: 1.5em;
        background: #fff;
        position: relative;
	}
		.com_info:after { clear: both; display: block; content: ""; }

		.com_info .avatar { float: left; margin: -6px 15px 0 -6px; }
		.com_info .avatar .cover { width: 41px; height: 41px; border: 5px solid #1a1a1a; }

		.com_user { float: left; margin-top: 9px; }
		.com_user > .name { margin-right: 20px; }
		.com_user > .name a { color: inherit; }

		.com_info > .rate { float: right; margin: 2px 10px 0 0; }
		.com_info > .rate .rate_stars { margin: 5px 2px 0 0; }
		.com_info > .rate .rate_like-dislike { margin-top: -2px; }
		
		.comment .status {
			position: absolute;
			left: 0;
			margin: 17px 0 0 -24px;
			overflow: hidden;
			text-indent: -9999px;
			background-color: #95c00e;
			width: 7px; height: 7px;
			border-radius: 50%;
		}
		.status.offline { background-color: #e75820; }
		.comment.online .status.offline, .status.online { display: none; }
		.comment.online .status.online, .status.offline { display: block; }

		.com_tools { margin: 1.5em 0 0 0; font-size: .9em; }
		.com_tools .edit_btn, .com_tools .mass { float: right; margin-top: -3px; }
		.com_tools .mass input { margin: 4px 0 0 10px; }
		.com_tools_links { display: inline; }
		.com_tools_links > a { margin: 0 2em 0 0; }
		.com_tools_links > a > .icon { margin: -3px 8px 0 0; }

	/* Древовидные комментарии */
	.comments-tree-list { padding: 0; margin: 0; list-style: none; position: relative; }
		.comments-tree-list .comment { position: static; margin: 0; }
		.comments-tree-list .comment:before {
			content: "";
			position: absolute;
			left: 0;
			width: 100%; height: 3px;
			background: #bababa;
			margin: 19px 0 0 0;
			background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAGBAMAAABDdsEYAAAAD1BMVEX///+6urrZ2dm/v7/9/f2Xp6s6AAAAHUlEQVQI12NwMlZhwACKgkKYgoaCwjgFCWvHahEArAICZfxDRiQAAAAASUVORK5CYII=);
			background-size: auto 3px;
			z-index: -2px;
		}
		.comments-tree-list .comments-tree-list { padding-left: 20px; position: static; }
		.comments-tree-list > li { margin-top: 37px; }

		/* Управление комментариями */
		.mass_comments_action {     display: none;}
		.block .mass_comments_action { padding-left: 0; padding-right: 0; }
		.comments_box_in .mass_comments_action { padding-left: 0; padding-right: 0; margin-top: 37px; }
		.mass_comments_action > select { padding: 5px; width: 200px; margin-left: 1em; }


.dle-comments-list {    
    background: #ffffff;
    border-radius: 10px;
    margin-bottom: 7px;
    padding: 40px;
	}
	
	
	
	
	
	
	

	
/* --- Страница пользователя --- */
.userinfo_top { position: relative; padding-bottom: 50px; margin-bottom: 50px; }
.userinfo_top .avatar { position: absolute; }
.user_tab { list-style: none; padding: 0; margin: 0; }
	.user_tab > li { display: inline; margin-right: 1.2em; }
	.user_tab > li > a {
		text-decoration: none !important;
		font-size: .6em;
		-webkit-transition: all ease .3s; transition: all ease .3s;
	}
	.user_tab > li > a { color: #fff; opacity: .5; }
	.user_tab > li > a:hover { color: inherit; }
	.user_tab > li.active > a { cursor: default; font-size: 1em; opacity: 1; }

	.usinf { list-style: none; padding: 0; margin: 0 0 25px 0; } 
	.usinf li { padding: 12px 0; border-top: 1px solid #e6e6e6; }
	.usinf li:first-child { border-top-width: 0; }

	.ui-c1, .ui-c2 { display: inline-block; vertical-align: top; }
	.ui-c1 { width: 30%; margin-right: 5%; }
	.ui-c2 { width: 60%; }

	/* Окно пользователя */
	.userinfo { padding-left: 90px; }
	.userinfo .avatar { position: absolute; float: left; margin: 0 0 0 -90px; }
	.userinfo .avatar .cover { width: 60px; height: 60px; }
	.userinfo > ul { list-style: none; padding: 0; margin: 0; }

	.dark_top {
		border-radius: 2px 2px 0 0;
		color: #fff;
		background: #2c2c2c;
	}
	
	
	
	


@media screen and (max-width:868px) {
.userinfo_top .avatar {display:none;}
.ui-c1 {width: 100%;margin-right: 0;}
.ui-c2 {width: 100%;margin-top: 10px;border-top: 1px solid #f1f1f1;padding-top: 10px;}
.userinfo_top {margin-bottom: 0px;}
.story .title {margin: 0px;margin-bottom: 20px;}
}
	
	
	
	
	
.maincategories {text-align: left;}	
	
.maincategories .maincategories-list .li .item .titlecatmenu {
-ms-text-overflow: ellipsis;
-o-text-overflow: ellipsis;
text-overflow: ellipsis;
overflow: hidden;
-ms-line-clamp: 2;
-webkit-line-clamp: 2;
line-clamp: 2;
display: -webkit-box;
display: box;
word-wrap: break-word;
-webkit-box-orient: vertical;
box-orient: vertical;
line-height: 22px;
}

.maincategories .maincategories-list .li .item .titlecatmenux {
-ms-text-overflow: ellipsis;
-o-text-overflow: ellipsis;
text-overflow: ellipsis;
overflow: hidden;
-ms-line-clamp: 2;
-webkit-line-clamp: 2;
line-clamp: 2;
display: -webkit-box;
display: box;
word-wrap: break-word;
-webkit-box-orient: vertical;
box-orient: vertical;
line-height: 18px;
}

.callout-title {

  animation-delay: 0.25s;


}



.callout-subtitle {
  margin-top: 0;

  animation-delay: 0.3s;

  color: var(--c-secondary);
}


.descdiv {font-weight: bold;margin-bottom: 20px;}
.descdiv div {margin-right: 10px;}
 .descdiv h1 {font-size: 23px;}
 .descdiv h2 {font-size: 16px;}




@media screen and (max-width:1063px) {
 .descdiv h1 {font-size: 20px;}
 .descdiv h2 {font-size: 14px;}
}

@media screen and (max-width:868px) {
 .descdiv h1 {font-size: 18px;}
 .descdiv h2 {font-size: 13px;}
}










.secdiv1 {
  --animate-duration: 0.5s;
}

.secdiv2 {
  --animate-duration: 2s;
}

.secdiv3 {
  --animate-duration: 2.5s;
}


/* === Стол заказов === */

.orderdesc-h{
	font: bold 18px/30px Calibri;
	color: #333;
}
.orderdesc-add{
	float: right;
	height: 30px;
	padding: 0 20px;
	border: 1px solid #127ad0;
	background: #127ad0 url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAeCAIAAABi9+OQAAAAKUlEQVQImWNwnHqTiYGBgenPv/9MDAwMTH/hNAMq/z8aH0r/IVIdmnkANWQmm4eB2ycAAAAASUVORK5CYII=') repeat-x 0 0;
	border-radius: 2px;
	cursor: pointer;
	color: #fff;
	font-weight: bold;
	text-shadow: 0 1px 3px rgba(0,0,0,.5);
}
.orderdesc-add:hover{
	background: #127ad0;
}
.orderdesc-add-area{
	display: none;
	clear: both;
	margin-top: 15px;
	background: #eee;
	padding: 5px 10px;
	border-radius: 3px;
}
.orderdesc-add-area-row{
	padding: 10px 10px 10px 150px;
	border-bottom: 1px solid #e0e0e0
}
.orderdesc-add-area-row:last-child{
	border: none;
}

.orderdesc-add-area-row:after{
	content: "";
	display: table;
	clear: both;
}
.orderdesc-add-area-row-t{
	float: left;
	margin-left: -140px;
	padding-top: 6px;
	font: bold 14px Calibri;
	color: #333;
}
.orderdesc-add-area-row-input{
	width: 450px;
	height: 30px;
	border: 1px solid #ccc;
	border-radius: 3px;
	padding: 0 15px;
}
.orderdesc-add-area-row-input:focus{
	border-color: #3a89c3;
	box-shadow: 0 0 3px rgba(60,140,200,.5);
}
.orderdesc-cancel,
.orderdesc-doadd{
	padding: 5px 25px;
	cursor: pointer;
	margin-right: 7px;
	color: black;
}
.orderdesc-cancel:hover,
.orderdesc-doadd:hover{
	box-shadow: 0 0 3px rgba(60,140,200,.5);
}

.orderdesc-related{
	display: none;
	margin: 10px 0 0;
	list-style: none;
	background: #fff;
	padding: 10px;
	border: 1px solid #ddd;
	box-shadow: 0 2px 5px rgba(0,0,0,.1);
	width: 460px;
	border-radius: 3px;
}
.orderdesc-related li{
	height: 22px;
	line-height: 22px;
	border-bottom: 1px solid #eee;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}
.orderdesc-related li:first-child,
.orderdesc-related li:last-child{
	border: none;
}
.orderdesc-related-h{
	text-align: center;
	font-weight: bold;
}

.orderdesc-statusinfo{
	list-style: none;
	padding: 0 5%;
	margin: 10px 0 0;
}
.orderdesc-statusinfo:after{
	content: "";
	display: table;
	clear: both;
}
.orderdesc-statusinfo li{
	float: left;
	width: 20%;
	font: normal 12px/22px Arial;
	color: #444;
	text-align: center;
}
.orderdesc-statusinfo li a,
.orderdesc-statusinfo li a:hover{
	text-decoration: none;
}
.orderdesc-statusinfo li a:hover span{
	text-decoration: underline;
	color: #ff5f43;
}





@media screen and (max-width:1063px) {

.orderdesc-add-area-row-input{
	width: 100%;
}

.orderdesc-add-area-row-t {
    float: none;
    margin-left: 0;
    padding-top: 5px;
    width: 100%;
}

.orderdesc-add-area-row {
   padding: 20px 5px;
}

.orderdesc-related {
    width: 100%;
}


}

@media screen and (max-width:868px) {

.orderdesc-add-area-row-input{
	width: 100%;
}

.orderdesc-add-area-row-t {
    float: none;
    margin-left: 0;
    padding-top: 5px;
    width: 100%;
}

.orderdesc-add-area-row {
   padding: 20px 5px;
}

.orderdesc-related {
    width: 100%;
}

}








.od-all,
.od-wait,
.od-done,
.od-deny,
.od-top{
	display: inline-block;
	height: 22px;
	width: 22px;
	background-repeat: no-repeat;
	background-position: 0 0;
	background: #f0f0f0;
	vertical-align: bottom;
}

.od-all{
	background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAAAAADh3zPnAAAApklEQVR42mP4gA08ZaCq8K35nZ2zz6EJv5ro5paR4ebS+AxZ+FFc0FYQvTUo7AqScF7MI4iuRzFxb+DCO91Owaw45bYULtxYjXBEdQ5cOGopQnipB1w4YCNCeKPLM5hwwmyE8FwfuOreNIRwWjlc+IrbVpjoVpf9CHdP9TkGET3mU4/knXetbp0nPnw40elW+golqDbHuQBB2PJ36AF7Y//uK9SNHQAeuqDkUdpBpwAAAABJRU5ErkJggg==');
}
.od-wait{
	background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAAAAADh3zPnAAAAXklEQVR42mP4gA08ZaCL8IUIt+VYhEtdXDyeYQrHuLi4XMAUzgMK38AUnu3iEoTF7AduLpOxObA77Ak24XePsLn7RW/pOSzCvS4uYViEa11cvN5g8XyYx2o6hzeKMADqkq62n/RA2wAAAABJRU5ErkJggg==');
}
.od-done{
	background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAAAAADh3zPnAAAAVElEQVR42mP4gA08ZRh44XdYhc8FzMYifC7AxesZhjBI9DCS6ul5L5BFocJnXFxyXiCJwlRPBYofQ4jCzQaKuyBEEVZORRZFckk/kiiyA+8NcHgDAJWdq89/NheVAAAAAElFTkSuQmCC');
}
.od-deny{
	background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAAAAADh3zPnAAAAaUlEQVR42mP4gA08ZRg44RMXQOSrjajCJ7x8TgFFc1z6UYTP+bj4nACKukxGMwQonuYCVYxkJVAcLook/Aqo1u0UujDIXDcXn1Oowi+Aov0g80+gCK8HmwsUz0E1pHcq2N68ewMesGjCAB57pGIv6y4lAAAAAElFTkSuQmCC');
}
.od-top{
	background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAAAAADh3zPnAAAAv0lEQVR42mP4gA08ZaBE+N3DW2+wCD+eU3kDi/CDCbmXsQg/7Mu5hC789MqrhxMwhF9vTrjwaEIuhvDKyBOP+lCFn194+XplxAk0s9/vDzgNUv2wPwfukncv37/f7nsUJPygH+HAu+sfw4X74MLvdsader/D9whYGOGdd1sjj0FVH3uIcMm7bVEngMKHIVYihA+nXXy/1/vU6/VxZx9PK74Gs/LltdcfXpx7+f7B0edvrx5/iR4m798Btb4lI9IA15afFB34FCYAAAAASUVORK5CYII=');
}

.orderdesc-related li .od-deny,
.orderdesc-table td .od-deny{
	cursor: help;
}

.orderdesc-table{
	margin-top: 10px;
	width: 100%;
	border-top: 1px solid #ccc;
	border-collapse: collapse;
}
.orderdesc-table tr:nth-child(odd){
	background: #fafaff;
}
.orderdesc-table tr:hover{
	background: #eee;
}
.orderdesc-table td{
	height: 22px;
	margin: 0;
	padding: 0;
	text-align: center;
	font: bold 11px/22px Arial;
	color: #666;
	border-bottom: 1px solid #ccc;
}
.orderdesc-table td.od_td_title{
	text-align: left;
	padding: 2px 0 2px 10px;
	height: 18px;
	line-height: 18px;
}

.orderdesc-rating{
	width: 100%;
	font-weight: bold;
	height: 22px;
	line-height: 22px;
	display: block;
	background:#eee;
	color: #999;
	cursor: pointer;
	border-radius:1px;
}
.orderdesc-rating-green{
	text-shadow: 0 1px 3px rgba(0,0,0,.3);
	background: #74b52f url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAWCAIAAACOpGH9AAAAJElEQVQImWNoOmXGxMDAwPTv338mBgYGpv9wmgGvOIz/D7s4AAAVHIUkUImVAAAAAElFTkSuQmCC') repeat-x 0 0;
	color: #fff;
}
.orderdesc-edit{
	font: normal 10px Arial;
	color: #d28c00;
}
.orderdesc-edit:hover{
	color:  var(--color-primary-p3-dark);
}
#orderdesc-edit{
	padding: 10px !important;
}

.orderdesc-navigation{
	clear: both;
	margin-top: 15px;
	text-align: center;
	font: normal 12px Arial;
	color: #999;
}
.orderdesc-navigation *{
	display: inline-block;
	margin: 0 2px 4px;
	padding: 7px 5px;
	border: 1px solid #eee;
	border-radius: 2px;
}
.orderdesc-navigation a{
	border-color: #bedbf1;
}
.orderdesc-navigation a:hover{
	color: #1e6faa;
	text-decoration: none;
	border-color: #3a89c3;
	box-shadow: 0 0 3px rgba(60,140,200,.5);
}

.show-alerts{
	position: fixed;
	top: 0;
	right: 0;
	z-index: 9999999;
}
.show-alerts>div{
	background: #eee url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAgCAIAAABch4VNAAAAGklEQVQImWP49esXEwMDA9P///+x0jBMI3kAMQInCeNawiQAAAAASUVORK5CYII=') 0 0 repeat-x;
	padding: 10px 15px;
	box-shadow: 0 2px 7px rgba(0,0,0,.2);
	border-left: 3px solid #f00;
	border-radius: 1px 0 0 1px;
	margin-top: 20px;
	color: #333;
	text-shadow: 0 1px 3px #fff;
	white-space: nowrap;
	display: none;
	width: auto;
	float: right;
	clear: both;
	cursor: default;
	-moz-box-sizing: content-box;
	-webkit-box-sizing: content-box;
	box-sizing: content-box;
}
div.showLoad{
	display: block;
	height: 28px;
	width: 28px;
	background: url('data:image/gif;base64,R0lGODlhHAAcAPUGAPz+/PTy9Pz6/PT29Ozu7Ozq7CQiJCQmJFRSVHR2dDQ2NISGhGRmZFRWVNTS1NTW1ERGRCwqLKyqrMzKzFxaXNza3MTGxExKTKSmpHx6fDw+PLy+vDw6PCwuLMzOzNze3IyKjOTi5JyenIyOjJSSlOTm5Hx+fLS2tERCRJSWlGRiZHRydKyurGxubFxeXMTCxLSytLy6vP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFBQAGACwAAAAAHAAcAAAGnECDcDgUBAiFZIEQEBCfUMNASa0Ook8BsspVOrGC7nLLvUKn1nM5WyVghWilWUguzN+A6jBufz/zckJUd35wVAZhSoVRZAMBgYtPcQRkkVFdbpZPmJpPdUmZnXRcoaKfSaJDVI2pk4lLqayDna8FhkoAloCgqlS5hVqHe2lvtX1EfEtfRMGrUcmgAUecWNBiSYSM10qliwOnBNlDQQAh+QQFBQAFACwAAAAAHAAcAAAGucCCcEgcliKKxmIiKDqdpUK0ZKhWIZLmEyrtWr8JwNbYLREIgQRDcageJuOyNKAdAhyJw2haL0YLfU4VJVOAXARicUIEXYxEf4mKhoVkJYGSXZUBmEUBfEJRl5xRAQR/nE6mBY6nqEOehSWbrlyktK+EoLdbjK20pmaeUqKKAn90U7O3hFqfrlOOustCA0O9q5iJUdGTXcSP3k+FAdXiZaJNsdzXf+VPAqqxctvfQ+Xy0O6YAqWZaN9BACH5BAUFAAAALAAAAAAcABwAAAayQIBwSBwWDsWkklhoNpfQYvMzPRiuWMQjCnA6CYRM8drZLJ1UwgCKPZiV1MIa+oBgO5VkgUskUKwGCAJMHwR8QwQQgBhGTXOHAA9WHSNCU4aQQyAjFXKWnplCAl8EBYWhhEyofaVemKsBXmmrQqVxe7RnuV1PXVS0A1MDwU2vmbGOn6CZprhDH7TOUqumSs18xL3WX4PbzY9ExLfSXtJLA62m6Wjq4FzszeaH6JaFYO5EQQAh+QQFBQABACwRAAQACwAXAAAGR0BPYEgsFg/GpCFZvDCVkEEycTAYLMmH1bBIAjhWBJNhVTAzVmQSbVAbF4qDOUkoVITPAuH5eQYKfgF9foB8e0yFTIOIhE9BACH5BAUFABAALAEAAgAbABoAAAaIQIhwOKwUChWicskkDhLNqDDZdEiJFQLhKjRwv8JDkwruls/TAdq8XjrExbZQcTA05GM1XljYY7dyDAYGCoBtAByDCEcFemdvgwtIhmcJgwYWlGcPEYMaen1nAxeXGHyTZwuKjqeNUgKMIh1kRZpLAYyMTASoUkavWrnCv2dGxpO2XAADWrxfQQAh+QQFBQACACwRABQACQAIAAAGKkCBUBAYGgMUg1HwuBieTEci8jQcNgJN1dDBClbVS2XIMkAwAGPBMlgKggAh+QQFBQABACwBAAIAGwAaAAAGdcCAcDj8CI3EpHI5JGSY0GN0WiwUqNjsFKmFHLTgIyEs/JKVDwORS+aoEWdoYRwv1pPW+/CqtwvOant8d4NkB2Z2fWN5fQFIf4SFSQBlVFcflygMGRkMblkDAXwYBwamp0MID1gFLaevQ6FYAykNCocKDQtRQQAh+QQFBQAKACwAAAAAHAAcAAAGkUCFcEgcliLFpJJYKjRLy2jx6SwYpFFqiUAIJLBJbUCQ9ICNhQIZe5BCz4pAI5uGxyHXqXNtDzsDfUN5aHx2Hm1oBYFDGgYGDWlvi3olgJN6lotfRpdLkp1CT5eICgJPmaBPhXCDnKBTIC6okyUrjhcPoIeOBgcJDgCXGx28jhqdFQjFrYsDGHjMRcFnAxYLgUEAIfkEBQUAAQAsAAAAABwAGwAABovAgHBIHBYOxaSSWGg2l9Bi8zNFRpdOJ4GQuSadVMIg6fAOqYXx1RAtmIUECrTwIbwDBIiV2VTfv3R2f0J7Qn2DAQ9sRnWIQhwGBghOjoAFgpVnl5VdZxYvmUMMBwYcAKEBC5EGZYiLARarCagCKJEHD6gYqxB+d3sCCKtyoQ8dr6gbB4Wozc6ovkJBACH5BAUFAAUALAAAAgAaABkAAAZhwIJwSKwIjcSkcikcJJjQAjJKrRAI1Kw2O91eDGBBZrOFWsANS1m5ABsca6EDDdYA4kLFQQFm4IkHYE9/QoEGg4R8Bn6EBQh1fwIajZRUGgeVSRcBmWVYmJWgnaOklXdDQQAh+QQFBQALACwBAAEAGQALAAAGT8CFcDgMFQqhA3HJrJCOUKOBSV1sOoaTMUToVpmbiMGA4gK+1Ap2DAmhqQLE2NAYvBeDBhEzh9jvCwEQB2xjBw+AXwYJiUtTjXcKkEQaBkEAIfkECQUAAwAsBgAAABYAHAAABk3AwUAwWTQUEaFyyRRIIIaolEkVIqTYqharYCS0VcMh4QCAwY/zOaAeBChUdntOFwrq+Lx+z+/7/4CBfXeCYAENS4SFi4xKinyPVJFKQQAh+QQJBQAeACwGAAAAFgAcAAAG20CPRzBZNBSRQoEQEAifUIEEYqhWldjCAPpEWL+FSpighFW4X4OCkSAMyOFHp7OBVg8JB4A7GBQYBwYRdUIGEA9cXAQXVh1nHg1biYoUgQYITpKTioxVGJugD5YQmqBcCVYWppMOVguriQAaVQ2wiQxVCrZcGXe7UL0GB79PuGrEQ7OXyK1Vr8SoVaq/olUaAwG7AZ0HnxTZqwSVVQhbBheIoReWHel3eXtPAA4JlsKEHmkaDBkZDBxp6EDxkqYguXRPBmCgYrAKBAzxEg2wYETBgQMKGiywUApKEAAh+QQJBQAeACwGAAAAFgAcAAAG2kCPRzBZNBSRQoEQEAifUIEEYqhWldjCAPpEWL+FSpigJDihX4OCkSAMyGPl9lk9JBwA7mCgrJDnHgYQD1x6cEpnDYCFTwBkfgRCi4xPb1iTlFB8BUVnmYUPDAcHFp+MDlYLpoUACgcGCKuFDFUKslwZdbdQGa8Hu0+0asBDGlWxwKhVqsAJVqW7D68GGgMBtwEXdRgeFNemBBTTCFsGF4SZDxfTHeh1d3mNDgnTBgcbdF8aDBkZDBxpOuDrkqagFQToKmGgYrAKBAzxCg2wYMTVAQUNFljAJCQIACH5BAkFAB4ALAYAAAAWABwAAAbRQI9HMFk0FJFSgRAQCJ9QgQRiqFaV2MIA+kRYv1kswQn9GhSMRIBQyBa0ZcMh4QBwBewSluwxQB5cd22DZA1bgVwAeUtCh4iJgyWOj4ECSm+UlAF6cJmBA4MBnoh5BKOBBJenXKB6q1CbmK9CGzEVJbNDGlUquQ5WC7kJVhazDwdVGgOipwEXVQcYHhTMmQQUyAYIWwYXgJQPF9kd39B0dk8ADgnZchtPZhoMGRkMHGYd711m/FYI308GYKDSrwoEDOg+WTCi4MABBQ0WWJgEJQgAIfkECQUAHgAsBgAAABYAHAAABs1Aj0cwWTQUkRCBEBAIn1CBBGKoVgshbKEwgD4R1vB2nCU4oWGDgpFYbpVZLtpwSDgA3sFgjD17DBAPXnlaW2cNXYNeAARaBEKJiotvcpKSe2OWlo1ZkZpQmAWPn4MESqOkUI1bqV4BWq2qb7FPnKixY7epe2W0Hq9bnqQCWUq/rQOrchQBpAQUDCHGfxeClg8XBwYNFXh/dHbeQgAOCdpVBxZPaRoMGRkMHGkdG1BgafhVCNZPAxhU+apAwCAujwUjCg4cUNBggQVhT4IAACH5BAkFAB0ALAYAAAAWABwAAAa/wE5HMFk0FJFCgRAQCJ9QgQRiqFaV2MIA+kRYv4VKmKAkOKFfg4KRIAzIY+X2WT0kHADuYKCskOcdBhAPXHpwSmcNgIVPAGR+BEKLjE9vWJOUUHxYmZmPbp2MfGSRoYVwpaZQn6pcAZytT69+sU+kBbVCWKmtmxWYoa9ytQJxHQGtAFlbFMihjn2lBheEmZtlZ3V3eY0CwmFadF8aDBkZDBwb0aBdaWkmu5MDGFTuBhrDlAMWRgoHBwoaLAAmJAgAIfkECQUAGQAsBgAAABYAHAAABrnATEYwWTQUkUKBEBAIn1CBBGKoVpXYwgD6RFi/hUqYoCQ4oV+DgpEgDMhj5fZZPSQcAO5goKyQ5xkGEA9cenBKZw2AhU8AZH4EQouMT29Yk5RQfFiZmY9unYx8ZJGhhXClplCfqlwBnK1Pr36xT6QFtUJYqa2bFZihr3K1AnEZAa0AWVsUyKGOfaUGF4SZm2VndXd5UcJhWnRWB34BAYdjoF1WEFlYfkuTAxhUC33Rw5QDFg/nbsBCQQAh+QQJBQAUACwAAAAAHAAcAAAGvkCKcCgUTBYNRaRUIAQExKhUIIEYrlemtjCQehHY8FZLgHqHYYOCkQgQCtsC9yy8HhIOQFTwLmnNXgYQD3QUAnCIgFENXYUUAH1NZ42Oj4gllJVnAkxymo4BfnOfk4gBpHR9BKhnBJ2sXgNwJbBSoZ61RJG5RIirvBSyTKfAtyWKsJxwv1HElQCXmUIqJXqOkL5SJh9yyHuXBcgfWsPShq6X3oadZE5ukZ3mQ5Bj4FtllcL2iKOfAm78nMgTEgQAIfkECQUADgAsAAAAABwAHAAABvJAh3AoFEwWDUWkUCAEBMSoVCCBGK5XprYwkEorCKy4UCETmASo17HpiA0KRoIwOJuZXekmgj0kPABRAwNbXFEVblcQD2tChGVMag4CYVcNeY0OAGcVBARDGFgQmJmadoYCVgYHjKVEhFoOFlgJrlKcdAtYHraCdgQNVxqBvURaBApXDMVRuAdXtcxDAVrPBtHSDtSdCgcdINlCZ2ceD0zhDsfUeNkCZmnH2addZOzF7maOW8SuAMeYuAjwa7SJSSci7uZlwodGkr47aaasq0dqCKxCTgKceleRSEFIheqh6SiljpkynbaQbDTIU5MmdBoFAQAh+QQJBQAUACwAAAAAHAAcAAAG50CKcCgUTBYNRSREIAQExKhUIIEYrtdCSFsoDKTSCgJL7pq3BCiYsumQDQpGotllbr3gTQR7SDgAUQMDZlpqQxVuVxAPa0KDdwWGAmNXDV+NQgAEXARDGFgQl5iZdXgUIgoGB4yjRINmFAJaIiStUptbAwF3orakTHRdvrddm1qdw0S4y8jJQsZnAc5DuITNztAEd9PPxwF1hsOvBQTj177fuRRcpr6yx451BIC2APKixkz0mJp31+9mek0hFGJfvDshnkjRxUXdQm1nmgQIQAdSuynVSrGTZ3DNgIzseCUTtIxcuUZBAAAh+QQFBQAIACwAAAAAHAAcAAAG20CEcCgUTBYNRaRUIAQExKhUIIEYrlemtjCQTlPY8FZLgHoRgkJIg1UwEgFCYVvgegel/OmQcACiAnJ5c2ZDaXV1JWdFiXWFCIIlBH+LQgCRBEMDc3WUlZaIJV0InCWPnwh4c5kCWgGoUgFaAgGcp7CbTHFMBbBeBExyq76xg67EUcJbr8hDsrzBzUPCTZzSQsCSsoTSrXVPx82RUKW3ld6SQrmdvgCcdtick6iX8kRpW+aGpQWn67qj7gEr5wVfKQJO4gh6F3DKwDH8gukjsiniwYaoaC1s8mRREAA7') no-repeat 50% 50%;
}



    .mode-fullbox {
	box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    flex-wrap: wrap;
    display: flex;
	}
	
	
	.mode-left {
	padding-right: 24px;
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 70%;
	font-size: 14px;
    }
	
	.mode-right {
    box-sizing: border-box;
    margin: 0px;
    position: relative;
    min-width: 0px;
    width: 30%;
    }
	
	
	
	
	
@media screen and (max-width: 1063px) {
	
		.mode-left {
	padding-right: 0px;
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
    }
	
	
	.mode-right {
     width: 100%;
    }
	
}


@media screen and (max-width: 767px) {
	
	.mode-left {
	padding-right: 0px;
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
    }
	
	
	
	.mode-right {
    width: 100%;
    }
}
	
	
	
	
	.mode-fullbox table.offers.redesigned .offer, table.offers.redesigned .offer, table.offers.redesigned.userobserved-list .offer {
    border-bottom: 0;
    padding: 10px 0;
    height: auto;
}
	
	
	.mode-fullbox table {
    line-height: 30px;
    border-bottom: 1px solid #eee;
    width: 100%;
    margin-bottom: 10px;
    padding-bottom: 5px;
	 }
	
	
	
	
	.mode-fullbox h1 {
	color: #343a40 !important;
    font-size: 22px;
    line-height: 30px;
    border-bottom: 1px solid #eee;
    width: 100%;
    margin-bottom: 10px;
    padding-bottom: 5px;
	 }
	 
	 
	 
	.allfull {
    padding: 20px 15px;
    border-radius: 8px;
    background-color: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
	margin-bottom: 30px;
	} 
	
	
	
	
	

	 
    .user-fullbox {
    box-sizing: border-box;
    margin: 15px 0px;
    min-width: 0px;
    flex-wrap: wrap;
    display: flex;
    padding: 15px 0px;
    border-top: 4px solid #eff1fb;
	}
	
	
	.user-fullbox h1 {
	color: #343a40 !important;
    font-size: 22px;
    line-height: 30px;
    border-bottom: 1px solid #eee;
    width: 100%;
    margin-bottom: 10px;
    padding-bottom: 5px;
	 }
	 
	.user-left {
	padding-right: 24px;
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 20%;
	font-size: 14px;
    }
	
	.user-right {
    box-sizing: border-box;
    margin: 0px;
    position: relative;
    min-width: 0px;
    width: 80%;
    }
	 
	 
	 
.user-offers {
    margin: 0;
    display: block;
    height: 40px;
    padding: 10px 20px;
    font-weight: 700;
    border-radius: 4px;
    position: relative;
    color: #ffffff;
    font-size: 18px;
    word-wrap: break-word;
    cursor: pointer;
    text-align: center;
    background: rgb(116, 188, 37);
    box-shadow: rgba(0, 0, 0, 0.04) 0px 2px 4px 0px;
}



.user-offers:hover {
    background-color: rgb(104 168 35);
    color: #fff;
}





	 
.limituser-offers {
    margin: 0;
    display: block;
    height: 40px;
    padding: 10px 20px;
    font-weight: 700;
    border-radius: 4px 4px 0px 0px;
    position: relative;
    color: #ffffff;
    font-size: 18px;
    word-wrap: break-word;
    cursor: pointer;
    text-align: center;
    background: #9d9d9d;
    box-shadow: rgba(0, 0, 0, 0.04) 0px 2px 4px 0px;
}



.limituser-offers:hover {
    background-color: #888888;
    color: #fff;
}


.fix_gridlimit {
	border-bottom: solid 1px #999;
    border-left: solid 1px #999;
    border-right: solid 1px #999;
    padding: 4px 6px;
    text-align: center;
    font-size: 13px;
	
}


.message-content {
    position: relative;
}
.message-content {
    flex: 1 1 auto;
    min-height: 1px;
    max-width: 100%;
}


.message-attribution {
    color: #a0afce;
    font-size: 12px;
    border-bottom: 1px solid #d3e1f6;
    padding-bottom: 3px;
    border-width: 0;
    border-style: solid;
    padding-bottom: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.message-attribution-main {
    float: left;
}

.message-attribution-opposite {
    float: right;
}

.message-attribution-opposite span {
    margin-right: 5px;
}


.message-attribution-opposite span a {
	color: #999;
}


.message-attribution-opposite span a:hover {
	color: #1a1a1a;
}

.message-footer {
    margin-top: auto;
}

.actionBar {
    padding: 16px;
    padding-top: 0;
    margin: -16px;
    margin-top: 0;
}

.actionBar-set.actionBar-set--external {
    float: right;
    margin-right: -3px;
}
.message-actionBar .actionBar-set {
    font-size: 12px;
}


.actionBar .actionBar-action:hover {
    color: #543ba2;
    background: rgba(112,130,167,0.1);
}


.actionBar .actionBar-action {
    padding: 3px;
    border: 1px solid transparent;
    border-radius: 8px;
    margin-left: 5px;
    color: #876fce;
    background: rgba(160,175,206,0.1);
    padding-right: 5px;
    padding-left: 5px;
    border-radius: 4px;
    display: inline-block;
}



.message-avatar {
    text-align: center;
    margin-bottom: 3px;
}


.message-avatar-wrapper {
    position: relative;
    display: inline-block;
    vertical-align: bottom;
}

.message-avatar .avatar {
    vertical-align: bottom;
    max-width: 120px;
    max-height: 120px;
}


.avatar.avatar--s {
    width: 48px;
    height: 48px;
    font-size: 28.8px;
	border-radius: 4px;
    vertical-align: top;
    overflow: hidden;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    line-height: 1;
    border-radius: 100%;
	border: solid 1px #efefef;
}
.avatar:hover {
    text-decoration: none;
}

.avatar img:not(.cropImage) {
    text-indent: 100%;
    overflow: hidden;
    white-space: nowrap;
    word-wrap: normal;
    display: block;
    border-radius: inherit;
    width: 100%;
    height: 100%;
}
.avatar img {
    background-color: #fff;
}


.message-userDetails {
    text-align: center;
}


.message-name {
    font-weight: 700;
    font-size: inherit;
    text-align: center;
    margin: 0;
}



.message-userTitle {
    font-size: 12px;
    font-weight: normal;
    text-align: center;
    margin: 0;
}


.message-userBanner.userBanner {
    margin-top: 3px;
}
.userBanner.userBanner--yellow {
    color:  var(--color-primary-p3-dark);
    background: #ffff91;
    border-color: #ffff5e;
    border-radius: 8px;
    border-color: #e6e687;
}

.userBanner.userBanner--ex {
    color: #fff;
    background: #c937f9;
    border-radius: 8px;
    border-color: #b423bd;
}


.userBanner.userBanner--staff {
    color: #fff;
    background: #f01420;
    border-radius: 8px;
    border-color: #bd232b;
}








.userBanner {
    font-size: 75%;
    font-size: 11px;
    font-weight: 400;
    font-style: normal;
    padding: 1px 10px;
    padding: 1px 3px;
    border: 1px solid transparent;
    border-radius: 4px;
    text-align: center;
    display: inline-block;
}




 .contact-button {
    display: block;
    height: 40px;
    padding: 10px 20px;
    font-weight: 700;
    border-radius: 4px;
    position: relative;
    color: #fff;
    font-size: 18px;
	background: #525d66;
    word-wrap: break-word;
    cursor: pointer;
    text-align: center;
	margin-bottom: 10px;
}



.contact-button:hover {
    background: rgb(51 51 51);
	color: #fff;
}



.mode-allbox {
	box-sizing: border-box;
    margin: 0px;
    padding: 24px 16px 40px;
    border-radius: 8px;
	background-color: rgb(255, 255, 255);
    border: 1px solid #ececec;
	line-height: 24px;
	width: 100%;
}



.mode-allbox h1 {
	color: #343a40 !important;
    font-size: 22px;
    line-height: 30px;
    border-bottom: 1px solid #eee;
    width: 100%;
    margin-bottom: 10px;
    padding-bottom: 5px;
	 }



.mode-right .favspan {
	display: block;
    height: 40px;
    padding: 10px 20px;
    font-weight: 700;
    border-radius: 4px;
    position: relative;
    color: #010101;
    font-size: 18px;
    background: #e6e6e6;
    word-wrap: break-word;
    cursor: pointer;
    text-align: center;
    margin-bottom: 10px;
    border: 1px solid #dfdfdf;}
	
	
	
	.mode-right .favspan:hover {
    background: #dee2e6;
	}
	
	
	
	

/* --- PM --- */
@media only screen and (min-width: 601px) {
#pm-menu:after { content: ""; clear: both; display: block; }
	#pm-menu { margin-bottom: 25px; }
	#pm-menu a { color: inherit; padding: 10px 16px; border-radius: 2px; border: 2px solid transparent; float: left; text-decoration: none !important; }
	#pm-menu a:hover { border-color: #3394e6; color: #3394e6; }
}

	.pm-box { margin-bottom: 25px; }
		.pm_status { padding: 25px; background-color: #f7f7f7; border-radius: 2px; }
		.pm_progress_bar { background-color: #e5dbcc; margin-bottom: 10px; border-radius: 2px; }
		.pm_progress_bar span { background: #e85319; font-size: 0; height: 20px; border-radius: 2px; display: block; overflow: hidden }







/*--- Загрузчик AJAX ---*/
#loading-layer { display: none;}

/*--- Цитаты, Спойлеры, Код  ---*/
.scriptcode, .title_quote,
	.title_spoiler, .text_spoiler, .quote { padding: 2% 4%; background: #fff; border: 1px solid #dde4ea; }

	.title_quote { border-left: 2px solid #e85319; border-bottom: 0; margin-top: 2px; font-weight: bold; }
	.quote, blockquote { padding: 1% 4%; border-left: 2px solid #e85319; font-style: italic;}
	.title_spoiler { margin-top: 2px; }
	.text_spoiler { margin-bottom: 2px; }
	.title_spoiler img { display: inline-grid !important;vertical-align: middle; margin: -1px 0 0 !important }
	.scriptcode { color: #4c6d0f; text-align: left;  }
	.title_spoiler {     background: #f6d5e0 !important;
    border-color: rgba(0,0,0,0) !important;
    font-size: 15px;
    font-weight: 600;
    border-radius: 8px;
    padding-top: 0;
    padding-right: 15px;
    padding-bottom: 0;
    padding-left: 15px;
    text-align: center;
    outline: none;
    line-height: 35px;
    height: 35px;
    text-decoration: none;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-sizing: content-box;
    -webkit-appearance: none;
    will-change: box-shadow;
    transition: all .3s cubic-bezier(.25, .8, .25, 1);
    border: none;
    white-space: nowrap;
    border-radius: 4 px;
    background: transparent;
    border-color: rgba(0,0,0,0); }
	.text_spoiler { border-top: 0; text-align: justify; }
	.hide { background-color: #f0f0f0; padding: 5px; color: #4c6d0f; margin: 0 0 1em 0 }
	.hide a { text-decoration: underline; } .hide a:hover { text-decoration: none }


/*--- Рейтинг - Звездами ---*/
.rating, .unit-rating { width: 115px; height: 23px; }
	.rating { font-size: 11px; }
	.unit-rating, .unit-rating li a:hover, .unit-rating li.current-rating {
		background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAACKBAMAAAAnGmX8AAAALVBMVEX///+RkZH+12L/w0//7cP/5aj+24X/+u7/9d2tra3Jycne3t7/zGn5+fnx8fHkdmbhAAACEUlEQVRIx+2UuUsDQRTGF+8bp4yiyKDRUhiNFikW73LxwsIiRETL4F2KilpYmFYQklIE0VYbIQQsY2kjWkbwfzDjzvhm3rzCJiCSr1p+SfY7HsT7w2rYp3ltQPO6HpqPDdA8GSVxPeckr+HcJ205T1D8gHPSeJbzPopz7hrvnk4sSL4wcboLdIpb6v0ZxuY+LGB/HRY2ubn2MeB1a5ukxtEUGkEp4bSVchtvhLzfORaE/NV7VCDnlFzJPSKPJmEcczpffhg4x13zvB2nVxXvDdP2oKNHU+FOAyi+r/xRgWn9sOVVRKv8/ycJmlc/0nx8iOYrMRLXC5EibYUIKN4iBGl8KMQoaSsEaZwTIo7Z3tHkoihpdX7mBOiysJSHhJYCWMDExho1JjfXPgP8ZG2T0zhub7SjecJpK+U23gz5iHMsHRJpLuTDzmoqjnNEJRXTbByTv/Gd48YD+WHgHHddtsMnrhb5MO0gih/b/7ZfQQWWA+WPCizph22vojKr7Y3mTec0L7bT/K6T5ukIbctYgbRlLEPxRsbOSVvGuimeZYw0ZiVh9vpwfyX5xfXDJ1CJDHVAQlOQtvXOxMYazSa/9UDvGqIOrWmNI/ZxXjS/xCOrjHjSZ3g7Wg1CmsZZ6Eq9P1LAR1RCXDaOpKGtOV2mGUaD48pGRXliFL8jTNuF4odB2tKoQDaj/FGBG/3w4f0LfQHtX5JXyZBVcwAAAABJRU5ErkJggg==);
		-webkit-background-size: 23px auto; background-size:  23px auto;
	}
	.unit-rating {
		list-style: none;
		margin: 0; padding: 0;
		position: relative;
		background-position: 0 -46px;
	}
	.unit-rating li {
		text-indent: -90000px;
		padding: 0; margin: 0;
		float: left;
	}
	.unit-rating li a {
		display: block;
		width: 23px; height: 23px;
		text-decoration: none;
		border: 0 none !important;
		text-indent: -9000px;
		z-index: 17;
		position: absolute;
		padding: 0;
	}
	.unit-rating li a:hover {
		background-position: 0 -23px;
		z-index: 2;
		left: 0;
	}
	.unit-rating a.r1-unit { left: 0; }
	.unit-rating a.r1-unit:hover { width: 23px; }
	.unit-rating a.r2-unit { left: 23px; }
	.unit-rating a.r2-unit:hover { width: 46px; }
	.unit-rating a.r3-unit { left: 46px; }
	.unit-rating a.r3-unit:hover { width: 69px; }
	.unit-rating a.r4-unit { left: 69px; }
	.unit-rating a.r4-unit:hover { width: 92px; }
	.unit-rating a.r5-unit { left: 92px; }
	.unit-rating a.r5-unit:hover { width: 115px; }
	.unit-rating li.current-rating {
		background-position: 0 0;
		position: absolute;
		height: 23px;
		display: block;
		text-indent: -9000px;
		z-index: 1;
		padding: 0px;
	}

	.ratingplus {
		color: #70bb39;
	}

	.ratingminus {
		color: red;
	}

	.ratingzero {
		color: #6c838e;
	}
	
/*--- Таблица Персональных сообщений и лучших пользователей ---*/
.userstop td, .pm td.pm_list, .pm td.pm_head { border-bottom: 1px solid #efefef; padding: 12px 2px; }
	table.pm, table.userstop { width: 100%; margin-bottom: 0; }
	table.pm select { width: 100px; }
	.userstop thead td, .pm td.pm_head { border-bottom: 1px solid #efefef; font-weight: bold; }
	table.pm .navigation { border-top-width: 0; margin: 0; }

/*---Выпадающее меню кнопки редактировать---*/
#dropmenudiv { padding: 10px 0; min-width: 140px; width: auto !important; opacity: 1 !important; display: none; font-size: .9em;
		box-shadow: 0 8px 40px -10px rgba(0,0,0,0.3); border: 1px solid #e6e6e6; border-color: rgba(0,0,0,0.1); background-clip: padding-box;
	}
	#dropmenudiv { background-color: #fff; }
	#dropmenudiv a { text-decoration: none !important; color: inherit; display: block; padding: 3px 20px; border: 0 none; white-space: nowrap; color: inherit; }
	#dropmenudiv a:hover { background-color: #eeeeef; }

/*---показ оригинальной картинки загруженной на сайт из уменьшенной копии---*/
.highslide-wrapper, .highslide-outline { background: #fff }
	.highslide-image { border: 2px solid #fff }
	.highslide-active-anchor { visibility: hidden } 
	.highslide-active-anchor img { visibility: hidden }
	.highslide-dimming { background-color: black }
	.highslide-html { background-color: white }
	.highslide-loading { display: block; color: white; font-size: 9px; font-weight: bold; text-decoration: none; padding: 3px; border: 1px solid white; background-color: black }
	a.highslide-full-expand { background: url(/templates/lifesport/dleimages/fullexpand.gif) no-repeat; display: block; margin: 0 10px 10px 0; width: 34px; height: 34px }
	.highslide-display-block { display: block }
	.highslide-display-none { display: none }
	.highslide-caption { display: none; padding: 5px; background: white }
	.highslide-controls { width: 195px; height: 40px; background: url(/engine/classes/highslide/graphics/controlbar-black-border.gif) no-repeat 0 -90px; margin-right: 15px; margin-bottom: 10px; margin-top: 10px }
	.highslide-controls ul { position: relative; left: 15px; height: 40px; list-style: none; margin: 0; padding: 0; background: url(/engine/classes/highslide/graphics/controlbar-black-border.gif) no-repeat 100% -90px }
	.highslide-controls li { float: left; padding: 5px 0; }
	.highslide-controls a { background: url(/engine/classes/highslide/graphics/controlbar-black-border.gif); display: block; float: left; height: 30px; width: 30px; outline: none }
	.highslide-controls a.disabled { cursor: default }
	.highslide-controls a span { display: none }
 
/*---Навигация по картинкам галереи---*/
.highslide-controls .highslide-previous a { background-position: 0 0 }
	.highslide-controls .highslide-previous a:hover { background-position: 0 -30px }
	.highslide-controls .highslide-previous a.disabled { background-position: 0 -60px !important }
	.highslide-controls .highslide-play a { background-position: -30px 0 }
	.highslide-controls .highslide-play a:hover { background-position: -30px -30px }
	.highslide-controls .highslide-play a.disabled { background-position: -30px -60px !important }
	.highslide-controls .highslide-pause a { background-position: -60px 0 }
	.highslide-controls .highslide-pause a:hover { background-position: -60px -30px }
	.highslide-controls .highslide-next a { background-position: -90px 0 }
	.highslide-controls .highslide-next a:hover { background-position: -90px -30px }
	.highslide-controls .highslide-next a.disabled { background-position: -90px -60px !important }
	.highslide-controls .highslide-move a { background-position: -120px 0 }
	.highslide-controls .highslide-move a:hover { background-position: -120px -30px }
	.highslide-controls .highslide-full-expand a { background-position: -150px 0 }
	.highslide-controls .highslide-full-expand a:hover { background-position: -150px -30px }
	.highslide-controls .highslide-full-expand a.disabled { background-position: -150px -60px !important }
	.highslide-controls .highslide-close a { background-position: -180px 0 }
	.highslide-controls .highslide-close a:hover { background-position: -180px -30px }


/*---Диалоговые и всплывающие окна jQuery UI---*/
.ui-front { z-index: 1000; }
.ui-widget-overlay {
	background:  var(--color-primary-p3-dark);
	opacity: 0.5;
	left: 0; top: 0; right: 0; bottom: 0;
	position: fixed;
	}
	.ui-helper-clearfix:after { clear: both; content: "."; display: block; height: 0; visibility: hidden }
	.ui-helper-clearfix { display: inline-block }
	* html .ui-helper-clearfix { height: 1% }
	.ui-helper-clearfix { display: block }
	.ui-dialog {
		text-align: left;
		overflow: hidden;
		padding: 0;
		position: absolute;
		width: 370px;
		border-radius: 2px;
		box-shadow: 0 8px 40px -10px rgba(0,0,0,0.3);
		border: 1px solid #e6e6e6; border-color: rgba(0,0,0,0.1);
		background-color: #f7f7f7;
		background-clip: padding-box;
		outline: none;
	}
	.ui-dialog-titlebar {position: relative; }
	.ui-dialog-title { float: left;font-weight: bold;font-size: 18px;font-family: "Cutest", sans-serif;}
	.ui-dialog-titlebar-close {
		position: absolute;
		right: 10px; top: 50%;
		margin-top: -16px !important;
		height: 23px !important;
		width: 32px;
		border: 0 none !important;
		background-color: inherit !important;
		box-shadow: none !important;
		padding: 0px !important;
	}
	.ui-dialog-titlebar-close .ui-icon {
		display: block;
		margin: 10px auto 0 auto;
		width: 12px; height: 12px;
		background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYBAMAAAASWSDLAAAAG1BMVEUAAAA1NTU1NTU1NTU1NTU1NTU1NTU1NTU1NTW7eCkWAAAACHRSTlMA8DiyCsELwNb3saQAAABlSURBVBjTY2AxYoACZQcG10YFCJtJooTBokMIwlHsaAZioBRYAigKJoAAJAghoRIQCiYEoSEiUCmIBFQKLAGTAkvApCASCA6GMoQBGEYjLEV1DopDUbyA4jlUb6ciAiSMgQ0pqAB4linXHtbaoQAAAABJRU5ErkJggg==);
		-webkit-background-size: 12px auto; background-size: 12px auto;
		opacity: .5;
	}
	.ui-button {
		float: right;
		border: 0 none;
		display: inline-block;
		vertical-align: middle;
		cursor: pointer;
		height: 36px;
		border-radius: 18px;
		line-height: 22px;
		outline: none;
		background-color: #3394e6;
		color: #fff;
		border: 0 none;
		padding: 7px 22px;
		text-decoration: none !important;
		box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
		-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
		-webkit-transition: all ease .1s; transition: all ease .1s;
	}
	.ui-dialog-titlebar-close:hover .ui-icon { opacity: 1; }
	.ui-icon, .ui-button-icon-only { overflow: hidden; text-indent: -9999px; }
	.ui-dialog label { color: #575757; }
	.ui-dialog-content { padding: 20px; border: 1px solid #fff; overflow: auto; position: relative; zoom: 1; }
	.loginbox.ui-dialog, .loginbox .ui-dialog-content { overflow: visible !important; }
	.ui-dialog-content h2 { display: inline; font-size: 1em; font-weight: bold }
	.ui-dialog .ui-dialog-buttonpane { padding: 20px; text-align: center; }
	.ui-dialog .ui-resizable-se { bottom: 3px; height: 14px; right: 3px; width: 14px; }
	.ui-draggable .ui-dialog-titlebar { cursor: move; }
	.ui-state-error { background: #fef1ec 50% 50% repeat-x !important; border: 1px solid #cd0a0a; color: #cd0a0a; }
	.ui-button { margin: 0 3px; }
	.ui-helper-hidden-accessible{display: none;}
	
	@media screen and (max-width: 590px) {
.ui-dialog {width:100% !important;}
}

/* --- Автозаполнение облака тегов --- */
.ui-autocomplete { position: absolute; cursor: default; }
* html .ui-autocomplete { width: 1px } /* without this, the menu expands to 100% in IE6 */
.ui-menu {
	list-style:none;
	padding: 2px; margin: 0;
	float: left;
	background: #fff 50% bottom repeat-x;
	border: 1px solid #dedede;
	color: #353535;
	}
	.ui-menu .ui-menu { margin-top: -3px; }
	.ui-menu .ui-menu-item { margin:0; padding: 0; zoom: 1; float: left; clear: left; width: 100%; }
	.ui-menu .ui-menu-item a { text-decoration:none; display:block; padding:.2em .4em; line-height:1.5; zoom:1; }
	.ui-menu .ui-menu-item a.ui-state-hover,
	.ui-menu .ui-menu-item a.ui-state-active { font-weight: normal; margin: -1px; border: 1px solid #a7a7a7; color: #4e4e4e; font-weight: bold; }

/*---Подсветка кода в теге [code]---*/
pre code { display: block; padding: 0.5em; background: #f9fafa; border: 1px solid #dce7e7; overflow:auto; white-space: pre; }
	pre .comment, pre .template_comment, pre .diff .header, pre .doctype, pre .lisp .string, pre .javadoc { padding: 0; margin: 0; border:none; box-shadow: none; background-color: inherit; color: #93a1a1; font-style: italic; }
	pre .keyword, pre .css .rule .keyword, pre .winutils, pre .javascript .title, pre .method, pre .addition, pre .css .tag, pre .lisp .title { color: #859900; }
	pre .number, pre .command, pre .string, pre .tag .value, pre .phpdoc, pre .tex .formula, pre .regexp, pre .hexcolor { color: #2aa198; }
	pre .title, pre .localvars, pre .function .title, pre .chunk, pre .decorator,
	pre .builtin, pre .built_in, pre .lisp .title, pre .identifier, pre .title .keymethods, pre .id { color: #268bd2; }
	pre .tag .title, pre .rules .property, pre .django .tag .keyword { font-weight: bold;font-size: 1.08em !important;  }
	pre .attribute, pre .variable, pre .instancevar, pre .lisp .body, pre .smalltalk .number, pre .constant, pre .class .title,
	pre .parent, pre .haskell .label { color: #b58900; }
	pre .preprocessor, pre .pi, pre .shebang, pre .symbol,
	pre .diff .change, pre .special, pre .keymethods, pre .attr_selector, pre .important, pre .subst, pre .cdata { color: #cb4b16; }
	pre .deletion { color: #dc322f; }
	pre .tex .formula { background: #eee8d5; }
	pre .comment:hover {background-color: inherit;box-shadow: none;}

/*---BB Редактор---*/
.bb-pane {
  height: 1%; overflow: hidden;
  padding-bottom: 5px;
  padding-left: 5px;
  margin: 0;
  height: auto !important;
  text-decoration:none;
  background-image: -webkit-gradient(linear, left 0%, left 100%, from(#FBFBFB), to(#EAEAEA));
  background-image: -webkit-linear-gradient(top, #FBFBFB, 0%, #EAEAEA, 100%);
  background-image: -moz-linear-gradient(top, #FBFBFB 0%, #EAEAEA 100%);
  background-image: linear-gradient(to bottom, #FBFBFB 0%, #EAEAEA 100%);
  background-repeat: repeat-x;
  border-radius: 3px 3px 3px 3px;
  -moz-border-radius-bottomright: 0px;
  -webkit-border-bottom-right-radius: 0px;
  -khtml-border-bottom-right-radius: 0px; 
  border-bottom-right-radius: 0px;
  -moz-border-radius-bottomleft: 0px;
  -webkit-border-bottom-left-radius: 0px;
  -khtml-border-bottom-left-radius: 0px;
  border-bottom-left-radius: 0px;
  border-top:1px solid #d7d7d7;
  border-left:1px solid #d7d7d7;
  border-right:1px solid #d7d7d7;
  box-shadow: none !important;
}

.bb-pane>b {
    margin-top: 5px;
    margin-left: 0;
	vertical-align: middle;
}
.bb-pane .bb-btn + .bb-btn,.bb-pane .bb-btn + .bb-pane,.bb-pane .bb-pane + .bb-btn,.bb-pane .bb-pane + .bb-pane {
    margin-left:-1px;
}
.bb-btn {
	display: inline-block; overflow: hidden; float: left;
	padding: 4px 10px;
    border: 1px solid #d4d4d4;
    -webkit-box-shadow: inset 0 1px 2px white;
    -moz-box-shadow: inset 0 1px 2px white;
    box-shadow: inset 0 1px 2px white;
    background-repeat: repeat-x;
    background-image: -webkit-gradient(linear, left 0%, left 100%, color-stop(0%, #fdfdfd), color-stop(100%, #e9e9e9));
    background-image: -webkit-linear-gradient(top, #fdfdfd, 0%, #e9e9e9, 100%);
    background-image: -moz-linear-gradient(top, #fdfdfd, 0%, #e9e9e9, 100%);
    background-image: linear-gradient(to bottom, #fdfdfd 0%, #e9e9e9  100%);

}
 

.bb-btn:hover {
      background: #e6e6e6;
      background-repeat: repeat-x;
      background-image: -webkit-gradient(linear, 50% 0%, 50% 100%, color-stop(0%, #fdfdfd), color-stop(100%, #e6e6e6));
      background-image: -webkit-linear-gradient(top, #fdfdfd, 0%, #e6e6e6, 100%);
      background-image: -moz-linear-gradient(top, #fdfdfd, 0%, #e6e6e6, 100%);
      background-image: -o-linear-gradient(top, #fdfdfd, 0%, #e6e6e6, 100%);
      background-image: linear-gradient(to bottom, #fdfdfd 0%, #e6e6e6 100%);
      -webkit-transition: box-shadow 0.05s ease-in-out;
      -moz-transition: box-shadow 0.05s ease-in-out;
      -o-transition: box-shadow 0.05s ease-in-out;
      transition: box-shadow 0.05s ease-in-out;
}
    
.bb-btn:active {
      background: #f3f3f3;
      border-color: #cfcfcf;
      -webkit-box-shadow: 0 0 5px #f3f3f3 inset;
      -moz-box-shadow: 0 0 5px #f3f3f3 inset;
      box-shadow: 0 0 5px #f3f3f3 inset;
}

.bb-editor textarea { 
    -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
    padding: 7px; border: 1px solid #d7d7d7; width: 100%; -webkit-box-shadow:inset 0 1px 1px rgba(0, 0, 0, 0.075);
    box-shadow:inset 0 1px 1px rgba(0, 0, 0, 0.075);
    -webkit-transition:border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
    transition:border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
	margin-top: -1px;
	outline: none;
}

.bb-editor textarea:focus{
		border-color: #d7d7d7 !important;
}

	@font-face {
	    font-family: 'bb-editor-font';
	    src: url(data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMg8SDwYAAAC8AAAAYGNtYXA29C0zAAABHAAAAPRnYXNwAAAAEAAAAhAAAAAIZ2x5ZjJsQmgAAAIYAAAh4GhlYWQFqWKMAAAj+AAAADZoaGVhCAwELgAAJDAAAAAkaG10eINuAK8AACRUAAAAlGxvY2FzLnwUAAAk6AAAAExtYXhwADQA3wAAJTQAAAAgbmFtZb8AOU4AACVUAAABhHBvc3QAAwAAAAAm2AAAACAAAwQAAZAABQAAApkCzAAAAI8CmQLMAAAB6wAzAQkAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADx3APA/8AAQAPAAEAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEAOAAAAA0ACAABAAUAAEAIOYB6RHpE+kw6XfpjenR6mHqaOpy6o3wA/A08DnwPvDB8M3xGPEh8SzxZvHc//3//wAAAAAAIOYA6RHpE+kw6XfpjenR6mHqaOpy6o3wA/Ax8DbwPvDB8MrxGPEh8SvxZvHc//3//wAB/+MaBBb1FvQW2BaSFn0WOhWrFaUVnBWCEA0P4A/fD9sPWQ9RDwcO/w72Dr0OSAADAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAABgAA/8AEAAPAAAMABwALABgAJQAyAAABITUhASE1IQEhNSEBNDYzMhYVFAYjIiY1ITQ2MzIWFRQGIyImNSE0NjMyFhUUBiMiJjUEAPwABAD+gP2AAoABgPwABAD8ACUbGyUlGxslAgAlGxslJRsbJf8AJRsbJSUbGyUDQID+gID+gID+QBslJRsbJSUbGyUlGxslJRsbJSUbGyUlGwAAAAIAGgAIA+gDqwAOACsAABMGFgcGFj4BNzYmJy4BBwEmDgIHDgEHBhYXHgEXHgEXHgE3PgE3PgMnjToVThE7Z3gtJQ8oKGMmA1sPncbAMTErDwYLAxQeERIWCgIHCBQ5MTGkmGQPARY5flcUDBIyKyVhKCcPJQKVD2OVoTEwOBQIBwIKFRERHhMECgYPKjAwvcKbDwABAAD/wAQAA8AAKwAAATMRFA4CIyIuAjU0PgIzMhYXEQURFA4CIyIuAjU0PgIzMhYXESUDwEAjPVIuLlI9IyM9Ui4vUx7+ACM9Ui4uUj0jIz1SLi9THgJAA8D9ICE6LBkZLDohITosGRoWAXBy/hIhOiwZGSw6ISE6LBkaFgJwgAAAAAAJAAAAQAQAA0AABAAJAA4AEwAYAB0AIgAnACoAABMRIREhEyM1MxURIzUzFREjNTMVASERIREzIzUzFREjNTMVESM1MxUhESUABAD8AMCAgICAgIACQP4AAgDAgICAgICA/cABAANA/QADAP1AgIABAICAAQCAgP4AAoD9gICAAQCAgAEAgID+gMAAAAIAAAAABAADQAADAAoAACUTIQMTAxEhFyEVA0DA/MDAgIABIIABoAACAP4AAkD9wANAgIAAAAAAAgAAAEAEAQMAAB8APwAAEzIeAhUUDgIjIi4CNSc0PgIzFSIGBw4BBz4BMyEyHgIVFA4CIyIuAjUnND4CMxUiBgcOAQc+ATPhLlI9IyM9Ui4uUj0jAUZ6o11AdS0JEAcIEgkCQC5SPSMjPVIuLlI9IwFGeqNdQHUtCRAHCBIJAgAjPVIuLlI9IyM9Ui4gXaN6RoAwLggTCgIBIz1SLi5SPSMjPVIuIF2jekaAMC4IEwoCAQAAAgAA/8AEAAPAACIALwAAASIOAhUUFhcBFRQWOwE1MzUzNTM3HgEzMj4CNTQuAiMTIiY1NDYzMhYVFAYjAsBCdVcyAwL+eyUbQICAgFMaNh1CdVcyMld1QmAoODgoKDg4KAPAMld1Qg8dD/57wBslQICAUwkKMld1QkJ1VzL+wDgoKDg4KCg4AAUAAAAABAADsgAdACgAOQBGAGMAAAEmIg8BLgEjIg4CBx4BFwcGFBceATMyNjcBNjQnATIWFwcuATU0NjMFPgE3PgE3DgEVFBYXBy4BJyU0JicBHgEzMj4CNTcHHgEVHgEXDgEHDgEjIiYnBx4BMzI+AjcuAScDsg4oDsonUitUmoRqJB9YNp8ODgcSCQkSBwNgDg797iAxCnocJTgo/s4dSy4CBgMHCBkWPShCGgKSBgb+vhMnFDVdRig+RQECLksdHUsuOIFDHTkcTS1gMlSahGokImM9A7IODsoMDC9Udkc+aSifDigOBwcHBwNgDigO/s4lHHoKMSAoOMAtTRwCBAIVLBcpSx89G0YpRhQnE/6+BgYoRl01mEUBAQEcTS0tTRwkJgcHTRARL1R2R0NxKgAAAgBA/8ADwANAAAcADwAAEyEVIxEjESMBIxEjESM1IUABgICAgAOA/Ij8AoABwID+gAGAAYD9AAMAgAAABwAA/8AEAAPAAAMABwALAA8AEwAbACMAABMzFSM3MxUjJTMVIzczFSMlMxUjAxMhEzMTIRMBAyEDIwMhAwCAgMDAwAEAgIDAwMABAICAEBD9ABAgEAKAEP1AEAMAECAQ/YAQAcBAQEBAQEBAQEACQP5AAcD+gAGA/AABgP6AAUD+wAAADgAA/8AEAAPAAAMABwAPABMAFwAfACMAJwAvADMANwA/AEQASgAAATMVIzczFSMlESM1MzUjNQUzFSM3MxUjJRUzFSMRMxUTMxUjNzMVIyURIzUzNSM1BTMVIzczFSMlFTMVIxEzFQEhESERNzERIREhAYCAgMCAgAFAwIBA/kCAgMCAgP7AQIDAQICAwICAAUDAgED+QICAwICA/sBAgMACgPyAA4BA/AAEAAMAQEBAQP8AQIBAwEBAQMCAQAEAQP7AQEBAQP8AQIBAwEBAQMCAQAEAQAJA/IADgED8AAQAAAAAAQAA/8AEAAPAACQAAAEhIgYVERQWMyERIzUzNTQ2OwEVIyIGHQEzByMRMzI2NRE0JiMDVf1WR2RkRwFVgIBeQqCgDROwIJDVR2RkRwPAZEf9VkdkAcCAYEJegBMNYID+QGRHAqpHZAADAAAAAAQAAyUAIABQAGUAACURBgcGBwYHBgcGKwEiJyYnJicmJyYnERQXFjMhMjc2NRE1MTUmIwYnJgcGJyEiBwYVFBcWFxYXFhcWFxYXFjsBMjc2NzY3Njc2NzY3Njc2NTcRFAcGIyEiJyY1ETQ3NjMhMhcWFQO3EhaZWh0SEx8fGwIbHx8TEh1amRYSBgUHA0oHBQYBAQIBAgMEBPy2BwUGVG53BBARCgkQEA0NCwILDQ0QEAkKERAEd24fGhtJGxsl/LYlGxsbGyUDSiUbG1sBtxQRdkwYDg4ODg4ODg4YTHYRFP5JBwUGBgUHAlkOBwgBBgUBAQIFBQhgQldeAw4OCAcLCgUFBQUKCwcIDg4DXlcYKikiFf2SJRsbGxslAm4mGxsbGyYAAAACAAAAAAO3A24ACQBrAAABAzIXFjMyNyYnATc2NzY3Njc2NzY3GwEzFhcTFhcWFxYXFhcWFxYXFhcWFRQVBhUiJyYjIgcGIzQ/ATI3NjcyNzY3Njc2NzY1NCcmJyYnJQYHBhUUFxYXFhcWFxYzFBUUByInJiMiBwYjBiMBnmETOzshCxUxOP5iAQ0TEw4NDw8KCweIoEkEAnUTKikYCBkZEAwICycoCAQBJEhJJCxPUBYCSwEGBwICBgYDAwMEAQISEhcXAf7/Dx0dCAgREQsLFRYCASFCQyEFCgsCLT4Cd/7/AQEBkXH9iS0EAwMDAwYFCwsSAWABnggE/u0sZ2Y3Ez8/IRoHCQgIBBULAgYFAgUEBAQYFBACAQECAgICAgMEAwUJLi43OAECIk5PDg0ICQUGAgMCAgsWBgoGBgMCCAAAAAADAAAAAAMlA24AHgA9AI0AACUWMzI1NCcmJyYnJicmJyYjIgcUFRQVFAcGFxQXFhcDFjMyNzY3Njc2NTQnJicmJyYjIgcUFxYVFBUUFRQVATc2NzY3Njc2NzY3NjU0PQEQJyYnJicmJyYnJiMnNjc2MzIXMjMyFxYXFhcWFxYVFAcGBwYHBgcGBxYXFhUUBwYHBgcGBwYjIicmIyIHBgcBPSom1xcQFBMTExsbFRUhKhABAQECAwQIGCYvIyMcHA8OEBEdHCEhJh0tAgL+ywEJKCgUBAMEAQIBAgwCCwoPDw0ODg8DAjiKi0sNGhoMKCYmJCMaGxAQCgkNDRgYEhEfWDs7FBQiIS4tMDA1GTIyGjxzcxFSE8BBJhkREQoJBQUBAQYePTweBCIiFhUaGwsBqgQHCBISISEwKB4eEREICAgcOjodDx4fDxoN/gQ2AgcHCAcJCAsKCAgODQYmAjEYBQQDAwMBAQIBMAEFBgEHCBARGBgkIyseGRkQEBEQCQoNFDk4VjktLh0dFBMICAECBgYBAAEAAAAAAkkDbgBOAAA/ATY3Njc2NzY3Njc2PQEmJyYnJic3FhcWFxYzMjc2NzY3BgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBhUXFhcGByIHBiMiJyYjJiMiBwYHAAoDKysVEAcBIyMeHg4REhYWCwsSMjIkIyEcHR0oKBADCBEpKRUEBAMCAgIDAQ8jIgoBBwYFBQQEAQpgAgcHDAwHECEhEE8nHTU0EQExAQsLChQmBKGhlpUUDwcDAwIBAjsBAwMBAQEBAwMBFxwGCgsJCg4NCgkREAhUm5wwBRwcFxgYGAkKAhAZHwEBBgUCBgUBAAIAAAAAA/0DbgAiAKQAACUyFxYPAQYjIi8BJjc2OwERIyInJj8BNjMyHwEWBwYrAREzARcWMzI3NjMyMzI7ATIXMjM2NzY3Nj8BMhcyMxYVFAcGByYnJicmJyYjJicmJyYjJiMGIyInIiMiBwYHBhcUFxYVFAcGFxYXFhcWFxYVFA8BBicmIyIHBiMmPQE2NzY3Njc2NTQnJj0BNDU0NTQ1JicmJyYjIgcGBwYHBgcGByYnNQPlEgYFDEgLERAMSAsFBRMuLhMFBQtIDBARC0gMBQYSLi78SR8HchkyMhoUKSkUqAMJCAQDBgYEBAQYAwUGAgECFxAPEAIEBQQDAQMEAwYFAgIICQEKHBwODxYWEwUBAQEBAgIBBhcwMBQDAhMrUlElHDo6HQIKGRofHw0LAgEBAQECBlYTIyILCwkICgkPGAiSCgsPXA8PXA8LCgJJCwsOXQ8PXQ4LC/23AtsPAwEBAQEBAQQEBgEBQIAuEAgCGTAFFhYUFAUDAgEBAQEBAQEDLh82qKhcCSAgFBUTDAwMCRcGCAgBAQYFBQUdAQUPCQoHBwgYwzpzdDpCAgcIBwYICAYGAgcHBwgHIiIeHQEOC9sAAAQAAABJBAADbgAUACkAPgBTAAAlFRQHBiMhIicmPQE0NzYzITIXFhUnFRQHBiMhIicmPQE0NzYzITIXFhU3FRQHBiMhIicmPQE0NzYzITIXFhUnFRQHBiMhIicmPQE0NzYzITIXFhUEAAsLD/xKDwsLCwsPA7YPCwvbCwsP/SUPCwsLCw8C2w8LC5ILCw/8kw8LCwsLDwNtDwsL3AoLD/1uDwsLCwsPApIPCwq3SQ8LCwsLD0kPCwoKCw/bSQ8LCgoLD0kPCwsLCw/cSQ8LCwsLD0kPCgsLCg/bSQ8LCwsLD0kPCwsLCw8AAAAABAAAAEkEAANuABQAKQA+AFMAACUVFAcGIyEiJyY9ATQ3NjMhMhcWFScVFAcGIyEiJyY9ATQ3NjMhMhcWFTcVFAcGIyEiJyY9ATQ3NjMhMhcWFScVFAcGIyEiJyY9ATQ3NjMhMhcWFQQACwsP/EoPCwsLCw8Dtg8LC9sLCw/+AA8LCwsLDwIADwsLkgsLD/zcDwsLCwsPAyQPCwvcCgsP/pIPCwoKCw8Bbg8LCrdJDwsLCwsPSQ8LCgoLD9tJDwsKCgsPSQ8LCwsLD9xJDwsLCwsPSQ8KCwsKD9tJDwsLCwsPSQ8LCwsLDwAAAAAEAAAASQQAA24AFAApAD4AUwAAJRUUBwYjISInJj0BNDc2MyEyFxYVNRUUBwYjISInJj0BNDc2MyEyFxYVNRUUBwYjISInJj0BNDc2MyEyFxYVNRUUBwYjISInJj0BNDc2MyEyFxYVBAALCw/8Sg8LCwsLDwO2DwsLCwsP/SUPCwsLCw8C2w8LCwsLD/yTDwsLCwsPA20PCwsLCw/9bg8LCgoLDwKSDwsLt0kPCwsLCw9JDwsKCgsP20kPCwoKCw9JDwsLCwsP3EkPCwsLCw9JDwoLCwoP20kPCwsLCw9JDwsLCwsPAAAABAAAAEkEAANuABQAKQA+AFMAACUVFAcGIyEiJyY9ATQ3NjMhMhcWFTUVFAcGIyEiJyY9ATQ3NjMhMhcWFTUVFAcGIyEiJyY9ATQ3NjMhMhcWFTUVFAcGIyEiJyY9ATQ3NjMhMhcWFQQACwsP/EoPCwsLCw8Dtg8LCwsLD/xKDwsLCwsPA7YPCwsLCw/8Sg8LCwsLDwO2DwsLCwsP/EoPCwsLCw8Dtg8LC7dJDwsLCwsPSQ8LCgoLD9tJDwsKCgsPSQ8LCwsLD9xJDwsLCwsPSQ8KCwsKD9tJDwsLCwsPSQ8LCwsLDwAAAAQAAAAABEkDbgAQABcALABBAAABFAcGIyInJjU0NzYzMhcWFQURITU3FwElISIHBhURFBcWMyEyNzY1ETQnJiMXERQHBiMhIicmNRE0NzYzITIXFhUBbiAgLi4gICAgLi4gIAJJ/Nu3XAEkASX8bQcFBgYFBwOTBwYFBQYHWxsbJfxtJRsbGxslA5MlGxsCbi4gICAgLi0gICAgLdz/AG63XAElpQYFCP1JBwUGBgUHArcIBQYT/UklGxsbGyUCtyYbGxsbJgAAAwAJAAkDrgOuACsAVwCAAAABNC8BJiMiBxYXFhcWFxYXFhUUBwYjIicmJyYnJicmJwYVFB8BFjMyPwE2NQE0LwEmIyIPAQYVFB8BFjMyNyYnJicmJyYnJjU0NzYzMhcWFxYXFhcWFzY1ARQPAQYjIi8BJjU0NycGIyIvASY1ND8BNjMyHwEWFRQHFzYzMh8BFhUDQBB3EBcYEQIJCQMDBgUCAhAQFwgHBwgHBAMJCQISEHUQFxcQVBD+bhB1EBcXEFQQEHcPGBgRAgkJAwQFBQICEBAWCQcHCAcEAwkJARMCADFUL0VFL3YwMzMxRUUwdzAxVC9FRS92LzIyMkVFMHcwAQAXEHcQEwEJCQMEBwgHBwkWEBACAgUFBAMJCQISGBcQdhAPVBAWAZMXEHYQD1QQFhcQdw8RAgkJAwQHCAcHCBcQEAICBQYDAwkJAhIY/m1FL1MwMXYvRUYxMzMwdzBFRDBTMDF2MERGMjIyMHYwRQAABgAAACUEAANJABAAIQA2AEcAXABxAAA3FAcGIyInJjU0NzYzMhcWFREUBwYjIicmNTQ3NjMyFxYVBRUUBwYjISInJj0BNDc2MyEyFxYVARQHBiMiJyY1NDc2MzIXFhUFFRQHBiMhIicmPQE0NzYzITIXFhURFRQHBiMhIicmPQE0NzYzITIXFhXbICAtLiAgICAuLSAgICAtLiAgICAuLSAgAyUFBgf9SQgFBQUFCAK3BwYF/NsgIC0uICAgIC4tICADJQUGB/1JCAUFBQUIArcHBgUFBgf9SQgFBQUFCAK3BwYFki0gICAgLS4gICAgLgElLiAgICAuLiAgICAu7m4HBQYGBQduCAUFBQUIAhItICAgIC0uICAgIC7tbgcGBQUGB24HBgUFBgcBJG0IBQYGBQhtCAUGBgUIAAYACf+3BAADsgAlAE4AYwB1AIoAnwAANxQHBiMiJzcWMzI3NjU0Byc2NzY3Njc1IgciIxUjNTMVBxYXFhUTFSMmNTQ3Njc2NzY3NjU0JyYjIgcnNjc2MzIXFhUUBwYHBgcGBzM1MwUVFAcGIyEiJyY9ATQ3NjMhMhcWFQEVIzUzNDU2PQEjBgcnNzMVMwUVFAcGIyEiJyY9ATQ3NjMhMhcWFREVFAcGIyEiJyY9ATQ3NjMhMhcWFdofIC48JiAcIREMDDwPBQ4OCgoLCRITCT2/Nx0SEQHPAw0NExMTEw0OCQgOGhQxDhsbISocHRMUFxgTFAFJPAMlBQYH/UkIBQUFBQgCtwcGBfzbvz0BAQUYKU49PQMlBQYH/UkIBQUFBQgCtwcGBQUGB/1JCAUFBQUIArcHBgUZLhoaJjIaCAkQJAQgBRQTCwwKAQEeVjJCBhYVHQFmWhQKHhgYDg8NDAwNDQ4ICCEhHhAQGBcpHBgYDQ0QEA4itm4HBQYGBQduCAUFBQUIAgI5ORcvLhcHChUrSefdbgcGBQUGB24IBQUFBgcBJG0IBQYGBQhtCAUGBgUIAAADAAAAAAQAA24AFAA7AG4AAAEyFxYdARQHBiMhIicmPQE0NzYzISUmJyY1NDc2MzIXFhcWFxYVFA8BLwEmJyYjIgcGFRQXFhcWFxYXIQUzFhUUBwYHBgcGBwYjIi8BJicmPQE0JyY/ATU3FhcWFxYXFhcWFxYzMjc2NzY1NCcmJwPuCAUFBQUI/CQIBQUFBQgD3P0mEA0cTUyVHEMmPwYGCAMHMAgcHjNFQiYnJiZ5KDshFv5XASLrBBgNGxYpLSouRkEvUCAJBAEBAQE6CQgJBAQDFBoYJCIpJSssGRsuEzsBtwUFCCUIBQUFBQglCAUFJBQaODRnSUkLBxUVLkYjCg8CAwJVIDQiITIqJicjDBoQDpIWHkA6HxwUGhwKDA0XCQcFCAc+GxEWFRkBExUVCwsFIBUVDAwPDyIjJzAqEBgAAAACAAAAAANuA24AaAB9AAATJi8BNjMyFxYzMjc2NzI3FRcVBiMiBwYVFBcUFR8BFhcWFxYzMjc2NzY3Njc2NTQnJicmLwEmJyYPASc3MxcWNxcWFRQHBgcGBwYVFBcUFRYXFgcGBwYHBgcGIyInJicmJyY9ATQnJicBNTQnJiMhIgcGHQEUFxYzITI3NjUbFQQCBxAiHksUMS9CESARASIlIgsIAQEIAxoUIzIzOzIgGBwKFAoMAgIEBQMCAwsUGDkIATB1K0UKBAMZFykECAEFCAMMCA8WKis9PlRfQ0QiIw0JCg5GA1MFBgj8twgFBQUFCANJCAYFAzcCATIBAwQCAgEBCCUFBQ4IRAcLCwSDoEYtIhMaEAoTFBAgISpZLRwcKioyIScMFAEBAjEGAggBFggEDQcBBgMJDwQLDAYL13A+KxslISESExsaKyxELVq+bA4VAfzbJQgFBQUFCCUIBQUFBQgAAAAFAAAAAANuA24AIAAxAEIAYwB8AAABBgcGIyInJicmNzY3NhcWFxYXFjMyNzY3Njc2FxYXFgclFAcGIyInJjU0NzYzMhcWFSEUBwYjIicmNTQ3NjMyFxYVFzQnJicmJyYjIgcGBwYHBhUUFxYXFhcWMzI3Njc2NzY1MxQHBgcGIyInJicmNTQ3Njc2MzIXFhcWFQKIFTo6SEk5OhUFBwcPDg0OBA8mJzAwJicOBQ4NDw4HBwX+5hYVHh8VFhYVHx4VFgEkFRYeHhYVFRYeHhYVkx4dMTBEREpKREQxMR0dHR0xMURESkpERDAxHR5JOztlZXd4ZGU7Ozs7ZWR4d2VlOzsBUUYqKioqRg4NDgQFBwcPLR0cHB0tDwcHBQQODQ74HhYVFRYeHhYVFRYeHhYVFRYeHhYVFRYekkpERDAxHR4eHTEwRERKSkREMTEdHR0dMTFEREp4ZGU7Ozs7ZWR4d2VlOzs7O2VldwAAAwAaAAsELwMaABoALwBKAAAlBwYjIicBJjU0NwE2MzIfARYVFA8BFxYVFAcBAwYHBi8BJicmNxM2NzYfARYXFgcJAQYjIi8BJjU0PwEnJjU0PwE2MzIXARYVFAcBYR0GBwgF/vUFBQELBQgHBh0FBeHhBQUBUdUCBwYHJAcEAwLVAgcGByQHBAQDAXj+9QUIBwYcBgbg4AYGHAYHCAUBCwUFlxwGBgEKBgcIBQELBQUdBgcHBuHgBgcIBgJi/R4HBAMCCgIGBwcC4ggDBAIKAgcGCP6M/vYGBhwGCAcG4OEGBwcGHQUF/vUFCAcGAAAAAgADAEkDbQNiACMAVQAAJRUjLwEmJyMHBg8BIzUzNycjNTMXFhcWFzM2PwIzFSMHFzMBFSEnJjU0NzY3Njc2NzY3NjU0JyYjIgcGByc2NzYzMhcWFRQHBgcGBwYHBgcGBzM1MwIBjlsOBAICBQYIWZNJcWpOnVABDAQCAgIEDlCTR2l0PwFs/toCAg8PFhYaGhYWDw8RERcdGwgMPA8VLzw/JycODhYVGRkWFhAPAoVIqWCQGAUHDAsOj2Cmm2CCAhYFBwUHGIJgmKkBhHYPEAskHh8TExISDQ0SEhMVDg4WBhA1FRElIiI5IBsbEBEREA0MERETLgACAAP/twNuAkoAIwBTAAAlFSMvASYnIwcGDwEjNTM3JyM1MxcWFxYXMzY/AjMVIwcXMwUVIScmNTQ3Njc2NzY3Njc2NTQnJiMiBwYHJzY3NjMyFxYVFAcGBwYHBgcGBzM1MwIBjlsOBAICBQYIWZNJcWpOnVABDAQCAgIEDlCTR2l0PwFt/toCAg8PFhYaGhYWDw8RERcdGwgMPA8VLj0/JycUFBwcHRwVFgKFSKlgkBgFBwwLDo9gpptgggIWBQcFBxiCYJipfHYPGgEkHh8TExISDQ0SEhMVDg4WBhA1FRElIiI5Jh4eExMQERMUFi4AAAAADAAAAAADbgNuAAoAEgAbADAAQwBlAHAAkQCfALIAxwDcAAAlNTQjIgcVFjMyNTczNTQjIh0BJRUjFSM1IzUzFxUjNQYjIicmPQEzFRQXFjMyNzUzFxUUBwYjIicVIxEzFTYzMhcWFRcVFAcGBwYjIicmPQE0NzYzMhcWHQEjFRQzMjc0NTQ9ATMBFRQjIj0BNDMyFQE0JyYnJicmIyIHBgcGBwYVFBcWFxYXFjMyNzY3Njc2NQE3IwcnIxcxFxYXFTM1FzU0JyYjIgcGHQEUFxYzMjc2NRczNSMVBiMiJzQ9ASMVFBcWMzI3FSURFAcGIyEiJyY1ETQ3NjMhMhcWFQINEAoJCQoQaSYTE/66LiothXMmFxUTBQMlAQEICw0mkAQHFxQTJycSFRcHBI8BAgYQHh4QDAsRHR0PDEwUDQQn/v8TEhITATALBRMTGU2enU4ZExIGCwsGEhMYT52dThkSEwYL/lEzKx0eLQ4NFAYrpQwRHB0PDAwPHRwRDGcnJwwMCAEnBAYSFRcBIDEwRP3cRDEwMDFEAiREMDHOWh0KgAkcRhMeHhOYKPLyKEjSFxoQChWmmg4BCRKgP1QeDBgYFQEaXBcYDB5KBREIDAsXFhAhSiIPFhYQISsmHQ8BAwQGDAHXWR4eWR0d/mhlMBkREQMICAMRERkyY2QwGRERAwkJAxERGTBkAXSpb28nJzsgc3MuSiERFhYRIUohERUVECJF1KISCgENnKgVCg8ZF6793EQxMDAxRAIkRDAxMTBEAAEAIwAAA90DbgCzAAAlIicmIyIHBiMiJyY1NDc2NzY3Njc2PQE0JyYjISIHBh0BFBcWFxYzFhcWFRQHBiMiJyYjIgcGIyInJjU0NzY3Njc2NzY9ARE0NTQ1NCc0JyYnJicmJyYnJiMiJyY1NDc2MzIXFjMyNzYzMhcWFRQHBiMGBwYHBh0BFBcWMyEyNzY9ATQnJicmJyY1NDc2MzIXFjMyNzYzMhcWFRQHBgciBwYHBhURFBcWFxYXMhcWFRQHBiMDwRkzMhoZMjMZDQgHCQoNDBEQChIBBxX+fhYHARUJEhMODgwLBwcOGzU1GhgxMRgNBwcJCQsMEA8JEgECAQIDBAQFCBIRDQ0KCwcHDho1NRoYMDEYDgcHCQoMDRAQCBQBBw8BkA4HARQKFxcPDgcHDhkzMhkZMTEZDgcHCgoNDRARCBQUCRERDg0KCwcHDgACAgICDAsPEQkJAQEDAwUMROAMBQMDBQzUUQ0GAQIBCAgSDwwNAgICAgwMDhEICQECAwMFDUUhAdACDQ0ICA4OCgoLCwcHAwYBAQgIEg8MDQICAgINDA8RCAgBAgEGDFC2DAcBAQcMtlAMBgEBBgcWDwwNAgICAg0MDxEICAEBAgYNT/3mRAwGAgIBCQgRDwwNAAABAAAAAQAAxj3R918PPPUACwQAAAAAANEgjwwAAAAA0SCPDAAA/7cESQPAAAAACAACAAAAAAAAAAEAAAPA/8AAAARJAAD//wRJAAEAAAAAAAAAAAAAAAAAAAAlAAAAAAAAAAAAAAAAAgAAAAQAAAAEAAAaBAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAQAQAAAAEAAAABAAAAAQAAAADtwAAAyUAAAJJAAAEAAAABAAAAAQAAAAEAAAABAAAAARJAAADtwAJBAAAAAQAAAkEAAAABAAAAAQAAAAESQAaBAAAAwQAAAMEAAAABAAAIwAAAAAACgAUAB4AbgC4APoBQAFcAbYB+gKUArIC9ANmA5oEMATSBZwGFAb4B24H5AhYCMwJMAnqCogLYgwEDLgNbg3mDmIO3A/+EPAAAQAAACUA3QAOAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAA4ArgABAAAAAAABABwAAAABAAAAAAACAA4AeAABAAAAAAADABwAMgABAAAAAAAEABwAhgABAAAAAAAFABYAHAABAAAAAAAGAA4ATgABAAAAAAAKADQAogADAAEECQABABwAAAADAAEECQACAA4AeAADAAEECQADABwAMgADAAEECQAEABwAhgADAAEECQAFABYAHAADAAEECQAGABwAXAADAAEECQAKADQAogBiAGIALQBlAGQAaQB0AG8AcgAtAGYAbwBuAHQAVgBlAHIAcwBpAG8AbgAgADEALgAwAGIAYgAtAGUAZABpAHQAbwByAC0AZgBvAG4AdGJiLWVkaXRvci1mb250AGIAYgAtAGUAZABpAHQAbwByAC0AZgBvAG4AdABSAGUAZwB1AGwAYQByAGIAYgAtAGUAZABpAHQAbwByAC0AZgBvAG4AdABGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==) format('truetype'),
	         url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAACdEAAsAAAAAJvgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAABCAAAAGAAAABgDxIPBmNtYXAAAAFoAAAA9AAAAPQ29C0zZ2FzcAAAAlwAAAAIAAAACAAAABBnbHlmAAACZAAAIeAAACHgMmxCaGhlYWQAACREAAAANgAAADYFqWKMaGhlYQAAJHwAAAAkAAAAJAgMBC5obXR4AAAkoAAAAJQAAACUg24Ar2xvY2EAACU0AAAATAAAAExzLnwUbWF4cAAAJYAAAAAgAAAAIAA0AN9uYW1lAAAloAAAAYQAAAGEvwA5TnBvc3QAACckAAAAIAAAACAAAwAAAAMEAAGQAAUAAAKZAswAAACPApkCzAAAAesAMwEJAAAAAAAAAAAAAAAAAAAAARAAAAAAAAAAAAAAAAAAAAAAQAAA8dwDwP/AAEADwABAAAAAAQAAAAAAAAAAAAAAIAAAAAAAAgAAAAMAAAAUAAMAAQAAABQABADgAAAANAAgAAQAFAABACDmAekR6RPpMOl36Y3p0eph6mjqcuqN8APwNPA58D7wwfDN8RjxIfEs8Wbx3P/9//8AAAAAACDmAOkR6RPpMOl36Y3p0eph6mjqcuqN8APwMfA28D7wwfDK8RjxIfEr8Wbx3P/9//8AAf/jGgQW9Rb0FtgWkhZ9FjoVqxWlFZwVghAND+AP3w/bD1kPUQ8HDv8O9g69DkgAAwABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAH//wAPAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAYAAP/ABAADwAADAAcACwAYACUAMgAAASE1IQEhNSEBITUhATQ2MzIWFRQGIyImNSE0NjMyFhUUBiMiJjUhNDYzMhYVFAYjIiY1BAD8AAQA/oD9gAKAAYD8AAQA/AAlGxslJRsbJQIAJRsbJSUbGyX/ACUbGyUlGxslA0CA/oCA/oCA/kAbJSUbGyUlGxslJRsbJSUbGyUlGxslJRsAAAACABoACAPoA6sADgArAAATBhYHBhY+ATc2JicuAQcBJg4CBw4BBwYWFx4BFx4BFx4BNz4BNz4DJ406FU4RO2d4LSUPKChjJgNbD53GwDExKw8GCwMUHhESFgoCBwgUOTExpJhkDwEWOX5XFAwSMislYSgnDyUClQ9jlaExMDgUCAcCChURER4TBAoGDyowML3Cmw8AAQAA/8AEAAPAACsAAAEzERQOAiMiLgI1ND4CMzIWFxEFERQOAiMiLgI1ND4CMzIWFxElA8BAIz1SLi5SPSMjPVIuL1Me/gAjPVIuLlI9IyM9Ui4vUx4CQAPA/SAhOiwZGSw6ISE6LBkaFgFwcv4SITosGRksOiEhOiwZGhYCcIAAAAAACQAAAEAEAANAAAQACQAOABMAGAAdACIAJwAqAAATESERIRMjNTMVESM1MxURIzUzFQEhESERMyM1MxURIzUzFREjNTMVIRElAAQA/ADAgICAgICAAkD+AAIAwICAgICAgP3AAQADQP0AAwD9QICAAQCAgAEAgID+AAKA/YCAgAEAgIABAICA/oDAAAACAAAAAAQAA0AAAwAKAAAlEyEDEwMRIRchFQNAwPzAwICAASCAAaAAAgD+AAJA/cADQICAAAAAAAIAAABABAEDAAAfAD8AABMyHgIVFA4CIyIuAjUnND4CMxUiBgcOAQc+ATMhMh4CFRQOAiMiLgI1JzQ+AjMVIgYHDgEHPgEz4S5SPSMjPVIuLlI9IwFGeqNdQHUtCRAHCBIJAkAuUj0jIz1SLi5SPSMBRnqjXUB1LQkQBwgSCQIAIz1SLi5SPSMjPVIuIF2jekaAMC4IEwoCASM9Ui4uUj0jIz1SLiBdo3pGgDAuCBMKAgEAAAIAAP/ABAADwAAiAC8AAAEiDgIVFBYXARUUFjsBNTM1MzUzNx4BMzI+AjU0LgIjEyImNTQ2MzIWFRQGIwLAQnVXMgMC/nslG0CAgIBTGjYdQnVXMjJXdUJgKDg4KCg4OCgDwDJXdUIPHQ/+e8AbJUCAgFMJCjJXdUJCdVcy/sA4KCg4OCgoOAAFAAAAAAQAA7IAHQAoADkARgBjAAABJiIPAS4BIyIOAgceARcHBhQXHgEzMjY3ATY0JwEyFhcHLgE1NDYzBT4BNz4BNw4BFRQWFwcuASclNCYnAR4BMzI+AjU3Bx4BFR4BFw4BBw4BIyImJwceATMyPgI3LgEnA7IOKA7KJ1IrVJqEaiQfWDafDg4HEgkJEgcDYA4O/e4gMQp6HCU4KP7OHUsuAgYDBwgZFj0oQhoCkgYG/r4TJxQ1XUYoPkUBAi5LHR1LLjiBQx05HE0tYDJUmoRqJCJjPQOyDg7KDAwvVHZHPmkonw4oDgcHBwcDYA4oDv7OJRx6CjEgKDjALU0cAgQCFSwXKUsfPRtGKUYUJxP+vgYGKEZdNZhFAQEBHE0tLU0cJCYHB00QES9UdkdDcSoAAAIAQP/AA8ADQAAHAA8AABMhFSMRIxEjASMRIxEjNSFAAYCAgIADgPyI/AKAAcCA/oABgAGA/QADAIAAAAcAAP/ABAADwAADAAcACwAPABMAGwAjAAATMxUjNzMVIyUzFSM3MxUjJTMVIwMTIRMzEyETAQMhAyMDIQMAgIDAwMABAICAwMDAAQCAgBAQ/QAQIBACgBD9QBADABAgEP2AEAHAQEBAQEBAQEBAAkD+QAHA/oABgPwAAYD+gAFA/sAAAA4AAP/ABAADwAADAAcADwATABcAHwAjACcALwAzADcAPwBEAEoAAAEzFSM3MxUjJREjNTM1IzUFMxUjNzMVIyUVMxUjETMVEzMVIzczFSMlESM1MzUjNQUzFSM3MxUjJRUzFSMRMxUBIREhETcxESERIQGAgIDAgIABQMCAQP5AgIDAgID+wECAwECAgMCAgAFAwIBA/kCAgMCAgP7AQIDAAoD8gAOAQPwABAADAEBAQED/AECAQMBAQEDAgEABAED+wEBAQED/AECAQMBAQEDAgEABAEACQPyAA4BA/AAEAAAAAAEAAP/ABAADwAAkAAABISIGFREUFjMhESM1MzU0NjsBFSMiBh0BMwcjETMyNjURNCYjA1X9VkdkZEcBVYCAXkKgoA0TsCCQ1UdkZEcDwGRH/VZHZAHAgGBCXoATDWCA/kBkRwKqR2QAAwAAAAAEAAMlACAAUABlAAAlEQYHBgcGBwYHBisBIicmJyYnJicmJxEUFxYzITI3NjURNTE1JiMGJyYHBichIgcGFRQXFhcWFxYXFhcWFxY7ATI3Njc2NzY3Njc2NzY3NjU3ERQHBiMhIicmNRE0NzYzITIXFhUDtxIWmVodEhMfHxsCGx8fExIdWpkWEgYFBwNKBwUGAQECAQIDBAT8tgcFBlRudwQQEQoJEBANDQsCCw0NEBAJChEQBHduHxobSRsbJfy2JRsbGxslA0olGxtbAbcUEXZMGA4ODg4ODg4OGEx2ERT+SQcFBgYFBwJZDgcIAQYFAQECBQUIYEJXXgMODggHCwoFBQUFCgsHCA4OA15XGCopIhX9kiUbGxsbJQJuJhsbGxsmAAAAAgAAAAADtwNuAAkAawAAAQMyFxYzMjcmJwE3Njc2NzY3Njc2NxsBMxYXExYXFhcWFxYXFhcWFxYXFhUUFQYVIicmIyIHBiM0PwEyNzY3Mjc2NzY3Njc2NTQnJicmJyUGBwYVFBcWFxYXFhcWMxQVFAciJyYjIgcGIwYjAZ5hEzs7IQsVMTj+YgENExMODQ8PCgsHiKBJBAJ1EyopGAgZGRAMCAsnKAgEASRISSQsT1AWAksBBgcCAgYGAwMDBAECEhIXFwH+/w8dHQgIERELCxUWAgEhQkMhBQoLAi0+Anf+/wEBAZFx/YktBAMDAwMGBQsLEgFgAZ4IBP7tLGdmNxM/PyEaBwkICAQVCwIGBQIFBAQEGBQQAgEBAgICAgIDBAMFCS4uNzgBAiJOTw4NCAkFBgIDAgILFgYKBgYDAggAAAAAAwAAAAADJQNuAB4APQCNAAAlFjMyNTQnJicmJyYnJicmIyIHFBUUFRQHBhcUFxYXAxYzMjc2NzY3NjU0JyYnJicmIyIHFBcWFRQVFBUUFQE3Njc2NzY3Njc2NzY1ND0BECcmJyYnJicmJyYjJzY3NjMyFzIzMhcWFxYXFhcWFRQHBgcGBwYHBgcWFxYVFAcGBwYHBgcGIyInJiMiBwYHAT0qJtcXEBQTExMbGxUVISoQAQEBAgMECBgmLyMjHBwPDhARHRwhISYdLQIC/ssBCSgoFAQDBAECAQIMAgsKDw8NDg4PAwI4iotLDRoaDCgmJiQjGhsQEAoJDQ0YGBIRH1g7OxQUIiEuLTAwNRkyMho8c3MRUhPAQSYZEREKCQUFAQEGHj08HgQiIhYVGhsLAaoEBwgSEiEhMCgeHhERCAgIHDo6HQ8eHw8aDf4ENgIHBwgHCQgLCggIDg0GJgIxGAUEAwMDAQECATABBQYBBwgQERgYJCMrHhkZEBAREAkKDRQ5OFY5LS4dHRQTCAgBAgYGAQABAAAAAAJJA24ATgAAPwE2NzY3Njc2NzY3Nj0BJicmJyYnNxYXFhcWMzI3Njc2NwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYVFxYXBgciBwYjIicmIyYjIgcGBwAKAysrFRAHASMjHh4OERIWFgsLEjIyJCMhHB0dKCgQAwgRKSkVBAQDAgICAwEPIyIKAQcGBQUEBAEKYAIHBwwMBxAhIRBPJx01NBEBMQELCwoUJgShoZaVFA8HAwMCAQI7AQMDAQEBAQMDARccBgoLCQoODQoJERAIVJucMAUcHBcYGBgJCgIQGR8BAQYFAgYFAQACAAAAAAP9A24AIgCkAAAlMhcWDwEGIyIvASY3NjsBESMiJyY/ATYzMh8BFgcGKwERMwEXFjMyNzYzMjMyOwEyFzIzNjc2NzY/ATIXMjMWFRQHBgcmJyYnJicmIyYnJicmIyYjBiMiJyIjIgcGBwYXFBcWFRQHBhcWFxYXFhcWFRQPAQYnJiMiBwYjJj0BNjc2NzY3NjU0JyY9ATQ1NDU0NSYnJicmIyIHBgcGBwYHBgcmJzUD5RIGBQxICxEQDEgLBQUTLi4TBQULSAwQEQtIDAUGEi4u/EkfB3IZMjIaFCkpFKgDCQgEAwYGBAQEGAMFBgIBAhcQDxACBAUEAwEDBAMGBQICCAkBChwcDg8WFhMFAQEBAQICAQYXMDAUAwITK1JRJRw6Oh0CChkaHx8NCwIBAQEBAgZWEyMiCwsJCAoJDxgIkgoLD1wPD1wPCwoCSQsLDl0PD10OCwv9twLbDwMBAQEBAQEEBAYBAUCALhAIAhkwBRYWFBQFAwIBAQEBAQEBAy4fNqioXAkgIBQVEwwMDAkXBggIAQEGBQUFHQEFDwkKBwcIGMM6c3Q6QgIHCAcGCAgGBgIHBwcIByIiHh0BDgvbAAAEAAAASQQAA24AFAApAD4AUwAAJRUUBwYjISInJj0BNDc2MyEyFxYVJxUUBwYjISInJj0BNDc2MyEyFxYVNxUUBwYjISInJj0BNDc2MyEyFxYVJxUUBwYjISInJj0BNDc2MyEyFxYVBAALCw/8Sg8LCwsLDwO2DwsL2wsLD/0lDwsLCwsPAtsPCwuSCwsP/JMPCwsLCw8DbQ8LC9wKCw/9bg8LCwsLDwKSDwsKt0kPCwsLCw9JDwsKCgsP20kPCwoKCw9JDwsLCwsP3EkPCwsLCw9JDwoLCwoP20kPCwsLCw9JDwsLCwsPAAAAAAQAAABJBAADbgAUACkAPgBTAAAlFRQHBiMhIicmPQE0NzYzITIXFhUnFRQHBiMhIicmPQE0NzYzITIXFhU3FRQHBiMhIicmPQE0NzYzITIXFhUnFRQHBiMhIicmPQE0NzYzITIXFhUEAAsLD/xKDwsLCwsPA7YPCwvbCwsP/gAPCwsLCw8CAA8LC5ILCw/83A8LCwsLDwMkDwsL3AoLD/6SDwsKCgsPAW4PCwq3SQ8LCwsLD0kPCwoKCw/bSQ8LCgoLD0kPCwsLCw/cSQ8LCwsLD0kPCgsLCg/bSQ8LCwsLD0kPCwsLCw8AAAAABAAAAEkEAANuABQAKQA+AFMAACUVFAcGIyEiJyY9ATQ3NjMhMhcWFTUVFAcGIyEiJyY9ATQ3NjMhMhcWFTUVFAcGIyEiJyY9ATQ3NjMhMhcWFTUVFAcGIyEiJyY9ATQ3NjMhMhcWFQQACwsP/EoPCwsLCw8Dtg8LCwsLD/0lDwsLCwsPAtsPCwsLCw/8kw8LCwsLDwNtDwsLCwsP/W4PCwoKCw8Ckg8LC7dJDwsLCwsPSQ8LCgoLD9tJDwsKCgsPSQ8LCwsLD9xJDwsLCwsPSQ8KCwsKD9tJDwsLCwsPSQ8LCwsLDwAAAAQAAABJBAADbgAUACkAPgBTAAAlFRQHBiMhIicmPQE0NzYzITIXFhU1FRQHBiMhIicmPQE0NzYzITIXFhU1FRQHBiMhIicmPQE0NzYzITIXFhU1FRQHBiMhIicmPQE0NzYzITIXFhUEAAsLD/xKDwsLCwsPA7YPCwsLCw/8Sg8LCwsLDwO2DwsLCwsP/EoPCwsLCw8Dtg8LCwsLD/xKDwsLCwsPA7YPCwu3SQ8LCwsLD0kPCwoKCw/bSQ8LCgoLD0kPCwsLCw/cSQ8LCwsLD0kPCgsLCg/bSQ8LCwsLD0kPCwsLCw8AAAAEAAAAAARJA24AEAAXACwAQQAAARQHBiMiJyY1NDc2MzIXFhUFESE1NxcBJSEiBwYVERQXFjMhMjc2NRE0JyYjFxEUBwYjISInJjURNDc2MyEyFxYVAW4gIC4uICAgIC4uICACSfzbt1wBJAEl/G0HBQYGBQcDkwcGBQUGB1sbGyX8bSUbGxsbJQOTJRsbAm4uICAgIC4tICAgIC3c/wBut1wBJaUGBQj9SQcFBgYFBwK3CAUGE/1JJRsbGxslArcmGxsbGyYAAAMACQAJA64DrgArAFcAgAAAATQvASYjIgcWFxYXFhcWFxYVFAcGIyInJicmJyYnJicGFRQfARYzMj8BNjUBNC8BJiMiDwEGFRQfARYzMjcmJyYnJicmJyY1NDc2MzIXFhcWFxYXFhc2NQEUDwEGIyIvASY1NDcnBiMiLwEmNTQ/ATYzMh8BFhUUBxc2MzIfARYVA0AQdxAXGBECCQkDAwYFAgIQEBcIBwcIBwQDCQkCEhB1EBcXEFQQ/m4QdRAXFxBUEBB3DxgYEQIJCQMEBQUCAhAQFgkHBwgHBAMJCQETAgAxVC9FRS92MDMzMUVFMHcwMVQvRUUvdi8yMjJFRTB3MAEAFxB3EBMBCQkDBAcIBwcJFhAQAgIFBQQDCQkCEhgXEHYQD1QQFgGTFxB2EA9UEBYXEHcPEQIJCQMEBwgHBwgXEBACAgUGAwMJCQISGP5tRS9TMDF2L0VGMTMzMHcwRUQwUzAxdjBERjIyMjB2MEUAAAYAAAAlBAADSQAQACEANgBHAFwAcQAANxQHBiMiJyY1NDc2MzIXFhURFAcGIyInJjU0NzYzMhcWFQUVFAcGIyEiJyY9ATQ3NjMhMhcWFQEUBwYjIicmNTQ3NjMyFxYVBRUUBwYjISInJj0BNDc2MyEyFxYVERUUBwYjISInJj0BNDc2MyEyFxYV2yAgLS4gICAgLi0gICAgLS4gICAgLi0gIAMlBQYH/UkIBQUFBQgCtwcGBfzbICAtLiAgICAuLSAgAyUFBgf9SQgFBQUFCAK3BwYFBQYH/UkIBQUFBQgCtwcGBZItICAgIC0uICAgIC4BJS4gICAgLi4gICAgLu5uBwUGBgUHbggFBQUFCAISLSAgICAtLiAgICAu7W4HBgUFBgduBwYFBQYHASRtCAUGBgUIbQgFBgYFCAAGAAn/twQAA7IAJQBOAGMAdQCKAJ8AADcUBwYjIic3FjMyNzY1NAcnNjc2NzY3NSIHIiMVIzUzFQcWFxYVExUjJjU0NzY3Njc2NzY1NCcmIyIHJzY3NjMyFxYVFAcGBwYHBgczNTMFFRQHBiMhIicmPQE0NzYzITIXFhUBFSM1MzQ1Nj0BIwYHJzczFTMFFRQHBiMhIicmPQE0NzYzITIXFhURFRQHBiMhIicmPQE0NzYzITIXFhXaHyAuPCYgHCERDAw8DwUODgoKCwkSEwk9vzcdEhEBzwMNDRMTExMNDgkIDhoUMQ4bGyEqHB0TFBcYExQBSTwDJQUGB/1JCAUFBQUIArcHBgX82789AQEFGClOPT0DJQUGB/1JCAUFBQUIArcHBgUFBgf9SQgFBQUFCAK3BwYFGS4aGiYyGggJECQEIAUUEwsMCgEBHlYyQgYWFR0BZloUCh4YGA4PDQwMDQ0OCAghIR4QEBgXKRwYGA0NEBAOIrZuBwUGBgUHbggFBQUFCAICOTkXLy4XBwoVK0nn3W4HBgUFBgduCAUFBQYHASRtCAUGBgUIbQgFBgYFCAAAAwAAAAAEAANuABQAOwBuAAABMhcWHQEUBwYjISInJj0BNDc2MyElJicmNTQ3NjMyFxYXFhcWFRQPAS8BJicmIyIHBhUUFxYXFhcWFyEFMxYVFAcGBwYHBgcGIyIvASYnJj0BNCcmPwE1NxYXFhcWFxYXFhcWMzI3Njc2NTQnJicD7ggFBQUFCPwkCAUFBQUIA9z9JhANHE1MlRxDJj8GBggDBzAIHB4zRUImJyYmeSg7IRb+VwEi6wQYDRsWKS0qLkZBL1AgCQQBAQEBOgkICQQEAxQaGCQiKSUrLBkbLhM7AbcFBQglCAUFBQUIJQgFBSQUGjg0Z0lJCwcVFS5GIwoPAgMCVSA0IiEyKiYnIwwaEA6SFh5AOh8cFBocCgwNFwkHBQgHPhsRFhUZARMVFQsLBSAVFQwMDw8iIycwKhAYAAAAAgAAAAADbgNuAGgAfQAAEyYvATYzMhcWMzI3NjcyNxUXFQYjIgcGFRQXFBUfARYXFhcWMzI3Njc2NzY3NjU0JyYnJi8BJicmDwEnNzMXFjcXFhUUBwYHBgcGFRQXFBUWFxYHBgcGBwYHBiMiJyYnJicmPQE0JyYnATU0JyYjISIHBh0BFBcWMyEyNzY1GxUEAgcQIh5LFDEvQhEgEQEiJSILCAEBCAMaFCMyMzsyIBgcChQKDAICBAUDAgMLFBg5CAEwdStFCgQDGRcpBAgBBQgDDAgPFiorPT5UX0NEIiMNCQoORgNTBQYI/LcIBQUFBQgDSQgGBQM3AgEyAQMEAgIBAQglBQUOCEQHCwsEg6BGLSITGhAKExQQICEqWS0cHCoqMiEnDBQBAQIxBgIIARYIBA0HAQYDCQ8ECwwGC9dwPisbJSEhEhMbGissRC1avmwOFQH82yUIBQUFBQglCAUFBQUIAAAABQAAAAADbgNuACAAMQBCAGMAfAAAAQYHBiMiJyYnJjc2NzYXFhcWFxYzMjc2NzY3NhcWFxYHJRQHBiMiJyY1NDc2MzIXFhUhFAcGIyInJjU0NzYzMhcWFRc0JyYnJicmIyIHBgcGBwYVFBcWFxYXFjMyNzY3Njc2NTMUBwYHBiMiJyYnJjU0NzY3NjMyFxYXFhUCiBU6OkhJOToVBQcHDw4NDgQPJicwMCYnDgUODQ8OBwcF/uYWFR4fFRYWFR8eFRYBJBUWHh4WFRUWHh4WFZMeHTEwRERKSkREMTEdHR0dMTFEREpKREQwMR0eSTs7ZWV3eGRlOzs7O2VkeHdlZTs7AVFGKioqKkYODQ4EBQcHDy0dHBwdLQ8HBwUEDg0O+B4WFRUWHh4WFRUWHh4WFRUWHh4WFRUWHpJKREQwMR0eHh0xMERESkpERDExHR0dHTExRERKeGRlOzs7O2VkeHdlZTs7OztlZXcAAAMAGgALBC8DGgAaAC8ASgAAJQcGIyInASY1NDcBNjMyHwEWFRQPARcWFRQHAQMGBwYvASYnJjcTNjc2HwEWFxYHCQEGIyIvASY1ND8BJyY1ND8BNjMyFwEWFRQHAWEdBgcIBf71BQUBCwUIBwYdBQXh4QUFAVHVAgcGByQHBAMC1QIHBgckBwQEAwF4/vUFCAcGHAYG4OAGBhwGBwgFAQsFBZccBgYBCgYHCAUBCwUFHQYHBwbh4AYHCAYCYv0eBwQDAgoCBgcHAuIIAwQCCgIHBgj+jP72BgYcBggHBuDhBgcHBh0FBf71BQgHBgAAAAIAAwBJA20DYgAjAFUAACUVIy8BJicjBwYPASM1MzcnIzUzFxYXFhczNj8CMxUjBxczARUhJyY1NDc2NzY3Njc2NzY1NCcmIyIHBgcnNjc2MzIXFhUUBwYHBgcGBwYHBgczNTMCAY5bDgQCAgUGCFmTSXFqTp1QAQwEAgICBA5Qk0dpdD8BbP7aAgIPDxYWGhoWFg8PEREXHRsIDDwPFS88PycnDg4WFRkZFhYQDwKFSKlgkBgFBwwLDo9gpptgggIWBQcFBxiCYJipAYR2DxALJB4fExMSEg0NEhITFQ4OFgYQNRURJSIiOSAbGxARERANDBEREy4AAgAD/7cDbgJKACMAUwAAJRUjLwEmJyMHBg8BIzUzNycjNTMXFhcWFzM2PwIzFSMHFzMFFSEnJjU0NzY3Njc2NzY3NjU0JyYjIgcGByc2NzYzMhcWFRQHBgcGBwYHBgczNTMCAY5bDgQCAgUGCFmTSXFqTp1QAQwEAgICBA5Qk0dpdD8Bbf7aAgIPDxYWGhoWFg8PEREXHRsIDDwPFS49PycnFBQcHB0cFRYChUipYJAYBQcMCw6PYKabYIICFgUHBQcYgmCYqXx2DxoBJB4fExMSEg0NEhITFQ4OFgYQNRURJSIiOSYeHhMTEBETFBYuAAAAAAwAAAAAA24DbgAKABIAGwAwAEMAZQBwAJEAnwCyAMcA3AAAJTU0IyIHFRYzMjU3MzU0IyIdASUVIxUjNSM1MxcVIzUGIyInJj0BMxUUFxYzMjc1MxcVFAcGIyInFSMRMxU2MzIXFhUXFRQHBgcGIyInJj0BNDc2MzIXFh0BIxUUMzI3NDU0PQEzARUUIyI9ATQzMhUBNCcmJyYnJiMiBwYHBgcGFRQXFhcWFxYzMjc2NzY3NjUBNyMHJyMXMRcWFxUzNRc1NCcmIyIHBh0BFBcWMzI3NjUXMzUjFQYjIic0PQEjFRQXFjMyNxUlERQHBiMhIicmNRE0NzYzITIXFhUCDRAKCQkKEGkmExP+ui4qLYVzJhcVEwUDJQEBCAsNJpAEBxcUEycnEhUXBwSPAQIGEB4eEAwLER0dDwxMFA0EJ/7/ExISEwEwCwUTExlNnp1OGRMSBgsLBhITGE+dnU4ZEhMGC/5RMysdHi0ODRQGK6UMERwdDwwMDx0cEQxnJycMDAgBJwQGEhUXASAxMET93EQxMDAxRAIkRDAxzlodCoAJHEYTHh4TmCjy8ihI0hcaEAoVppoOAQkSoD9UHgwYGBUBGlwXGAweSgURCAwLFxYQIUoiDxYWECErJh0PAQMEBgwB11keHlkdHf5oZTAZEREDCAgDEREZMmNkMBkREQMJCQMRERkwZAF0qW9vJyc7IHNzLkohERYWESFKIREVFRAiRdSiEgoBDZyoFQoPGReu/dxEMTAwMUQCJEQwMTEwRAABACMAAAPdA24AswAAJSInJiMiBwYjIicmNTQ3Njc2NzY3Nj0BNCcmIyEiBwYdARQXFhcWMxYXFhUUBwYjIicmIyIHBiMiJyY1NDc2NzY3Njc2PQERNDU0NTQnNCcmJyYnJicmJyYjIicmNTQ3NjMyFxYzMjc2MzIXFhUUBwYjBgcGBwYdARQXFjMhMjc2PQE0JyYnJicmNTQ3NjMyFxYzMjc2MzIXFhUUBwYHIgcGBwYVERQXFhcWFzIXFhUUBwYjA8EZMzIaGTIzGQ0IBwkKDQwREAoSAQcV/n4WBwEVCRITDg4MCwcHDhs1NRoYMTEYDQcHCQkLDBAPCRIBAgECAwQEBQgSEQ0NCgsHBw4aNTUaGDAxGA4HBwkKDA0QEAgUAQcPAZAOBwEUChcXDw4HBw4ZMzIZGTExGQ4HBwoKDQ0QEQgUFAkREQ4NCgsHBw4AAgICAgwLDxEJCQEBAwMFDETgDAUDAwUM1FENBgECAQgIEg8MDQICAgIMDA4RCAkBAgMDBQ1FIQHQAg0NCAgODgoKCwsHBwMGAQEICBIPDA0CAgICDQwPEQgIAQIBBgxQtgwHAQEHDLZQDAYBAQYHFg8MDQICAgINDA8RCAgBAQIGDU/95kQMBgICAQkIEQ8MDQAAAQAAAAEAAMY90fdfDzz1AAsEAAAAAADRII8MAAAAANEgjwwAAP+3BEkDwAAAAAgAAgAAAAAAAAABAAADwP/AAAAESQAA//8ESQABAAAAAAAAAAAAAAAAAAAAJQAAAAAAAAAAAAAAAAIAAAAEAAAABAAAGgQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAEAEAAAABAAAAAQAAAAEAAAAA7cAAAMlAAACSQAABAAAAAQAAAAEAAAABAAAAAQAAAAESQAAA7cACQQAAAAEAAAJBAAAAAQAAAAEAAAABEkAGgQAAAMEAAADBAAAAAQAACMAAAAAAAoAFAAeAG4AuAD6AUABXAG2AfoClAKyAvQDZgOaBDAE0gWcBhQG+AduB+QIWAjMCTAJ6gqIC2IMBAy4DW4N5g5iDtwP/hDwAAEAAAAlAN0ADgAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAOAK4AAQAAAAAAAQAcAAAAAQAAAAAAAgAOAHgAAQAAAAAAAwAcADIAAQAAAAAABAAcAIYAAQAAAAAABQAWABwAAQAAAAAABgAOAE4AAQAAAAAACgA0AKIAAwABBAkAAQAcAAAAAwABBAkAAgAOAHgAAwABBAkAAwAcADIAAwABBAkABAAcAIYAAwABBAkABQAWABwAAwABBAkABgAcAFwAAwABBAkACgA0AKIAYgBiAC0AZQBkAGkAdABvAHIALQBmAG8AbgB0AFYAZQByAHMAaQBvAG4AIAAxAC4AMABiAGIALQBlAGQAaQB0AG8AcgAtAGYAbwBuAHRiYi1lZGl0b3ItZm9udABiAGIALQBlAGQAaQB0AG8AcgAtAGYAbwBuAHQAUgBlAGcAdQBsAGEAcgBiAGIALQBlAGQAaQB0AG8AcgAtAGYAbwBuAHQARgBvAG4AdAAgAGcAZQBuAGUAcgBhAHQAZQBkACAAYgB5ACAASQBjAG8ATQBvAG8AbgAuAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=) format('woff');
	    font-weight: normal;
	    font-style: normal;
	}

	[class^="bb-btn"], [class*=" bb-btn"] {
	    font-family: 'bb-editor-font';
	    speak: none;
	    font-style: normal;
	    font-weight: normal;
	    font-variant: normal;
	    text-transform: none;
	    line-height: 1;
	    font-size: 14px;
	    -webkit-font-smoothing: antialiased;
	    -moz-osx-font-smoothing: grayscale;
	}

	.bb-sel { float: left; padding: 2px 2px 0 2px; }
	.bb-sel select { font-size: 11px; }
	.bb-sep { display: inline-block; float: left; width: 1px; padding: 2px; }
	.bb-btn { cursor: pointer;  outline: 0; }

	#b_font select, #b_size select { padding: 0;}

	#b_b:before {content: "\f032";}
	#b_i:before {content: "\f033";}
	#b_u:before {content: "\f0cd";}
	#b_s:before {content: "\f0cc";}
	#b_img:before { content: "\f03e"; }
	#b_up:before { content: "\e930"; }
	#b_emo:before { content: "\f118"; }
	#b_url:before { content: "\f0c1"; }
	#b_leech:before { content: "\e98d"; }
	#b_mail:before { content: "\f003"; }
	#b_video:before { content: "\e913"; }
	#b_audio:before { content: "\e911"; }
	#b_hide:before { content: "\e9d1"; }
	#b_quote:before { content: "\e977"; }
	#b_code:before { content: "\f121"; }
	#b_left:before { content: "\f036"; }
	#b_center:before { content: "\f037"; }
	#b_right:before { content: "\f038"; }
	#b_color:before { content: "\e601"; }
	#b_spoiler:before { content: "\e600"; }
	#b_fla:before { content: "\ea8d"; }
	#b_yt:before { content: "\f166"; }
	#b_tf:before { content: "\ea61"; }
	#b_list:before { content: "\f0ca"; }
	#b_ol:before { content: "\f0cb"; }
	#b_tnl:before { content: "\ea61"; }
	#b_br:before { content: "\ea68"; }
	#b_pl:before { content: "\ea72"; }
	#b_size:before { content: "\f034"; }
	#b_font:before { content: "\f031"; }
	#b_header:before { content: "\f1dc"; }
	#b_sub:before { content: "\f12c"; }
	#b_sup:before { content: "\f12b"; }
	#b_justify:before { content: "\f039"; }

	.bb-pane h1, .bb-pane h2, .bb-pane h3, .bb-pane h4, .bb-pane h5, .bb-pane h6 { margin-top: 5px; margin-bottom: 5px; }
	.bb-pane h1 { font-size: 36px; }
	.bb-pane h2 { font-size: 30px; }
	.bb-pane h3 { font-size: 24px; }
	.bb-pane h4 { font-size:18px; }
	.bb-pane h5 { font-size:14px; }
	.bb-pane h6 { font-size:12px; }
	.bb-pane-dropdown {
		position: absolute;
		top: 100%; left: 0;
		z-index: 1000;
		display: none;
		min-width: 180px;
		padding: 5px 0; margin: 2px 0 0;
		list-style: none;
		font-size: 11px;
		border: 1px solid #e6e6e6; border-color: rgba(0,0,0,0.1);
		border-radius: 2px;
		background: #fff;
		background-clip: padding-box;
		-webkit-box-shadow: 0 1px 2px #dadada; box-shadow: 0 1px 2px #dadada;
		max-height: 300px;
    	overflow: auto;
	}
	.bb-pane-dropdown > li > a {
		display: block;
		padding: 3px 10px;
		clear: both;
		font-weight: normal;
		line-height: 1.42857;
		color: #353535;
		white-space: nowrap;
	}
	.bb-pane-dropdown > li > a:hover { text-decoration:none; color: #262626; background-color:whitesmoke; }
	.bb-pane-dropdown .color-palette div .color-btn {
		width: 17px; height: 17px;
		padding: 0; margin: 0;
		border: 1px solid #fff;
		cursor: pointer;
	}
	.bb-pane-dropdown .color-palette { padding: 0px 5px; }

	.bb-pane-dropdown table { margin: 0px; }
	
	.emoji_box {
		width:100%;
		max-width: 390px;
	}
	.emoji_category {
		padding:7px;
		clear:both;
	}
	.emoji_list {
		margin-top:5px;
		margin-bottom:5px;
		width:100%;
		font-family:'Apple Color Emoji', 'Segoe UI Emoji', 'NotoColorEmoji', 'Segoe UI Symbol', 'Android Emoji', 'EmojiSymbols';
		font-size:2em;
	}
	.emoji_symbol {
		float:left;
		margin-bottom: 10px;
		width:12.5%;
		text-align:center;
	}
	
	.emoji_symbol a,  .emoji_symbol a:hover {
		cursor: pointer;
		text-decoration:none;
	}
	
/*---Поля быстрого редактирования публикаций на сайте---*/
.quick-edit-text { padding: .4em; width: 350px; }
	.quick-edit-textarea {
		height: 250px; padding: 2px;
		border: 1px solid #d7d7d7;
		width: 100%;
		box-shadow:inset 0 1px 1px rgba(0, 0, 0, 0.075);
		-webkit-transition:border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
		transition:border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
	}

/*---Быстрый ответ на комментарии, упрощенная форма---*/
#dlefastreplycomments {
	padding: 10px;
}
/*---Выделение текста и всплывающее окно (поделиться ссылкой)---*/
#marker-bar,
	#txtselect_marker {
		display: block;
		visibility: hidden;
		position: absolute;
		z-index: 1200;
		opacity: 0;
		-webkit-transition: opacity .4s, visibility .1s linear .4s;
		transition: opacity .4s, visibility .1s linear .4s;
	}
	#txtselect_marker {
		cursor: pointer;
		background:url(/templates/lifesport/dleimages/marker.png) no-repeat 0 0;
	}
	#txtselect_marker:hover { background-position: 0 -32px; }
	#marker-bar{
		border: 1px solid #ccc;
		border-radius: 15px;
		background: #fff;
		padding: 5px 10px;
		cursor: default;
		box-shadow: 0 0 4px #ccc; -webkit-box-shadow: 0 0 4px #ccc;
	}
	#marker-bar.show {
		-webkit-transition: opacity .4s, visibility 0s;
		transition: opacity .4s, visibility 0s;
		opacity: 1;
		visibility: visible;
	}
	#txtselect_marker.show {
		visibility: visible;
		width: 32px; height: 32px;
		-webkit-transition: opacity .4s, visibility 0s;
		transition: opacity .4s, visibility 0s;
		opacity: 1;
	}
	#marker-bar .masha-social,
	#marker-bar .masha-marker{
		cursor: pointer;
		display: block;
		margin: 0 5px;
		float: left;
	}
	#marker-bar .masha-marker{
		line-height: 1em;
		color: #aaa;
		border-bottom: 1px dotted #aaa;
		margin-right: 10px;
	}
	#marker-bar .masha-marker:hover {
		color: #ea3e26;
		border-color: #ea3e26;
	}
	.user_selection, .user_selection_true {
		background: #fff5d5;
		padding: 2px 0;
	}
	.user_selection a.txtsel_close,
	.user_selection_true a.txtsel_close { display: none; }
	.user_selection .closewrap, .user_selection_true .closewrap { position: relative; }
	.user_selection.hover a.txtsel_close, .user_selection_true.hover a.txtsel_close {
		display: inline-block;
		position: absolute;
		top: -7px; left: -5px;
		width: 33px; height: 33px;
		background: url(/templates/lifesport/dleimages/closemarker.png) 0 0 no-repeat;
	}
	.user_selection.hover a.txtsel_close:hover,
	.user_selection_true.hover a.txtsel_close:hover { background-position: -0px -33px; }

	#share-popup {
		border: 1px solid #e6e6e6; border-color: rgba(0,0,0,0.1);
		border-radius: 2px;
		background: #fff;
		position: absolute; z-index: 100;
		width: 414px;
		display: none;
		padding: 20px 0;
		opacity: 0;
		box-shadow: 0 8px 40px -10px rgba(0,0,0,0.3);
		background-clip: padding-box;
		-webkit-transition: opacity .4s, visibility .1s linear .4s;
		transition: opacity .4s, visibility .1s linear .4s;
	}
	#share-popup.show {
		display: block; opacity: 1;
		-webkit-transition: opacity .4s, visibility 0s;
		transition: opacity .4s, visibility 0s;
	}
	#share-popup .social { padding: 0 0 10px 17px; }
	#share-popup .social p { padding-bottom: 10px; margin: 0; font-weight: bold;}
	#share-popup .social ul { list-style: none; margin: 0; padding: 0; }
	#share-popup .social ul li { display: inline; margin-right: 20px; padding-top: 2px; }
	#share-popup .social ul a {
		text-decoration: none;
		font-size: 12px;
		display: inline-block;
		color: #919191;
	}
	#share-popup .social ul a:hover { text-decoration: underline; }
	#share-popup .social a span {
		cursor: pointer;
		width: 20px; height: 20px;
		background: url(/templates/lifesport/dleimages/social-icons.png) 20px 20px no-repeat;
		display: inline-block;
		vertical-align: middle;
		margin: -3px 5px 0 0;
	}
	#share-popup .social .tw span { background-position: 0 -20px; }
	#share-popup .social .tw:hover span { background-position: 0 0; }
	#share-popup .social .fb span { background-position: -20px -20px; } 
	#share-popup .social .fb:hover span { background-position: -20px 0; }
	#share-popup .social .vk span{ background-position: -40px -20px; }
	#share-popup .social .vk:hover span { background-position: -40px 0; }
	#share-popup .social .gp span{ background-position: -60px -20px; }
	#share-popup .social .gp:hover span { background-position: -60px 0; }
	#share-popup .link {
		clear: both;
		border-top: 1px solid #d9d9d9;
		padding: 10px 5px 0 10px;
		line-height: 1.2;
		overflow: hidden;
		margin: 0 7px;
	}
	#share-popup .link p {
		font-weight: bold;
		padding: 0 0 3px 0;
		margin: 0;
	}
	#share-popup .link span {
		color: #999;
		font-size: 10px;
		display: block;
		padding-top: 3px;
	}
	#share-popup .link a { display: block; }
	.dle-alert, .dle-confirm, .dle-promt { padding: 20px 1em !important; }


.com_content .text {padding: 0px 10px;}

	/* Настройка стандартной капчи */
	.form_submit .c-captcha { float: right; }
	.c-captcha { position: relative; }
	.c-captcha:after { clear: both; display: block; content: ""; }
	.c-captcha > a { float: left; margin-right: 5px; }
	.c-captcha img {
		position: relative;
		display: block;
		width: 130px; height: 46px;
		z-index: 1;
		-webkit-transition: all ease .2s; transition: all ease .2s;
	}
	.c-captcha > input { float: left; width: 130px; }

	/* Настройка стандартной капчи при ответах на комментарии */
	.dle-captcha { position: relative; }
	.dle-captcha:after { clear: both; display: block; content: ""; }
	.dle-captcha > a { float: left; margin-right: 5px; }
	.dle-captcha img {
		position: relative;
		display: block;
		width: 130px; height: 46px;
		-webkit-transition: all ease .2s; transition: all ease .2s;
	}
	.dle-captcha > input { float: left; width: 130px; }




@media screen and (max-width:1063px) {

#sec_code {width: 50%;}

.c-captcha > a {width: 48%;}
}

@media screen and (max-width:868px) {


#sec_code {width: 50%;}

.c-captcha > a {width: 48%;}

.btn-big {
    height: 46px;
    width: 100%;
    padding: 12px 27px;
    margin-top: 20px;
}




}




/* --- Настройка кнопок --- */
.btn, .bbcodes, .btn-border {
	border: 0 none;
	display: inline-block;
	vertical-align: middle;
	cursor: pointer;
	height: 36px;
	border-radius: 8px;
	line-height: 22px;
	outline: none;
	background-color: #3394e6;
	color: #fff;
	border: 0 none;
	padding: 7px 22px;
	text-decoration: none !important;
	box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
	-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
	-webkit-transition: all ease .1s; transition: all ease .1s;
}
	.btn > .icon { fill: #fff; }
	.btn-white > .icon { fill: #3394e6; }
	.btn-white { background-color: #fff; color: #3394e6; }
		.btn-white:hover > .icon { fill: #fff; }
		.btn-white:hover { background-color: #3394e6; color: #fff; }

	.btn-big { height: 46px; padding: 12px 27px; border-radius: 23px; }

	.btn-border {
		color: #3394e6;
		border: 2px solid #3394e6;
		line-height: 22px;
		padding: 5px 20px;
		background-color: transparent !important;
		overflow: hidden;
		box-shadow: inset 0 0 0 0 transparent; -webkit-box-shadow: inset 0 0 0 0 transparent;
	}
	.btn-border:hover {
		box-shadow: inset 0 0 0 2px rgba(51,148,230,0.2); -webkit-box-shadow: inset 0 0 0 2px rgba(51,148,230,0.2);
	}

/*---Дополнительные поля---*/
table.xfields {
	width: 100%;
}
.xfields textarea, .xprofile textarea {
    width: 100%;
    height: 186px;
    margin-top: 5px;
}
.xfields input[type="text"] {
	width: 100%;
}

.xfieldsdescr {
	width: 200px;
}
.xfields .bb-pane + textarea {
    margin-top: 0px;
}
.xfieldsnote {
	color: #838383;
    font-size: .9em;
}

.xfields_table td {
    vertical-align: top;
}
.xfieldsrow {
	padding-top:10px;
	clear: both;
}
.xfieldscolleft {
	float: left;
	width: 30%;
}
.xfieldscolright {
	float: left;
	width: 70%;
}
.file-box {
	width: 95%;
	max-width: 437px;
	border:1px solid #B3B3B3;
	-moz-border-radius: 3px; -webkit-border-radius: 3px; border-radius: 3px;
	background-color: #F5F5F5;
	padding: 10px;
	margin-top: 10px;
}

.xfieldimagegallery {
  margin: 0;
  padding: 0;  
  list-style: none;
  clear: both;
}

.xfieldimagegallery li {
	list-style: none;
	margin: 0;
	padding: 0;  
}

.xfieldimagegallery li img {
  float: left;
  margin-right: 5px;
  border: 5px solid #fff;
  width: 100px;
  height: 100px;
  transition: box-shadow 0.5s ease;
}

.xfieldimagegallery li img:hover {
  box-shadow: 0px 0px 7px rgba(0,0,0,0.4);
}

.qq-uploader { position:relative; width: 100%;}

.qq-upload-button {
    display:inline-block;
    margin-top:5px;
    margin-bottom:5px;
	cursor:pointer;
}
.qq-upload-drop-area {
    position:absolute; top:0; left:0; width:100%; height:100%; z-index:2;
	max-width: 437px;
    background:#FF9797; text-align:center; 
}
.qq-upload-drop-area span {
    display:block; position:absolute; top: 50%; width:100%; margin-top:-8px; font-size:16px;
}

.qq-upload-drop-area-active {background:#FF7171;}

.uploadedfile {
	display: inline-block;
    width: 115px;
    height: 160px;
    margin: 10px 5px 5px 5px;
    border:1px solid #B3B3B3;
    box-shadow: 0px 1px 4px rgba(0,0,0,0.3);
    -moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
    text-align: center;
    background:#ffffff;

}

.uploadedfile .uploadimage {
    margin-top: 5px;
    width: 115px;
    height: 90px;
	display: flex;
    align-items: center;
    justify-content: center;
    cursor: move;
    cursor: -webkit-grabbing;
}

.sortable-ghost {
	opacity: 0.4;
}
.uploadedfile .info {
    text-align: left;
    white-space: nowrap;
    margin: 0px 5px 0px 5px;
    overflow: hidden;
}

.btn.disabled, .btn[disabled], fieldset[disabled] .btn {
    cursor:not-allowed;
    pointer-events:none;
    opacity:0.65;
    filter:alpha(opacity=65);
    -webkit-box-shadow:none;
    box-shadow:none;
}

.progress {
    overflow:hidden;
    margin-top:10px;
	margin-bottom:10px;
    background-color:whitesmoke;
    height:10px;
    -webkit-border-radius:8px;
    -moz-border-radius:8px;
    -ms-border-radius:8px;
    -o-border-radius:8px;
    border-radius:8px;
    background:#eee;
    -webkit-box-shadow:0 1px 0 white, 0 0px 0 1px rgba(0, 0, 0, 0.1) inset, 0 1px 4px rgba(0, 0, 0, 0.2) inset;
    box-shadow:0 1px 0 white, 0 0px 0 1px rgba(0, 0, 0, 0.1) inset, 0 1px 4px rgba(0, 0, 0, 0.2) inset;
}
 .progress .progress-bar {
    float:left;
    width:0%;
    font-size:12px;
    line-height:20px;
    color:white;
    text-align:center;
    background-color:#428bca;
    -webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    box-shadow:inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    -webkit-transition:width 0.6s ease;
    transition:width 0.6s ease;
    -webkit-border-radius:8px;
    -moz-border-radius:8px;
    -ms-border-radius:8px;
    -o-border-radius:8px;
    border-radius:8px;
    -webkit-box-shadow:none;
    box-shadow:none;
    height:8px;
}
.progress-bar span{
    position:absolute;
    width:1px;
    height:1px;
    margin:-1px;
    padding:0;
    overflow:hidden;
    clip:rect(0 0 0 0);
    border:0;
}
.progress-blue {
    background-image:-webkit-gradient(linear, left 0%, left 100%, from(#9bcff5), to(#6db9f0));
    background-image:-webkit-linear-gradient(top, #9bcff5, 0%, #6db9f0, 100%);
    background-image:-moz-linear-gradient(top, #9bcff5 0%, #6db9f0 100%);
    background-image:linear-gradient(to bottom, #9bcff5 0%, #6db9f0 100%);
    background-repeat:repeat-x;
    border:1px solid #55aeee;
}

/*---Смайлы---*/

.emoji {
    border: none;
    vertical-align: middle;
    width: 22px;
    height: 22px;
}

.native-emoji {
    font-size: 1.3em;
    font-family: 'Apple Color Emoji', 'Segoe UI Emoji', 'NotoColorEmoji', 'Segoe UI Symbol', 'Android Emoji', 'EmojiSymbols';
}





/* --- Новости --- */
.comment {
	background-color: #fff;
	margin-bottom: 25px;
	border-radius: 2px;
	position: relative;
	box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2);
}
	.box > .heading { padding: 4% 4%; margin: 0; text-transform: uppercase; }
	.box > .heading .hnum { font-size: .6em; display: inline-block; vertical-align: top; margin: 0 0 0 .4em; }

	.story .title { margin: -.1em 0 1em 0; font-size: 20px; }
	.story .title > a {
		color: inherit;
		text-decoration: none !important;
		-webkit-transition: all ease .2s; transition: all ease .2s;
	}
	.story .title > a:hover { color: #3394e6; }




/* --- Регистрация, Восстановление пароля, Добавление новости---*/
.page_form_style body { background-color: #f7f7f7; }
	.page_form { max-width: 1100px; padding-left: 7%; }
	.page_form__back {
		background-color: #3394e6;
		position: fixed;
		left: 0; top: 0;
		height: 100%; width: 3%;
		padding: 0 2%;
	}
	.page_form__back:after {
		content: "";
		position: absolute;
		top: 0; right: 0;
		width: 5px; height: 100%;
		background-repeat: repeat-y;
		background-image: -webkit-linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
		background-image: -moz-linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
		background-image: -o-linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
		background-image: linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
	}
	.page_form__back > .icon {
		position: absolute;
		left: 50%; top: 8%;
		margin: 0 0 0 -15px;
		width: 30px; height: 20px;
		fill: #fff;
		opacity: .6;
	}
	.page_form__back:hover > .icon { opacity: 1; }
	.page_form__body { padding: 0 10%; }
	.page_form__logo { padding: 8% 0 0 0; margin-bottom: 8%; }
	.page_form__logo .icon { margin-top: -10px; width: 60px; height: 60px; }

	.page_form__inner > .title { font-weight: normal; font-size: 30px; margin: 4% 0; }
	.page_form__form .form_submit { border-top: 1px solid #e0e0e0; padding: 20px 0 0 0; margin-top: 20px; }
	
	@media only screen and (min-width: 701px) {
		.page_form__form { font-size: 1.25em; }
		.page_form__form .form-group label { color: #999; }
		.page_form__form .form-group input, .page_form__form .form-group textarea,
		.page_form__form .form-group select, .page_form__form .c-captcha input {
			font-size: 1em;
			height: 60px;
			line-height: 26px;
			padding: 15px;
		}
		.page_form__form .form-group textarea { height: auto; }
		.page_form__form .c-captcha img { width: 160px; height: 60px; }
		.page_form__form .c-captcha input { width: 160px; }

		.page_form__form .form_submit { padding-top: 3%; margin-top: 3%; }
		.page_form__form ul.ui-form > li { margin-bottom: 3%; }
		.page_form__form .form_submit > .btn {
			font-size: 1em;
			font-weight: normal !important;
			height: 60px;
			border-radius: 30px;
			line-height: 26px;
			padding: 17px 28px;
		}
	}

	.page_form__form .login_check { position: relative; }
	.page_form__form .login_check > input { padding-right: 150px; }
	.page_form__form .login_check > .btn {
		width: 120px;
		position: absolute;
		right: 0; top: 0;
		font-weight: bold;
		margin: 12px;
	}
	#result-registration {     margin-top: 10px;
		font-size: 12px;
		text-align: center; }
	.regtext { margin-bottom: 5%; }

	.page_form__foot { margin-top: 8%; padding-bottom: 8%; }
	.page_form__foot > * { display: block; float: none; }
	.page_form__foot .ca { display: block; margin-top: 2%; margin-left: 0; }
	
	
	.wide, .bb-editor textarea, .ui-dialog textarea, select#category, .timezoneselect, .quick-edit-text {
    width: 100% !important;
}

/* INFO MESSAGES, ERRORS */
.message-info {margin-bottom: 20px;padding: 10px 20px;background-color: #f3fff9;border: 1px solid #bce0c3;border-radius: 6px;}
.message-info--title {font-weight: 700;}
.message-info a {color: inherit; text-decoration: underline; font-weight: 500;}
.message-info--yellow {background: #fce5ba; color: #a76846; border-color: #ebd3a7;}
.message-info--red {margin-top: 25px; color: #ffffff; border-color:  var(--color-primary-p3); background: var(--color-primary-p3); border-radius: 3px; width: 100%;}
.message-info--title {font-weight: 700;font-size: 18px;padding-bottom: 10px;}



#button-up {
  display: inline-block;
  background-color: #6c757d;
  width: 50px;
  height: 50px;
  text-align: center;
  border-radius: 4px;
  position: fixed;
  bottom: 30px;
  right: 30px;
  transition: background-color .3s, 
    opacity .5s, visibility .5s;
  opacity: 0;
  visibility: hidden;
  z-index: 1000;
    font-size: 2em;
  line-height: 50px;
  color: #fff;
}












#button-up:hover {
  cursor: pointer;
  background-color: #333;
}
#button-up:active {
  background-color: #555;
}
#button-up.show {
  opacity: 1;
  visibility: visible;
}


.trightbottom {
    padding-bottom: 25px;
}
	
.bbCodeBlock {
    margin: .75em 0;
    background: #f1f3fb;
    border: 1px solid #d3e1f6;
    border-left: 2px solid #826bc9;
}

.bbCodeBlock-content {
    position: relative;
    padding: 10px 16px;
}


.bbCodeBlock--hidden {
    border-left-color: #9c2f2f !important;
}

.bbCodeBlock--visible {
    border-left-color: #1e942e !important;
}


.bbCodeBlock {
    margin: .75em 0;
    background: #f1f3fb;
    border: 1px solid #d3e1f6;
    border-left: 2px solid #826bc9;
}

.bbCodeBlock--hide {display:none;}

.bbCodeBlock.bbCodeBlock--hide.groups .bbCodeBlock-title, .bbCodeBlock-title {
    font-size: 15px;
}
.bbCodeBlock.bbCodeBlock--hide.groups .bbCodeBlock-title {
    font-size: 13px;
}
.bbCodeBlock-title {
    padding: 10px 16px;
    font-size: 12px;
    color: #7a66b4;
    background: #f9fafd;
	word-break: break-all;
}

.bbCodeBlock-title a{
    color: #e4858d;
    font-weight: bold;
	}
	
	
.bbCodeBlock-title a:hover{
    color:  var(--color-primary-p3-dark);
    font-weight: bold;
	}



.cslinkass {font-size: 14px;color: #c06b71;}
.cslinkass:hover {font-size: 14px;color:  var(--color-primary-p3-dark);}



.itemCount {
font-weight: bold;
    font-size: 11px;
    color: white;
    background-color: #e03030;
    padding: 0px 4px;
    border-radius: 4px;
    position: absolute;
    top: 10px;
    line-height: 15px;
    min-width: 13px;
    _width: 12px;
    text-align: center;
    text-shadow: none;
    white-space: nowrap;
    word-wrap: normal;
    box-shadow: 2px 2px 5px rgb(0 0 0 / 25%);
    height: 15px;
}

.itemCount .arrow {
    border: 3px solid transparent;
    border-top-color: #e03030;
    border-bottom: 1px none black;
    position: absolute;
    bottom: -3px;
    right: 4px;
    line-height: 0px;
    text-shadow: none;
    _display: none;
    width: 0px;
    height: 0px;
}


.editreason {
    background: #e0ffe0;
    padding: 15px;
    border: 1px solid #d0f2d0;
    border-radius: 4px;
    text-align: center;
    color: #ff3d3d;
    font-weight: bold;
    font-size: 16px;
    margin-bottom: 25px;
	}
	
	
	
	
	
	
	.TopNavBtn__profileLink  {
	cursor: pointer;
	}

	
	.TopNavBtn__profileLink.active{background-color: #aeb7c21f;color:  var(--color-primary-p3-dark);} 
	
	
.TopNavBtn__profileLink	svg {margin-bottom: 1px;overflow: hidden;vertical-align: middle;}







#jGrowl .jGrowl-notification {
    opacity: 1;
    border-radius: 0;
    z-index: 9999999;
    position: relative;
    top: 63px;
}





.growls-default {	
z-index: 9999999;
    position: relative;
    top: 63px;}
	
	


.main-body-auth {
    padding: 10px;
    display: block;
    position: relative;
    background: white;
    width: 350px;
    margin: 0 auto;
}




.lheight16 a:nth-child(2) span {margin-left: 20px !important;}	
.lheight16 a:nth-child(2) span:before {content: '\0338';margin-left: -10px;margin-right: 10px;font-weight: bold;}

.lheight16 a:nth-child(3) span {margin-left: 20px !important;}	
.lheight16 a:nth-child(3) span:before {content: '\0338';margin-left: -10px;margin-right: 10px;font-weight: bold;}






@media screen and (max-width:1063px) {
.main-body-auth {
    width: 350px;
}

}

@media screen and (max-width:868px) {
.main-body-auth {
    width: 100%;
}


.lheight16 a:nth-child(2) span {margin-left: 0 !important;}	
.lheight16 a:nth-child(2) span:before {content: '';margin-left: 0;margin-right: 0;font-weight: bold;}

.lheight16 a:nth-child(3) span {margin-left: 0 !important;}	
.lheight16 a:nth-child(3) span:before {content: '';margin-left: 0;margin-right: 0;font-weight: bold;}


.bbMediaWrapper-inner iframe {width: 100%;height: 185px;}

iframe {width: 100%;height: 185px;}

}








.bvDKng {
    color: rgb(133, 133, 133);
}


.jcbRHX {
    display: inline-block;
    vertical-align: top;
    height: 100%;
    transition: opacity 0.3s ease 0s;
    opacity: 1;
	width: 144px;
    margin-right: 15px;
}


.eYPEZX {
    vertical-align: top;
    display: inline-block;
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    position: relative;
}


.dUrmQP {
    position: relative;
    top: 0px;
    left: 0px;
    height: calc(100% - 32px);
    width: 100%;
    transition: fill 200ms ease 0s;
}


.bsRGkV {
    position: absolute;
    top: 0px;
    left: 0px;
    display: block;
    width: 100%;
    height: calc(100% - 32px);
    background-position: center center;
    background-size: 100%;
    background-repeat: no-repeat;
}



.eYPEZX:hover .sc-pzMyG {
    opacity: 1;
}




.bTECAR {
    position: absolute;
    bottom: 0px;
	left: 0;
    font-size: 12px;
    line-height: 1.43;
    font-weight: 600;
    height: 40px;
    width: 100%;
    color: rgb(51, 51, 51);
    white-space: normal;
    text-align: center;
    opacity: 0.8;
    transition: opacity 200ms ease 0s;
}




.container-cat-ico .owl-carousel.owl-drag .owl-item {    
   height: 160px;
    margin: 0px auto;
    position: relative
	}
	
	
	


	
.svg-1:hover .dUrmQP{
  fill: #d0eafa;
}


.svg-2:hover .dUrmQP{
  fill: #d7ebf0;
}	


.svg-3:hover .dUrmQP{
  fill: #d7f0d7;
}



.svg-4:hover .dUrmQP{
  fill: #f0e6d7;
}

.svg-5:hover .dUrmQP{
  fill: #f0d7f0;
}

	
.svg-6:hover .dUrmQP{
  fill: #e1d7f0;
}





	
.jcbRHX  .svg-1.selected .dUrmQP{
  fill: #d0eafa;
}


.jcbRHX  .svg-2.selected .dUrmQP{
  fill: #d7ebf0;
}	


.jcbRHX  .svg-3.selected .dUrmQP{
  fill: #d7f0d7;
}



.jcbRHX  .svg-4.selected .dUrmQP{
  fill: #f0e6d7;
}

.jcbRHX  .svg-5.selected .dUrmQP{
  fill: #f0d7f0;
}

	
.jcbRHX .svg-6.selected .dUrmQP{
  fill: #e1d7f0;
}








.skid  {color: #5b66cc}






.jKDBeI {
    float: left;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    transition: box-shadow 0.4s ease-in-out 0s;
    box-shadow: rgba(0, 0, 0, 0.04) 0px 2px 4px 0px;
}


.jKDBeI:hover {
	box-shadow: rgba(0, 0, 0, 0.08) 0px 8px 16px 0px;
	transform: translateY(-6px);
}





.fXXIqu {
    display: flex;
    flex-flow: column nowrap;
    -webkit-box-pack: end;
    justify-content: flex-end;
    align-items: flex-start;
    width: 100%;
    height: 100%;
    color: inherit;
    text-decoration: none;
    cursor: pointer;
    padding: 25px 15px;
}



.hVybaj {
	display: block;
    font-weight: 600;
    line-height: 24px;
    height: 70px;
    width: 60%;
    text-align: left;
    font-size: 16px;
    transition: color 0.4s ease 0s;
    color: var(--color-primary-p3-dark);
    white-space: break-spaces;
    overflow: hidden;
}






.ftqUsy {
    display: block;
    
    line-height: 24px;
    font-weight: 400;
    font-size: 13px;
    color: rgba(51, 51, 51, 0.64);
    max-width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}








.ioUpwA {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    background-color: rgb(245, 245, 245);
    background-image: url(/uploads/python.jpg);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
}




.iZVoVb {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    background-color: rgb(245, 245, 245);
    background-image: url(/uploads/3d.png);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
}



.cfxbRg {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    background-color: rgb(245, 245, 245);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
}


.zdorovye {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    background-color: rgb(245, 245, 245);
    background-image: url(/uploads/zdorovye.png);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
}









.ioUpwX {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    background-color: rgb(245, 245, 245);
    background-image: url(/uploads/php.jpg);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
}




.JFBfM {
    overflow: hidden;
}


.gLiaon {
    max-width: 1066px;
    padding: 0 32px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
}




@media screen and (max-width:1063px) {

.gLiaon {
    max-width: 768px;
    padding: 0 32px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
}
}

@media screen and (max-width:868px) {

.gLiaon {
    padding: 0 32px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
}

}










.pvbqM {
    position: relative;
    margin: 0px auto;
}


.jsIEAM {
    position: relative;
}


.pvbqM .sc-qQMSE {
    overflow: visible;
}
constructed stylesheet
.hLIUPs {
    width: 960px;
    height: 175px;
    margin: 0px auto;
    position: relative;
    overflow: hidden;
}


.deBWZE {
    height: 100%;
    white-space: nowrap;
    position: relative;
    transition: transform 400ms ease 0s;
}



.hLIUPs {
    width: 960px;
    height: 175px;
    margin: 0px auto;
    position: relative;
    overflow: hidden;
}






.hXGkGv .owl-carousel .owl-stage-outer {
	overflow: visible;
    width: 100%;
    height: 165px;
    margin: 0px auto;
    position: relative;
    overflow: visible;;}
	
	
.hXGkGv  .owl-carousel .owl-stage {
    height: 100%;
    white-space: nowrap;
    position: relative;
    transition: transform 400ms ease 0s;
}



.owl-carousel.owl-drag .fMRDMD {
    display: inline-block;
    vertical-align: top;
    height: 140px;
    transition: opacity 0.3s ease 0s;
    opacity: 0;
    width: 100%;
}

.swiper-wrapper {height: 140px !important;}





@media screen and (max-width:868px) {

	.sc-pbxSd {
		width: 100% !important;
	}

}









.owl-carousel.owl-drag .active .fMRDMD {
    opacity: 1;
}



.iIRtDC {
	display: block;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
}


.cXXhTb {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    flex-wrap: wrap;
    display: flex;
    padding: 24px 16px 0px;
    border-radius: 8px;
    background-color: rgb(255, 255, 255);
	border: 1px solid #ececec;
}


.gPlgnl {
    background: linear-gradient(rgb(255, 255, 255) 0px, rgb(250, 250, 250) 222px);
}

.gPlgnl {
	margin-top: 60px;
    position: relative;
    flex: 1 1 auto;
    background: linear-gradient(rgb(255, 255, 255) 0px, rgb(250, 250, 250) 174px);
}



.eKBirH {
    position: relative;
	padding-bottom: 60px;
	display: flex;
	margin-top: 25px;
}


.ibDbuL {
	position: relative;
	padding-bottom: 60px;
	display: flex;
	margin-top: 25px;
}

.sc-gmmXTR {margin-top: 5px;}


.egzVtT .sc-gmmXTR {
	background: #fff;
}

.egzVtT {
    position: relative;
    z-index: 10;
    box-shadow: 0 4px 20px rgb(57 69 86 / 10%);
    height: 96px;
}


.jwNNnX {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 70%;
	padding-right: 24px;
}


.dyfpCa {
    box-sizing: border-box;
    margin: 0px;
	position: relative;
    min-width: 0px;
    width: 30%;
}

.dyfpCa #advice {
    margin-bottom: 10px;
    padding: 0px;
}


.ihwwlI .dyfpCa {
    box-sizing: border-box;
    margin: 0px;
	top: -40px;
	position: relative;
    min-width: 0px;
    width: 33%;
}







.owl-prev:focus{outline: 0;}
.owl-next:focus{outline: 0;}
.hXGkGvxx .owl-theme .custom-nav .owl-prev, .hXGkGvxx .owl-theme .custom-nav .owl-next {
      position: absolute;
    z-index: 1;
    pointer-events: visible;
    padding: 0px;
    border: none;
    width: 32px;
    height: 32px;
    outline: none;
    cursor: pointer;
    background: center center no-repeat rgb(255, 255, 255);
    border-radius: 8px;
    box-shadow: rgb(0 0 0 / 17%) 0px 4px 8px 0px;
    transition-property: opacity, visibility;
    transition-duration: 0.1s;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}
.hXGkGvxx .owl-theme .custom-nav .owl-prev i, .hXGkGvxx .owl-theme .custom-nav .owl-next i {
  font-size: 1.2rem;
  color:  var(--color-primary-p3-dark);
}
.hXGkGvxx .owl-theme .custom-nav .owl-prev {
    left: -15px;
    top: 55px;
}
.hXGkGvxx .owl-theme .custom-nav .owl-next {
  right: -15px;
  top: 55px;
}




.owl-prev:focus{outline: 0;}
.owl-next:focus{outline: 0;}
.main-rinok .owl-theme .custom-nav .owl-prev, .main-rinok .owl-theme .custom-nav .owl-next {
      position: absolute;
    z-index: 1;
    pointer-events: visible;
    padding: 0px;
    border: none;
    width: 32px;
    height: 32px;
    outline: none;
    cursor: pointer;
    background: center center no-repeat rgb(255, 255, 255);
    border-radius: 8px;
    box-shadow: rgba(0, 0, 0, 0.06) 0px 4px 8px 0px;
    transition-property: opacity, visibility;
    transition-duration: 0.1s;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}


.newpmos {position: relative;padding: 0px 5px;background: #e00;color: #fff;border-radius: 3px;}


@media screen and (max-width:1063px) {
.newpmos {margin-left: 5px;}
}

@media screen and (max-width:868px) {
.newpmos {margin-left: 5px;}
}


.bannerfree {
margin-top: 5px;
    margin-right: 10px;
    position: relative;
    display: inline-table;
    padding: 5px;
    opacity: 0.6;
    border: solid 1px #dddddd;
	}
	
	
	.bannerfree:hover {
	opacity: 1;
	}



@media screen and (min-width:767px) {
.g-recaptcha {
 -moz-transform:scale(1.1);
    -ms-transform:scale(1.1); 
    -o-transform:scale(1.1); 
    -moz-transform-origin:0; 
    -ms-transform-origin:0;
    -o-transform-origin:0;
    -webkit-transform:scale(1.1);
    transform:scale(1.1);
    -webkit-transform-origin:0 0;
    transform-origin:0;
    filter: progid:DXImageTransform.Microsoft.Matrix(M11=1.1,M12=0,M21=0,M22=1.1,SizingMethod='auto expand');
}
}


.mode-fullbox img {
	max-width: 95%;
	display: block;
    margin-left: auto;
    margin-right: auto;
	}



@media screen and (max-width:1063px) {
	.mode-fullbox img {
	max-width: 95%;
	display: block;
    margin-left: auto;
    margin-right: auto;
	}
}

@media screen and (max-width:868px) {
	.mode-fullbox img {
	max-width: 95%;
	display: block;
    margin-left: auto;
    margin-right: auto;
	}

}


.ui-dialog {
    z-index:1000000000;
    top: 0; left: 0;
    margin: auto;
    position: fixed;
    max-width: 100%;
    max-height: 100%;
    display: flex;
    flex-direction: column;
    align-items: stretch;
}
.ui-dialog .ui-dialog-content {
    flex: 1;
}


.hotnum {
    display: block;
	font-weight: bold;
    font-size: 11px;
    color: white;
    background-color: #e03030;
    padding: 0 2px;
    border-radius: 2px;
    position: absolute;
    right: 2px;
    top: 10px;
    line-height: 16px;
    min-width: 12px;
    _width: 12px;
    text-align: center;
    text-shadow: none;
    white-space: nowrap;
    word-wrap: normal;
    box-shadow: 2px 2px 5px rgb(0 0 0 / 25%);
    height: 16px; 
}

.hotnum.hide {
    display: none;
}


.collection .cl-glav {
    width: 31.7%;
    display: inline-block;
    vertical-align: top;
    margin-right: 17px;
    height: 140px;
    margin-bottom: 25px;
	}


.collection .cl-glav:nth-child(3n) {
margin-right: 0px;
}




@media screen and (max-width: 1063px) {

  .cl-glav {
    width: 49%;
    display: inline-block;
    vertical-align: top;
    height: 140px;
    margin-bottom: 25px;
	}

}


@media screen and (max-width: 767px) {
	
	  .cl-glav {
    width: 100%;
    display: inline-block;
    vertical-align: top;
    height: 140px;
    margin-bottom: 25px;
	}
	
}




	
	
	.cl-sub {
    float: left;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    transition: box-shadow 0.4s ease-in-out 0s;
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
    }


    .cl-sub:hover {
    box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px;
    }
	
	
	.cl-image {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 8px;
    background-color: rgb(245, 245, 245);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    }
	
	
	.cl-a {
    display: flex;
    flex-flow: column nowrap;
    -webkit-box-pack: end;
    justify-content: flex-end;
    align-items: flex-start;
    width: 100%;
    height: 100%;
    color: inherit;
    text-decoration: none;
    cursor: pointer;
    padding: 25px 15px;
}


.cl-text1 {
    display: block;
    font-weight: 600;
    line-height: 24px;
    height: 70px;
    width: 60%;
    text-align: left;
    font-size: 16px;
    transition: color 0.4s ease 0s;
    color:  var(--color-primary-p3-dark);
    white-space: break-spaces;
	overflow: hidden;
}


.cl-text2 {
    display: block;
    
    line-height: 24px;
    font-weight: 400;
    font-size: 13px;
    color:  var(--color-primary-p3-dark);
    max-width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}



.cash-add {
    float: right;
    height: 30px;
	line-height: 30px !important;
    padding: 0 20px;
    border: 1px solid #c02e3c;
    background: #dc3545;
    border-radius: 2px;
    cursor: pointer;
    color: #fff;
    font-weight: bold;
    text-shadow: 0 1px 3px rgb(0 0 0 / 50%);
}



.cash-add:hover {
background: #c42231;
}





.sPFrk {
    position: relative;
    z-index: 10;
    height: 96px;
    top: 10px;
}


.sPFrk .sc-iOTrKq {
    background: #f3f3f3;
    border: 1px solid #f2f2f2;
    border-radius: 8px;
	padding: 8px 16px;
}

.hlSXSH {
    height: 36px;
	background:  var(--color-primary-p3-dark);
}


.bcSPju {
    max-width: 1264px;
    background-color: transparent;
    z-index: 11;
}



.fYNLwC {
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
}



.eUIgzn {
    display: flex;
    overflow: hidden;
    text-transform: uppercase;
    font-weight: 600;
}



.druaoK {
    display: flex;
}



.druaoK li {
   margin-right: 15px;
}



.dMjLyM > :not(:last-child) {
    margin-right: 4px;
}

.dMjLyM svg {
    min-width: 16px;
}

.iVvBSb > svg, .iVvBSb > svg * {
    fill: currentcolor;
}

.iVvBSb > svg {
    margin-right: 8px;
}



.dMjLyM:hover {
    color:  var(--color-primary-p3);
}

.iVvBSb:hover {
    color:  var(--color-primary-p3);
}



.iVvBSb {
    
    line-height: 16px;
    font-weight: 600;
    font-size: 14px;
    letter-spacing: 0.2px;
}


.hNreIX {
    white-space: nowrap;
}


.hNreIX a {color:  var(--color-primary-p3-dark);}
.hNreIX a:hover {color:  var(--color-primary-p3);}


.dMjLyM {
    display: flex;
    cursor: pointer;
    color:  var(--color-primary-p3-dark);
    text-transform: uppercase;
}

.eaCiYe {
    border: none;
    margin: 0px;
    padding: 0px;
    width: auto;
    outline: none;
    overflow: visible;
    cursor: pointer;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    background: transparent;
    font-style: inherit;
    font-variant: inherit;
    font-stretch: inherit;
    -webkit-font-smoothing: inherit;
    text-align: left;
    
    line-height: 16px;
    font-weight: 400;
    font-size: 12px;
    letter-spacing: 0.2px;
    color: rgb(51, 51, 51);
    text-decoration: underline;
}




.ifmvMZ {
    width: 100%;
    position: absolute;
	transition: transform 0.5s cubic-bezier(0.8, 0.2, 0.2, 0.8);
    top: 36px;
    height: 64px;
}


.ifmvMZx {
    width: 100%;
    position: absolute;
	transition: transform 0.5s cubic-bezier(0.8, 0.2, 0.2, 0.8);
    top: 36px;
    height: 64px;
	box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px !important;
    border-radius: 8px;
    background: #fff;
    border: 1px solid #f2f2f2;
}


.sPFrk .sc-gmmXTR .sc-gmAETw {
    background: transparent;
}


.frfdTW {
    width: 100%;
    padding: 12px 0px;
    height: 64px;
}


.bcSPju {
    max-width: 1264px;
    background-color: transparent;
    z-index: 11;
}





.laquCT {
    display: flex;
}


.bCARSy {
    position: relative;
    z-index: 11;
}

.iMIhtY {
    margin-left: -8px;
    margin-right: -8px;
}


.iMIhtY {
    margin-left: -5px;
    margin-right: -5px;
}

.iMIhtY {
    box-sizing: border-box;
    margin: 0px -5px;
    min-width: 0px;
    flex-wrap: wrap;
}



.boOgoZ {
    display: flex;
}

.elA-dZk {
    padding-right: 8px;
    padding-left: 8px;
}



.elA-dZk {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
    padding-right: 5px;
    padding-left: 5px;
}



.euzVCd {
    font-size: 0px;
    transform: translateY(3px);
	margin-top: 1px;
}






.gxEnBn:hover {
    background:  var(--color-primary-p3-light);
	color: #fff;
}



.gxEnBn {
    border: none;
    margin: 0px;
    width: auto;
    outline: none;
    overflow: visible;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    font: inherit;
    text-align: center;
    -webkit-font-smoothing: inherit;
    height: 32px;
    padding: 4px 16px;
    border-radius: 8px;
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    border-radius: 8px;
    color: #fff;
    background-color:  var(--color-primary-p3);
}


.gxEnBnhover {
	border: none;
    margin: 0px;
    width: auto;
    outline: none;
    overflow: visible;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    font: inherit;
    text-align: center;
    -webkit-font-smoothing: inherit;
    height: 32px;
    padding: 4px 16px;
    border-radius: 8px;
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    border-radius: 8px;
    color: #fff;
    background-color:  var(--color-primary-p3-light);
}




.fIhwb {
    -webkit-box-flex: 1;
    flex-grow: 1;
    margin-right: 8px;
    max-height: 100%;
}

.boOgoZ > * {
    max-height: 32px;
}

.boOgoZ > * + * {
    margin-left: 16px;
}



.dBDcDn {
    width: 100%;
    position: relative;
    font-size: 14px;
    padding-right: 79px;
}



.iTezNb {
    position: relative;
    display: inline-block;
    vertical-align: middle;
    margin: 0px;
    padding: 0px;
    
    text-decoration: none;
    text-align: center;
    line-height: normal;
    white-space: nowrap;
    border: 0px;
    outline: 0px;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.2s ease 0s;
    border-radius: 4px;
    color: rgb(57, 57, 57);
    background-color: rgb(235, 235, 235);
    box-shadow: none;
}




.gRJPTD {
    position: absolute;
    top: 0px;
    right: 0px;
    width: 32px;
    height: 32px;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    color: #fff;
    background:  var(--color-primary-p3-dark);
    border-radius: 8px;
}



.hcSCKw {
    position: absolute;
    top: 0px;
    right: 0px;
    width: 32px;
    height: 32px;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    color: #fff;
    background:  var(--color-primary-p3);
    border-radius: 8px;
}


.iTezNb:hover {
    text-decoration: none;
}

.iTezNb:hover {
    color: rgb(57, 57, 57);
    background-color: rgb(239, 239, 239);
    box-shadow: none;
}

.gRJPTD:hover {
    background: var(--color-primary-p3-light) !important;
    color: #fff;
    border-radius: 8px;
}

.iTezNb .sc-cOajty {
    display: block;
    padding: 6px;
    font-size: 16px;
    font-weight: 600;
}

.jAnegm {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}



.iIeIkW {
    margin: 0px;
    width: auto;
    outline: none;
    overflow: visible;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    font: inherit;
    text-align: center;
    -webkit-font-smoothing: inherit;
    height: 32px;
    padding: 4px 15px;
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    color:  #fff;
	background-color: var(--color-primary-p3-dark);
    border: 1px solid #dfdfdf;
    border-radius: 8px;
}


.iIeIkW:hover {
	border: 1px solid  var(--color-primary-p3-light);
	background-color: var(--color-primary-p3-light);

}






.bFHTUZ {
    border: none;
    margin: 0px;
    width: auto;
    outline: none;
    overflow: visible;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    font: inherit;
    text-align: center;
    -webkit-font-smoothing: inherit;
    height: 32px;
    padding: 4px 16px;
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
	border-radius: 8px;
    color:  var(--color-primary-p3-dark);
	background-color: #fff;
    border: 1px solid #dfdfdf;
}


.bFHTUZ:hover {
	color:  var(--color-primary-p3-dark);
    border: 1px solid  var(--color-primary-p3);
}


.ckFvLy {
    
    line-height: 24px;
    font-weight: 600;
    font-size: 16px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-height: 24px;
}


.fvooyb .sc-eQhwCh {
    position: absolute;
    left: 8px;
    top: 4px;
}

.ccGxUx div {
    height: 5px;
    width: 18px;
    overflow: hidden;
    position: relative;
    transition: all 0.1s ease-in 0s;
}




.ccGxUx > div:nth-child(2n) {
    visibility: visible;
    opacity: 1;
}

.ccGxUx > div:nth-child(2) {
    width: 14px;
}




.ccGxUx > div:last-child {
    width: 10px;
}

.ccGxUx svg {
    position: absolute;
    top: 0px;
    left: 0px;
}

.frfdTW .sc-gpsAVS {
    top: 48px;
}

.uZATO {
    overflow: hidden;
    position: absolute;
    padding-bottom: 24px;
    width: 100%;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.1s linear 0s, transform 0.1s linear 0s, visibility 0s linear 0.1s;
    transform: translate3d(0px, -8px, 0px);
}




.fqxkwu > div:first-child {
    margin-top: 8px;
    transform: rotate(
45deg);
}

.fqxkwu div {
    width: 23px;
    margin-top: 0px;
    transition: all 0.2s ease-in 0s;
}

.fqxkwu div {
    height: 5px;
    width: 18px;
    overflow: hidden;
    position: relative;
    transition: all 0.1s ease-in 0s;
}


.fqxkwu svg {
    position: absolute;
    top: 0px;
    left: 0px;
}



.fqxkwu > div:nth-child(2n) {
    visibility: visible;
    opacity: 1;
}

.fqxkwu > div:nth-child(2) {
    width: 14px;
}



.fqxkwu > div:nth-child(2n) {
    visibility: hidden;
    transform: translateX(-100%);
    opacity: 0;
}



.fqxkwu > div:nth-child(3) {
    margin-top: -10px;
    margin-left: -3px;
    transform: rotate(
-45deg);
}







.dLQGEk {
    position: absolute;
    visibility: visible;
    opacity: 1;
    transform: translate3d(0px, 0px, 0px);
    overflow: hidden;
    transition: opacity 0.2s linear 0s, transform 0.2s linear, visibility 0s linear;
    background: #fff;
    box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px !important;
}


.daPpPm {
    position: relative;
    z-index: 10;
    padding: 20px 0px;
}



.bpQQda {
    left: 8px;
}

.bpQQda {
    position: absolute;
    top: 4px;
    pointer-events: none;
    left: 4px;
}






.dBDcDn .sc-Fyfyc {
    width: 116%;
    padding: 4px 10px;
	background: #f9f9fb;
    color: rgb(51, 51, 51);
    display: inline-block;
    vertical-align: middle;
    zoom: 1;
    font: inherit;
    margin: 0px;
    overflow: visible;
    transition: border-color 0.2s ease 0s;
    height: 32px;
	border: 1px solid #dfdfdf;
    border-radius: 8px;
}




.dBDcDn .sc-Fyfyc:focus
{
outline: 0;
outline-offset: 0;
background: #fff;
border: 1px solid  var(--color-primary-p3);
}


.fvooyb {
    padding: 0px 15px 0px 40px;
}



.XqbgT {
    max-width: 1066px;
    min-width: 320px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    padding-left: 16px;
    padding-right: 16px;
	left: 0;
    right: 0;
	border-radius: 8px;
}


.brandlist {
	display: inline-block;
    justify-content: center;
    align-items: center;
    border: 1px solid #dfdfdf;
    border-radius: 4px;
    width: 120px;
    height: 120px;
    margin-right: 5px;
    margin-left: 5px;
    background: #ffffff;
    text-align: center;
    margin-bottom: 10px;
    opacity: 1;
}


.brandlist:hover {
    border: 1px solid  var(--color-primary-p3);
}

.brandlist:hover {
opacity: 0.6;
}



.brandlist a {
    display: inherit;
    justify-content: center;
    align-items: center;
    width: 100px;
    height: 100px;
}


.brandlist img {
	object-fit: contain;
    object-position: center;
    width: 100%;
    height: 100%;
    padding: 5px;
    top: 10px;
    position: relative;
	cursor: pointer !important;
}





.tooltip {
	display:none;
    position: absolute;
    border: 1px solid #5f73f6;
    background-color:  var(--color-primary-p3);
    border-radius: 5px;
    padding: 10px;
    color: #fff;
    z-index: 99;
}






		
.gWVnqI {
    display: inline-block;
    vertical-align: top;
    height: 124px;
    transition: opacity 0.3s ease 0s;
    opacity: 1;
}



.jaQVoM {
    vertical-align: top;
    display: inline-block;
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    position: relative;
}


.svg1:hover svg {fill:#d7f0f0;}
.svg2:hover svg {fill:#d0eafa;}
.svg3:hover svg {fill:#e6d7f0;}
.svg4:hover svg {fill:#f0e6d7;}
.svg5:hover svg {fill:#e1d7f0;}
.svg6:hover svg {fill:#f0e1d7;}
.svg7:hover svg {fill:#d0d8fa;}
.svg8:hover svg {fill:#d7e6f0;}
.svg9:hover svg {fill:#f0d7d7;}
.svg10:hover svg {fill:#f4b4ff;}


.iORAaW {
    position: absolute;
    top: 0px;
    left: 0px;
    height: calc(100% - 32px);
    width: 100%;
    transition: fill 200ms ease 0s;
}


.hHYCJM {
    position: absolute;
    top: 22px;
    font-size: 45px;
    left: 0px;
    text-align: center;
    display: block;
    width: 100%;
    height: calc(100% - 32px);
    background-position: center center;
    background-size: 100%;
    background-repeat: no-repeat;
}


.iQUpZw {
    position: absolute;
    bottom: 0px;
    font-size: 14px;
    line-height: 1.43;
    font-weight: 600;
    height: 40px;
    width: 100%;
    color:  var(--color-primary-p3-dark);
    white-space: normal;
    text-align: center;
    opacity: 0.8;
    transition: opacity 200ms ease 0s;
}



.dFgovI {
    font-weight: 600;
    line-height: 55px;
    font-size: 22px;
    color:  var(--color-primary-p3-dark);
}



#jiCSMd {
    list-style: none;
    margin: 35px 0px 0px;
    position: absolute;
    top: 100%;
    width: 100%;
    padding: 9px 0px;
    background-color: rgb(255, 255, 255);
    border-radius: 2px;
    border: 1px solid rgb(235, 235, 235);
    z-index: 10;
	overflow-y: auto;
    min-height: 100px;
    max-height: 456px;
}


#jiCSMd::-webkit-scrollbar {
	-webkit-appearance: none;
	width: 7px;
}

#jiCSMd::-webkit-scrollbar-thumb {
	border-radius: 4px;
	background-color: rgba(0, 0, 0, .5);
	-webkit-box-shadow: 0 0 1px rgba(255, 255, 255, .5);
}



.ebxpdw {
    color: rgb(51, 51, 51);
    font-size: 14px;
    padding: 8px 16px;
    margin: 0px;
    cursor: pointer;
}


.fjuCED {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}


.guBdTp {
    display: block;
    padding-top: 6px;
    color: rgb(133, 133, 133);
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}





.hGnVBE {
    height: 100%;
}


.jFkTfG {    
	min-height: 100%;
    min-width: 320px;
    height: 100%;
    background-color: rgb(255, 255, 255);
}



.logauthcls {
    display: none;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 999;
    -webkit-tap-highlight-color: transparent;
}




.logauthopn {
    display: block;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 999;
    -webkit-tap-highlight-color: transparent;
}






.videocls {
    display: none;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 999;
    -webkit-tap-highlight-color: transparent;
}




.videoopn {
    display: block;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 999;
    -webkit-tap-highlight-color: transparent;
}



.videotube {
	margin: 0 auto;
    padding: 100px;
    width: 100%;
    max-width: 100%;
    text-align: center;
    animation-name: showAuthBorder;
    animation-duration: 1s;
    animation-fill-mode: forwards;
    position: relative;
}



.videotube {
    animation-name: fadeInUp;
    animation-duration: 0.8s;
    border: 1px solid rgb(235, 235, 235);
}




.gwSsrA {
    margin: 100px auto 40px;
    padding: 30px 30px 20px;
    width: 370px;
    max-width: 100%;
    text-align: center;
    animation-name: showAuthBorder;
    animation-duration: 1s;
    animation-fill-mode: forwards;
    position: relative;
}


.gwSsrA {
    animation-name: fadeInUp;
    animation-duration: 0.8s;
    border: 1px solid rgb(235, 235, 235);
}



.gjnxsj {
    padding: 10px;
    margin: -70px auto 18px;
    border-radius: 100px;
    box-sizing: content-box;
    width: 64px;
    height: 64px;
    background: 50% center / 64px 64px no-repeat rgb(255, 255, 255);
}


.fwUSol {
    font-family: "Cutest", sans-serif;
    font-size: 20px;
    font-weight: 500;
    line-height: normal;
    margin-bottom: 12px;
}




.kyDrzE {
    display: inline-block;
    vertical-align: baseline;
    line-height: 18px;
    font-weight: 400;
    font-size: 12px;
    color: rgb(51, 51, 51);
	font-family: "Cutest", sans-serif;
}

.kwZVkj {
    display: inline-block;
    color: rgb(133, 133, 133);
    margin-bottom: 30px;
}



.kgyYlU {
    width: 100%;
    height: 40px;
    border-radius: 4px;
    border: 1px solid rgb(235, 235, 235);
    color: rgb(133, 133, 133);
    padding: 8px 12px;
    outline: 0px;
    margin-bottom: 5px;
    line-height: 24px;
    font-weight: 400;
    font-size: 14px;
    transition: border-color 0.2s ease 0s;
}


.eBVgjd.eBVgjd > * + * {
    margin-top: 12px;
}



.doLBc {
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
}

.bIpdxk {
    border: none;
    margin: 0px;
    outline: none;
    overflow: visible;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    font-family: "Cutest", sans-serif;
    text-align: center;
    -webkit-font-smoothing: inherit;
    height: 40px;
    padding: 8px 20px;
    border-radius: 8px;
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
	background:  var(--color-primary-p3);
    color: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
    width: 100%;
	margin: 10px 0;
}

.bIpdxk:hover {
	background:  var(--color-primary-p3-dark);
    box-shadow: rgb(0 0 0 / 6%) 0px 4px 8px 0px;
}



.hmkSPt {
    color: rgb(133, 133, 133);
    text-align: center;
    margin-top: 10px !important;
}

.jmKyTP {
    display: block;
    
    line-height: 16px;
    font-weight: 400;
    font-size: 12px;
    letter-spacing: 0.2px;
    color: rgb(51, 51, 51);
}


.cDxNDt {
    color: rgb(133, 133, 133);
    text-decoration: underline;
    transition: color 0.2s ease 0s;
    cursor: pointer;
}



.display-none {
    overflow: hidden !important;
    display: none;
}



.jvlhar {
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 130;
    transition: opacity 250ms ease 0s;
    background-color: #fff;
    display: none;
    opacity: 0;
}

.dDFnkR {
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 130;
    transition: opacity 250ms ease 0s;
    background-color: #fff;
    display: block;
    opacity: 1;
}




.ExkKG {
    position: relative;
    display: inline-block;
    vertical-align: middle;
    margin: 0px;
    padding: 0px;
    
    text-decoration: none;
    text-align: center;
    line-height: normal;
    white-space: nowrap;
    border: 0px;
    outline: 0px;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.2s ease 0s;
    border-radius: 4px;
    color: rgb(57, 57, 57);
    background-color: transparent;
    box-shadow: none;
}



.cIoNSD {
    position: absolute;
    width: auto;
    height: auto;
    top: 24px;
    right: 24px;
    cursor: pointer;
    z-index: auto;
    transition: none 0s ease 0s;
}






.jAnegm {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}



.ExkKG .sc-cOajty {
    display: block;
    padding: 9px 16px;
    font-size: 0px;
    font-weight: 400;
}




.bhdLno {
    speak: none;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    -webkit-font-smoothing: antialiased;
}




.vDcfZ {
    color: rgb(133, 133, 133);
}


.ExkKG i {
    color: rgb(57, 57, 57) !important;
}



.cIoNSD i {
    font-size: 28px !important;
}



.ExkKG .sc-AzgDb {
    position: relative;
    display: inline-block;
    vertical-align: middle;
    height: calc(24px);
    font-size: calc(24px);
    line-height: calc(24px);
    opacity: 1;
    margin: -2px -8px;
}





.bhdLno::before {
    font-size: inherit;
    line-height: inherit;
}


.ioOodw::before {
    font-family: icon-main;
    content: "";
}




.ExkKG .sc-AzgDb::before {
    display: block;
}









.dVQZCe {
    visibility: hidden;
	opacity: 0;
	max-height: none;
    position: absolute;
    right: 4px;
    top: 100%;
    transform: translateY(10px);
    border-radius: 8px;
    background-color: rgb(255, 255, 255);
    border: 1px solid rgb(235, 235, 235);
    animation-name: hYfEzu;
    animation-duration: 0.2s;
}  
	  
	
	.dVQZCe.ashown {
	visibility: visible;
    opacity: 1;
    }
	
	


.dVQZCe::after, .dVQZCe::before {
    bottom: 100%;
    left: 40px;
    border: solid transparent;
    content: " ";
    height: 0px;
    width: 0px;
    position: absolute;
    pointer-events: none;
}




.dVQZCe::before {
    border-bottom-color: rgb(235, 235, 235);
    border-width: 11px;
    margin-right: -1px;
}




.dVQZCe::after {
    border-bottom-color: rgb(255, 255, 255);
    border-width: 10px;
}


.cHqlKf {
    box-shadow: rgb(0 0 0 / 24%) 0px 16px 24px 0px, rgb(0 0 0 / 8%) 0px 0px 8px 0px;
    border-radius: 8px;
    padding: 8px 12px;
    max-height: 314px;
    overflow: auto;
}


.grGor {
    margin: 0px;
    padding: 0px;
    list-style-type: none;
}



.jAjPYI {
    border-bottom: 1px solid rgb(235, 235, 235);
    margin: 8px 0px;
}


li:last-child .sc-cuaApf {
    border-top: 1px solid transparent;
}




.dKeJse {
    position: relative;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    width: 100%;
    height: 40px;
    cursor: pointer;
    color: rgba(51, 51, 51, 0.96);
}


.dKeJse:hover {
    text-decoration: none;
    color: rgb(55 181 60);
}


.dKeJse {
    width: 270px;
}



.cbOuZG {
    position: relative;
    display: flex;
    -webkit-box-pack: start;
    justify-content: flex-start;
    -webkit-box-align: center;
    align-items: center;
    width: 22px;
    height: 28px;
    margin-right: 12px;
    color: rgb(133, 133, 133);
}


.kTUuna {
    display: inline-block;
    vertical-align: baseline;
    
    line-height: 24px;
    font-weight: 400;
    font-size: 14px;
    color: inherit;
}


.xsort-area{
margin-bottom: 10px;
}



.xsort-div-filler{
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAAAvklEQVR42o3KsUqCYRiA0RPVZg6Fg2NgU0ME7g0KTg0SLtHaFYQ0VjRFDUGjEAhBi1vQ1Fx2BVJ4Aa4FQWT6tn38llTnWR//t+7MjY6mgh9mXYjUi4ZvzoVnDUXL9r35VJWxaqxvEcCGkSczkmNhR1ZHKEuuhZKsPWFbcimsyToS6pJd4YRkTs9IUZIzMLQFmNcSbk2oeBfuHDrVF8KHugllj0IIQ23daQsrNtUsIe9BWqbLuxde/WLBlQN/+wLDfD9iwnIihwAAAABJRU5ErkJggg==);
	background-position: 50% 50%;
	width: 32px;
	padding: 0;
	background-repeat: no-repeat;
	cursor: pointer;
}

.xsort-ul {
display: block !important;

}


.xsort-ul li{
border: none;
    margin: 0px;
    outline: none;
    margin-right: 4px;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    font: inherit;
    -webkit-font-smoothing: inherit;
    height: 24px;
    padding: 4px 5px;
    border-radius: 8px;
    position: relative;
    display: inline-block;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    background: #ebebeb;
    color: rgb(51, 51, 51);
    box-shadow: rgb(51 51 51 / 2%) 0px 2px 4px 0px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.xsort-ul li:last-child{
	border: none;
}
.xsort-ul li.current{
    color: #fff;
    font-weight: bold;
    background: #4caf50;
    position: relative;
}
.xsort-ul li.current:hover {
    color: #fff;
    font-weight: bold;
    background: #4caf50;
}
.xsort-ul li:hover{
	background: #e2e2e2;
	color:  var(--color-primary-p3-dark);
}
.xsort-ul li.xdesc, .xsort-ul li.xasc{
	background-position: 6px 50%;
	background-repeat: no-repeat;
}
.xsort-ul li.xdesc, .xdesc{
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAIElEQVQY02NgYGBgSPsPggwwQDQXwoRBFAHsekECEBoASUcnDSh9+RUAAAAASUVORK5CYII=);
}
.xsort-ul li.xasc, .xasc{
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAHklEQVQYV2NgAIO0/xAaygFBFA5UAMGBq0BRTDwXAPWMJw0b8PLnAAAAAElFTkSuQmCC);
}
span.xasc, span.xdesc{
	padding-left: 10px;
	background-position: 0 50%;
	background-repeat: no-repeat;
}

.xsort_empty{
	margin-top: 15px;
	background: #fff;
	border: 1px solid #ccc;
	padding: 15px;
	text-align: center;
	color: #444;
	border-radius: 3px;
	box-shadow: 0 2px 7px rgba(0,0,0,.1);
}

.xsort-admin-area{
	padding: 0 0 0 210px;
}
.xsort-admin-area:after{
	content: "";
	display: block;
	clear: both;
}
.xsort-admin-area ul{
	list-style: none;
	margin: 0 0 0 -210px;
	padding: 0;
	float: left;
	width: 200px;
	border-right: 1px solid #ddd;
}
.xsort-admin-area ul.loading{
	background: url(data:image/GIF;base64,R0lGODlhFAAUAPUEAPz6/PT29Pz+/PTy9Hx+fHx6fIyKjLSytISChOzq7MTCxJyanOTm5NTS1Nza3MzOzKSmpJyenOTi5Ozu7IyOjMTGxMzKzJSWlLy6vKyurLS2tLy+vJSSlNze3KSipKyqrNTW1P///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFBQAEACwAAAAAFAAUAAAGY0CCcAgIDI6DAGDIJCKfyGWTYHwGqshAExsQMAVc51E7JQiyQqS3LMQSAGM2s3o9ruXmMRI/t/KHWEl/bX6DWXZ/Z0l0f4xqeIoDhIhlcHGTSXdmloJ9WVeBklOhUGRsdYVMQQAh+QQFBQACACwKAAAABwAGAAAGHECCAfIACASFZMHgEBwihAJBEjgGFIqjdssNBIIAIfkEBQUAAwAsAAABABQAEwAABjvAgXBILD6KyGShcBAknwMCgQlNJgzLY7WYkBoA26LiYgmbz+hnIj1YpwMDOHsNPtfTd7Z+75bvt31JQQAh+QQFBQAAACwPAAUABQALAAAGI0CAEBAQFgoPIoEAEUYKBuHhKC0QhBKFZjgQFhMAgXeYEAcBACH5BAUFAAcALAEAAQATABMAAAZWwINQODkUh8hkMqBsGp0HREE5CQicR2QVAH1Gr90kgcgMC6XCsnmYXQsHbm08UjDEAdJIu6soFB5uE1IGAQB7TRMLf3JciBOASYdeTQABe5JJjVmNSEEAIfkEBQUADQAsAQABABMAEwAABlbAhlA4aBSHyGTyqFQylQSCcxBoNhJTgVXIQBQM1a2yQHyKo0Rx06wWYttLuFwZNs7vV2SAnUwYyHF1QgAKUQUHTkoLBYwHWnoDZgcEBg9bYW8MD4INQQAh+QQFBQAAACwHAAUACwAPAAAGI0CAcChMEAjEpHLJbDqf0Kh0upREDocIkogpeL9cw9EASQYBACH5BAUFAAIALAIADwAMAAUAAAYhQMGDkxAYj8YOoYBQBJBGwKFAJUCQBOPDQIUiAw8IFxkEACH5BAUFAAMALAAACwASAAkAAAY1wA3kMCgaj0hIgQBAOouER6GgeDqZCAIiYXU2poYu1HiYEhRNY0CBQArGA48RUVCL79e6MwgAIfkEBQUAAQAsAAAEABQAEAAABkDAgHBILFKIgkCiyBwWhA+KokkVQgoEQLVpKES2xCuiUDiAiwRC+UwsdL/sOHMMkQuf9vyQgrf3q3VNSXpnWFVBACH5BAUFAAMALAAAAQASABEAAAY1wIFwwBgaj0PBoeBAOgfLwuJ5bBQKhgTVcAUgCAQtVUgYEAqKsXrNbrvf8Lh8/jSU3Xd4IAgAIfkECQUAAwAsBAAAABAADwAABjbAAeABMRAGyKSyYSg4C8oo0kmIHKRRgiIgRUCx4DAWQUAIxMojOvldRwiGNVuOVNPvkTtdHQQAIfkECQUACwAsBAAAABAAFAAABm3ABeABMRAGgwBgwWw2DIVoYTKgVpsLKSFyCASQDMRBwCwQFAGsIPCJHpiGCRbLgBYeC/kcOyEQEGR7cwpmeIJYAQQFEIdzEAUGjVhtBJJNB1GWTBGQmgEIi5qEdwmSfX9pmqpZjR+CgauClY1BACH5BAkFAAsALAQAAAAQABQAAAaGwAXgATEQBoMAYMFsNgyFaAFJXTalhMghEBgkkIErQRFuCrhgpiHRbC8E1DDb3YYjBXR6wHJ55N0BBAUQf24RBQaFbQcFBIpNjAWPTIeJjwEIg5MKUQ9zfwmZBgFroEYFfo0KVkwBCgiCB0yNjRAHBxGZUVtMD1BSwAZ+bQFEUAQGEA9lTUEAIfkECQUACwAsAQAAABMAFAAABozAhXABeEAMhMEgABg6hQ1DYVpQWpvPBZUQyQQCg4QykC0QFOSh4Dt+GhJZocCaFsLjciseD17us3N+f099BRmDQ4WHiAtgd4wLGREYkI0IBBCVClMPUgSPcQkIBQYBDwSkoE4JSAUPTgUIaE4ACpeGThlbEBkHEaNTGQJPnVTGpK9xRUcEBAYQD3VCQQAh+QQJBQALACwBAAAAEwAUAAAGlsCFcAF4QAyEwSAAGDqFDUNhWlBam07BgUqIHAKBQUIZcG4LhEp5KACToVND4sm2lhEEwpxeVy4IBRV8T2FLaFiDQgJkBRGJhAkBBQePToWTlUOXjpkLlwSIiYuGBQqZhQF4CHuDAFYLDXGsTwkUFUtCZ2mhARV5BQ9sZ2gQBwcRCFQHAk8PUlTQBsF8AUZSBAYRD2tDQQAh+QQFBQALACwBAAAAEwAUAAAGjMCFcAF4QAyEwSAAGDqFDUNhWlBam07BgUqIZAKBQUIZcG4LBEV5KACToVND4sm2lhEEwpxeVy4IBQp8T2FLaFiDQgJkBRGJhEoFGY9OhZKUQ2EJjZhCYQGHmIuRgZiFAVJ6j6MDCw+AcoOsa2cIalkAdmwZXBAZBxENY0t0D1JUUxCfg0VHeQYZiENBACH5BAkFAAIALAEAAgANABIAAAYxQIFwKDwQj8ikcslsOptG6HNKVSIICGajQCUIAMdAUeA1BM6BwQAJUbvXQ7FDnUgHggAh+QQJBQALACwAAAIAFAASAAAGasDFQnAoGAmRQyAwSAifz2KBUAlABVaosGE0OLXgJ4JA+IbDhELlzJ4C2OdCBK5NWAsHehivhw4Wcn1Pf26CC3cFCoZCYwhmfVwUDAJnb2AVCQMDAZRPApZhTJqbS0yPYEujqn90qZmkYEEAIfkEBQUACwAsAAACABQAEgAABoDAxUJwKBgJkUMgMEgMBgGhtFggKKJSwfKJXTSMhoR0PHxCFwAEgSAmjwXmxYNQULjdTCikCriT4VAGBRF+eE9GB4VkeXSJilJMCRobEo+QUHkClnAJAQBOXYUAXAuZiqNPQqgDmncAeV15UK1CAqidi2aYW05nhrrAoXiRXMILQQAh+QQJBQAAACwAAAIAFAAPAAAGNkCAcEgsGouVo3LJNBSYxwAokoQSA4OBwErMBrjdwRecyCbG4KwYLBywh25AnJuAv4foe3oYBAAh+QQFBQAFACwAAAEAFAATAAAGecCCsCAZCicD5ABgHAYmCAIhcggEBslBoHkdNBTboQCQDRfIk4CgKb5OmIVkAM4WkrFnrLkudAOeanxGAnp6glxpcodGaIaLfViKjwVPWlhri4RaAEh7fGhMkZifkpyXn110bkujBWNlXFlaVqtpdX9KkUp0t6ubbEEAOw==) no-repeat 50% 50%;
}
.xsort-admin-area ul li{
	display: block;
	color: #f43;
	cursor: pointer;
	padding: 1px 0;
}
.xsort-admin-area ul li.current,
.xsort-admin-area ul li:hover{
	color:  var(--color-primary-p3-dark);
}
.xsort-admin-area ul li.current{
	font-weight: bold;
}
.xsort-admin-area p{
	margin: 0;
	padding: 7px 0 0;
}
.xsort-admin-area code{
	max-height: 400px;
	overflow: auto;
}
.xsort-div-clearall{
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAQAAACR313BAAAAKklEQVQoz2NgGATA4L/Bf3QWmrTBfwSNQwEOSWQT8EjiNRqnCQRcPgAAAG+mJxC7ICdhAAAAAElFTkSuQmCC);
	background-position: 50% 50%;
	width: 32px;
	padding: 0;
	background-repeat: no-repeat;
	cursor: pointer;
}




.dfiJIc {
    width: 100%;
    position: fixed;
    transition: transform 0.5s cubic-bezier(0.8, 0.2, 0.2, 0.8);
    transform: translateY(0px);
    top: 0px;
    height: 56px;
    box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px !important;
    border-radius: 8px;
    background: #fff;
    border: 1px solid #f2f2f2;
}


	   
.cKSkd {
    border: none;
    margin: 0px;
    outline: none;
    overflow: visible;
    cursor: pointer;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    background: transparent;
    font: inherit;
    text-align: center;
    -webkit-font-smoothing: inherit;
    display: flex;
    flex-direction: column;
    width: 95px;
    height: 100%;
    position: fixed;
    top: 0px;
    padding: 16px;
    z-index: 9;
    color:  var(--color-primary-p3-dark);
	font-weight: bold;
    font-size: 14px;
	display: none;
}

.cKSkd:hover {
       background-color: rgb(57 69 86 / 13%);
}   



.sort-torg {
    height: 285px;
    width: 190px;
    position: relative;
    min-height: 1px;
    margin: 0px 2px 0px 2px;
	float: none;
    display: inline-block;
	border-radius: 8px;
	border: 1px solid #ececec;
}

.sort-torg:hover .card-title {color:  var(--color-primary-p3);}




.sort-torg a:hover img {    
-webkit-transform: scale(1.1);
transform: scale(1.1);}



.card-title {
    margin-bottom: 0.75rem;
    
    font-weight: 600;
    font-size: 14px;
}

.m-0 {
    color: #212121;
    max-width: 100%;
    margin-bottom: 8px;
    line-height: 1.286;
    font-size: 14px;
    min-height: 46px;
    font-weight: 400;
}

.mb-0 {
	color: rgb(51, 51, 51);
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    min-width: 0px;
	font-size: 22px;
	text-align: center;
}



.mb-5, .my-5 {
    margin-bottom: 15px !important;
}

.float-price {
    font-size: 16px;
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    -o-text-overflow: ellipsis;
    position: relative;
    margin-bottom: 5px;
    padding-right: 40px;
    min-height: 15px;
    color:  var(--color-primary-p3-dark);
}


.card-body {
    padding-left: 12px;
    padding-right: 12px;
    padding-top: 10px;
    padding-bottom: 10px;
    display: block;
    position: relative;
}






.cat-sortlist .sort-torg {
    height: 245px;
    width: 202px;
    position: relative;
    min-height: 1px;
    margin: 0px 2px 0px 2px;
    -webkit-backface-visibility: hidden;
    -webkit-tap-highlight-color: transparent;
    -webkit-touch-callout: none;
    transition: box-shadow .3s ease,background .3 ease;
	float: none;
    display: inline-block;
	border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}


.sort-torg:hover {
    border: 1px solid  var(--color-primary-p3);
}


.speedbar{
	margin: 0;
    list-style: none;
    display: inline-block;
    vertical-align: middle;
    max-width: 100%;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}
.speedbar:after{
	content: "";
	display: block;
	clear: both;
}
.speedbar li{
	display: inline;
    margin-right: 3px;
    color: #222;
    font-size: 14px;
}
.speedbar li.speedbar_sep{
	color: #999;
}


.text-center {
    text-align: center !important;
    width: 100%;
    margin-bottom: 30px;
    font-size: 26px;
    font-weight: 500;
    transform: translateY(15%);
    line-height: 35px;
}


.text-static {
    text-align: center !important;
    width: 100%;
    margin-bottom: 30px;
    font-size: 26px;
    font-weight: 500;
    line-height: 35px;
}

.p-13 {
    padding: 10px;
}

.mt-4, .my-4 {
    margin-top: 5px !important;
}



	.usluga-srochno { 
    box-shadow: 0 0 0 1px  var(--color-primary-p3);
    -webkit-border-bottom-left-radius: 12px;
    -webkit-border-top-right-radius: 12px;
    border-bottom-left-radius: 12px;
    border-top-right-radius: 12px;}

	.sw-sale { 
	font-weight: bold;
    background: red;
    height: 18px;
    font-size: 13px;
    color: #fff;
    letter-spacing: 1px;
    line-height: 17px;
    width: 100%;
    text-align: center;
    display: block;
    top: -15px;
    position: absolute;
    left: 0px;
    z-index: 1;
    overflow: hidden;}


.usluga-magazin {
	font-weight: bold;
    background: #4b616b;
    height: 18px;
    font-size: 13px;
    color: #fff;
    letter-spacing: 1px;
    line-height: 17px;
    width: 100%;
    text-align: center;
    display: block;
    top: -15px;
    position: absolute;
    left: 0px;
    z-index: 1;
    overflow: hidden;	
}







 .usluga-videlenie {
    box-shadow: 0 0 0 1px #c134d9;
 }

 .usluga-videlenie-s {
    background-color: #FFFCEE;
 }


.usluga-top {box-shadow: 0 0 0 1px #9C27B0;}


.topka {
    font-weight: bold;
    background: #7c00ff;
    height: 18px;
    font-size: 13px;
    color: #fff;
    letter-spacing: 1px;
    line-height: 17px;
    width: 100%;
    text-align: center;
    display: block;
    top: -15px;
    position: absolute;
    left: 0px;
    z-index: 1;
    overflow: hidden;
}




 .usluga-top-s {
    font-weight: bold;
    background: #9C27B0;
    height: 18px;
    font-size: 13px;
    color: #fff;
    letter-spacing: 1px;
    line-height: 17px;
    width: 100%;
    text-align: center;
    display: block;
    top: -15px;
    position: absolute;
    left: 0px;
    z-index: 1;
    overflow: hidden;
 }
 
 .usluga-top-r {
    position: absolute;
    left: 10px;
    top: 10px;
    display: block;
    margin-right: 2px;
    border: 1px solid #5eb6ff;
    background-color: #6cbcff;
    color: #ffffff;
    text-transform: uppercase;
    border-radius: 2px;
    padding: 0 3px;
    font-size: 12px!important;
    line-height: 17px!important;
    height: 18px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-weight: 700;
    z-index: 9;
 }
 




hr {
  box-sizing: content-box;
  height: 0;
  overflow: visible;
}

h1, h2, h3, h4, h5, h6 {
  margin-top: 0;
  margin-bottom: 0.5rem;
  line-height: normal;
}

p {
  margin-top: 0;
  margin-bottom: 1rem;
}

abbr[title],
abbr[data-original-title] {
  text-decoration: underline;
  -webkit-text-decoration: underline dotted;
  text-decoration: underline dotted;
  cursor: help;
  border-bottom: 0;
  -webkit-text-decoration-skip-ink: none;
  text-decoration-skip-ink: none;
}

address {
  margin-bottom: 1rem;
  font-style: normal;
  line-height: inherit;
}

ol,
ul,
dl {
  margin-top: 0;
}

ol ol,
ul ul,
ol ul,
ul ol {
  margin-bottom: 0;
}

dt {
  font-weight: 700;
}

dd {
  margin-bottom: .5rem;
  margin-left: 0;
}

blockquote {
  margin: 0 0 1rem;
}

b,
strong {
  font-weight: bold;
      color: black;
}


.fbold, strong {
    font-weight: 500;
} 


small {
  font-size: 80%;
}

sub,
sup {
  position: relative;
  font-size: 75%;
  line-height: 0;
  vertical-align: baseline;
}

sub {
  bottom: -.25em;
}

sup {
  top: -.5em;
}

a {
  color:  var(--color-primary-p3);
  text-decoration: none;
  background-color: transparent;
  font-weight: bold;
}

a:hover {
	color: d21746;
}



a:not([href]):not([tabindex]) {
  color: inherit;
  text-decoration: none;
}

a:not([href]):not([tabindex]):hover, a:not([href]):not([tabindex]):focus {
  color: inherit;
  text-decoration: none;
}

a:not([href]):not([tabindex]):focus {
  outline: 0;
}

pre,
code,
kbd,
samp {
  
  font-size: 1em;
}

pre {
  margin-top: 0;
  margin-bottom: 1rem;
  overflow: auto;
}

figure {
  margin: 0 0 1rem;
}

img {
  vertical-align: middle;
  border-style: none;
}

svg {
  overflow: hidden;
  vertical-align: middle;
}

table {
  border-collapse: collapse;
}

caption {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
  color: #6c757d;
  text-align: left;
  caption-side: bottom;
}

th {
  text-align: inherit;
}

label {
  display: inline-block;
  margin-bottom: 0.5rem;
}

button {
  border-radius: 0;
}

button:focus {
  outline: 1px dotted;
  outline: 5px auto -webkit-focus-ring-color;
}

input,
button,
select,
optgroup,
textarea {
  margin: 0;
  font-family: "Cutest", sans-serif;
  font-size: inherit;
  line-height: inherit;
}

button,
input {
  overflow: visible;
}

button,
select {
  text-transform: none;
}

select {
  word-wrap: normal;
}





*, *::before, *::after {
    box-sizing: border-box;
}

.clearfix::after {
    display: block;
    clear: both;
    content: "";
}

#nav-load {
    text-align: center;
    padding: 20px 0 0 0;
}

#nav-load a {
    transition: .2s all;
    border: 0;
    background:  var(--color-primary-p3-dark);
    box-shadow: 0 1px 0 #e1e1e1;
    display: inline-block;
    border-radius: 99px;
    padding: 0 28px;
    height: 38px;
    line-height: 38px;
    color: #fff;
    font-size: 14px;
    text-transform: uppercase;
    font-weight: 700;
}

.nav-load span {display: none;}

.get_next_page_separator {
    font-weight: 700;
    text-transform: uppercase;
    font-size: 18px;
    color: #282828;
    margin: 30px 0;
    position: relative;
}



.get_next_page_separator:after {
    content: "";
    border-bottom: 1px dashed #bebebe;
    display: block;
    position: relative;
}


.dnone {display: none;}    



.status {
    background-color: rgba(0,160,70,.08);
    display: inline-flex;
    align-items: center;
    padding: 3px 22px;
    border-radius: 20px;
    color: #00a046;
    line-height: 1.2;
}

	


.f-weight-5 {
    font-weight: 500!important;
}

.text-uppercase {
    text-transform: uppercase;
}

.align-items-center {
    align-items: center!important;
}
.d-flex {
    display: flex!important;
}





.status .status__icon {
	background-color: #00a046;
    width: 18px;
    height: 18px;
    margin-right: 8px;
    font-size: 16px;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: #fff;
}



.status .status__title {
    font-size: 12px;
    line-height: normal;
    white-space: nowrap;
}

.rounded-10 {
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
}








.cfloAv .sc-hYZPRl {
    top: 56px;
}

.jFNmll {
    position: absolute;
    padding-bottom: 24px;
    width: 100%;
    visibility: visible;
    opacity: 1;
    transform: translate3d(0px, 0px, 0px);
    overflow: hidden;
    transition: opacity 0.2s linear 0s, transform 0.2s linear, visibility 0s linear;
}

.iddELS {
    position: relative;
    z-index: -1;
    padding: 16px 0px 24px;
    background: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px;
}


.ewqGCM {
    max-width: 1264px;
    min-width: 320px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    padding-left: 16px;
    padding-right: 16px;
}


.gdsrAv {
    position: relative;
}

.fFvlhF {
    display: flex;
}

.rrLIJ {
    margin-left: -8px;
    margin-right: -8px;
    box-sizing: border-box;
    margin: 0px -5px;
    min-width: 0px;
    flex-wrap: wrap;
}


.kPwfsx {
    position: absolute;
    top: 20px;
    right: 0px;
    width: 248px;
    height: 188px;
}


.dEEPDV {
    display: inline-block;
    position: relative;
    background: center center no-repeat transparent;
}


.dNmlyK {
    position: absolute;
    z-index: -1;
    width: 188px;
    height: 188px;
    left: 50%;
    margin-left: -94px;
    border-radius: 50%;
    background: rgb(250, 250, 250);
}

.cVaWqn {
    position: absolute;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    visibility: visible;
}


.gmzLtL {
    position: relative;
}


.gmzLtL:last-child .sc-dHntBn {
    border: none;
}




.bPnwqf {
    padding-right: 8px;
    padding-left: 8px;
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 25%;
}



.fgpNWL {
    height: 100%;
    border-right: 1px solid rgb(245, 245, 245);
}


html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font-size: 100%;
    vertical-align: baseline;
}



ol, ul {
    list-style: none;
}





li {
    display: list-item;
    text-align: -webkit-match-parent;
}



.fbNnLF {
    display: block;
    cursor: default;
    padding: 8px 16px 8px 48px;
    margin: 0px 0px 0px -12px;
    background-size: 24px;
    background-repeat: no-repeat;
    background-position: 12px 8px;
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
}



.fbNnLF:hover {
    display: block;
    cursor: default;
    padding: 8px 16px 8px 48px;
    margin: 0px 0px 0px -12px;
    background-size: 24px;
    background-repeat: no-repeat;
    background-position: 12px 8px;
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
}

.iZoMaM {
    color: rgb(51, 51, 51);
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    letter-spacing: normal;
    text-decoration: underline;
    font-size: 14px;
    line-height: 1.71;
}


.fbNnLF a:hover {
    color: rgb(112, 146, 254);
}

.iZoMaM:hover {
    text-decoration: underline;
    color: rgb(112, 146, 254);
}


.iBbjTI {
    color: rgb(51, 51, 51);
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    letter-spacing: normal;
    font-size: 14px;
    line-height: 1.71;
}


.dQACEC {
    margin-bottom: 7px;
}

.fhFmlt {
    color: rgb(51, 51, 51);
    font-weight: 500;
    font-size: 20px;
    line-height: 1.6;
}


.kgPYcZ {
    display: flex;
    width: 100%;
}



.kgPYcZ ul {
    width: 50%;
}

.cNPAMN:hover {
    text-decoration: underline;
}

.cNPAMN {
    color: rgb(112, 146, 254);
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    letter-spacing: normal;
    font-size: 14px;
    line-height: 1.71;
}

.cNPAMN:hover {
    text-decoration: underline;
}


.fsNAux {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 50%;
    padding-right: 5px;
    padding-left: 5px;
}

.fsNAux {
    padding-right: 8px;
    padding-left: 8px;
}


.menuhblok {display: none;}



.catlist-a {
    border: none;
    margin: 0px;
    outline: none;
    margin-right: 1px;
    margin-left: 1px;
    height: 30px;
    padding: 4px 8px;
    border-radius: 8px;
    position: relative;
    display: inline-block;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    background: #f3f3f3;
    color: rgb(51, 51, 51);
    box-shadow: rgb(51 51 51 / 2%) 0px 2px 4px 0px;
    width: 19.8%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: "Cutest", sans-serif;
    font-size: 14px;
}


.catlist-a:hover {background:#ecefff;}


.tovar1 {height: 175px !important;}

.tovar2 {height: 320px !important;padding-top: 5px !important;}



.tovar2 .swiper-wrapper {height: 280px !important;}
.tovar2 .swiper-wrapper {

    display: inline-grid;
    grid-auto-flow: column;
    width: 100%;
    position: relative;
    grid-column-gap: 20px;
    grid-auto-columns: calc((100% - 95px) / 5);
}

.tovar2 .swiper-slide { width: 202px !important;margin: 0 auto;}


#content-cat .product-layout.product-layout-featured {width: 206px;}

.cat-brands .product-thumb {
    margin-bottom: 0;
    padding: 10px;
    border: 1px solid #ececec;
    transition: .3s;
    border-radius: 6px;
    background-color: #fff;
    margin-bottom: 20px;
    height: 180px;
    padding: 15px;
    position: relative;
    text-align: center;
}

#content-info .product-layout.product-layout-featured {width: 100%;height: 180px;}


#content-info  .product-thumb .image { margin-bottom: 15px; font-size: 30px; }
#content-info  .product-thumb {height: 180px;}



#content-info .product-thumb .buttons-row {display: flex !important;flex-direction: column !important;}
#content-info .product-thumb .buttons-row span {
color: #777;
font-size: 12px;
line-height: 18px;
font-weight: 500;
}


#content-info .product-thumb i {color:  var(--color-primary-p3);}
#content-info .product-thumb:hover i {color:  var(--color-primary-p3-light);}


.product-layout.product-layout-featured {
    width: 100%;
    display: inline-block;
    position: relative;
    padding: 0 2px;
    font-size: 16px;
}
.product-layout {
    padding: 0 8px;
    position: relative;
}

.product-thumb {
    margin-bottom: 0;
    padding: 10px;
    border: 1px solid #ececec;
    border-radius: 10px;
    transition: .3s;
    border-radius: 6px;
    background-color: #fff;
    margin-bottom: 20px;
    height: 340px;
    padding: 15px;
    position: relative;
	text-align: center;
}


.product-layout:hover .product-thumb {
    border: 1px solid  var(--color-primary-p3);
}






.owl-carousel .owl-item .button-group {
    text-align: center;
}
.button-group.wishlist {
    z-index: 5;
    top: 0;
    right: 0;
}
.button-group.wishlist {
    position: absolute;
    top: 13px;
    right: 14px;
}
.product-thumb .button-group {
    text-align: center;
}

.product-thumb .image {
    text-align: center;
	position: relative;
}


.newest {
    position: absolute;
    top: 0;
    left: 0;
    background-color: var(--color-primary-p3-light);
    color: #fff;
    padding: 0 5px;
    font-size: 11px;
    border-radius: 5px;
    text-align: center;
	z-index: 1;
}


.top {
    position: absolute;
    top: 0;
    left: 0;
    background-color: #7c00ff;
    color: #fff;
    padding: 0 5px;
    font-size: 11px;
    border-radius: 5px;
    text-align: center;
	z-index: 1;
}

.product-thumb .image a {
    display: block;
}

.product-thumb .image img {
    margin-left: auto;
    margin-right: auto;
    -moz-transition: .3s all ease;
    -o-transition: .3s all ease;
    -webkit-transition: .3s all ease;
    transition: .3s all ease;
    border-radius: 6px;
}

.product-layout:hover .product-thumb .image img {    
	-webkit-transform: scale(1.1);
    transform: scale(1.1);
}


.product-thumb h4 {
    min-height: 60px;
}
.product-thumb h4 {
    font-weight: 700;
    min-height: 40px;
    max-height: 40px;
    overflow: hidden;
    margin: 0;
    margin-top: 5px;
    margin-bottom: 5px;
	font-size: 15px;
}


.product-thumb h4 a {
    color:  var(--color-primary-p3-dark);
    font-size: 14px;
    font-weight: 600;
    line-height: 21px;
}


.product-thumb:hover h4 a {
    color:  var(--color-primary-p3);
    transition: color .3s linear;
}



.buttons-row {
    margin: 0;
}

.buttons-row>div {
    padding-right: 0;
    padding-left: 0;
	height: 50px;
}





.product-thumb .price {
	font-size: 16px;
    font-weight: 700;
    margin-bottom: 5px;
    margin-top: 0;
    text-align: center;
	color:  var(--color-primary-p3-dark);
	
}
.product-thumb p {
    opacity: 1;
    color: #979697;
    font-size: 12px;
    font-weight: 400;
    line-height: 16.21px;
    margin-bottom: 4px;
}
p:last-child {
    margin-bottom: 0;
}

.product-thumb .price span, #cart_view .price span {
    font-size: 13px;
    font-weight: bold;
	margin-left: 5px;
}


.product-thumb .price-old span {
	margin-left: 0px;
}

.product-thumb .price-old {
	position: relative;
	font-size: 13px;
    color: #6a6a6a;
}


.product-thumb .price-old:before {
    content: "";
    width: 100%;
	height: 1.3px;
    background: red;
    position: absolute;
    top: 50%;
    left: 0;
    transform: rotate(-1deg);
}


.owl-carousel .owl-item .button-group {
    text-align: center;
}

.product-thumb .button-group button.add_to_cart {
    width: inherit;
    height: inherit;
    border: solid 1px rgba(0,0,0,.3);
    border-radius: 8px;
    margin-right: 0;
    display: inline-block;
    vertical-align: top;
    line-height: 1;
    padding: 8px 15px 7px;
    background: #fff;
    font-size: 14px;
    font-weight: 400;
}


.product-thumb .button-group a.add_to_cart {
    border-radius: 8px;
    margin-right: 0;
    display: inline-block;
    vertical-align: top;
    line-height: 1;
    padding: 8px 15px 7px;
    background:  var(--color-primary-p3);
    color: #fff;
    font-size: 14px;
    font-weight: 400;
    width: 100%;
	border: solid 1px  var(--color-primary-p3);
}


.product-thumb .button-group a.add_to_cart:hover {
	color: #000000!important;
    transition: color linear 0s;
    background: #fff;
    border: solid 1px  var(--color-primary-p3);
}

.product-thumb .button-group a.add_to_cart:focus {
	color: #fff!important;
    transition: color linear 0s;
    background:  var(--color-primary-p3-dark);
    border: solid 1px  var(--color-primary-p3-dark);
}

.product-thumb .button-group a.add_to_cart.active_goods {
	color: #fff!important;
    transition: color linear 0s;
    background:  var(--color-primary-p3-light);
    border: solid 1px  var(--color-primary-p3-light);
}






.salest {
    position: absolute;
    top: 0;
    left: 0;
    background-color: red;
    color: #fff;
    padding: 0 5px;
    font-size: 11px;
    border-radius: 5px;
    z-index: 1;
    text-align: center;
}


.rate {width: 0%;}
.rate1 {width: 20%;}
.rate2 {width: 40%;}
.rate3 {width: 60%;}
.rate4 {width: 80%;}
.rate5 {width: 100%;}

.rating-box, .rating-box .rating
{
	background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='13.68' height='43.89' viewBox='0 0 13.68 43.89'%3E%3Ctitle%3Estar%3C/title%3E%3Cpath d='M4.68,4.31l-4.34.5a.27.27,0,0,0-.3.24v.06c-.1.1,0,.3.1.4,1.34,1.1,3.2,2.9,3.2,2.9s-.5,2.5-.9,4.2c0,.2,0,.3.2.4A.3.3,0,0,0,3,13c1.5-.9,3.8-2.1,3.8-2.1s2.3,1.3,3.8,2.1a.3.3,0,0,0,.4,0,.7.7,0,0,0,.2-.4c-.3-1.7-.9-4.2-.9-4.2s1.9-1.7,3.2-2.9c.1-.1.2-.3.1-.4s-.2-.3-.3-.3l-4.4-.5s-1-2.4-1.8-4c0-.1-.2-.2-.3-.2a.52.52,0,0,0-.4.2C5.78,1.91,4.68,4.31,4.68,4.31Z' transform='translate(0 -0.11)' fill='%23ffd500'/%3E%3Cpath d='M4.64,35.22l-4.3.5A.28.28,0,0,0,0,36V36c-.1.2,0,.3.1.4,1.3,1.2,3.2,2.9,3.2,2.9s-.5,2.5-.9,4.2c0,.2,0,.3.2.4a.28.28,0,0,0,.4,0c1.5-.9,3.8-2.1,3.8-2.1s2.3,1.3,3.8,2.1a.28.28,0,0,0,.4,0,.7.7,0,0,0,.2-.4c-.3-1.7-.9-4.2-.9-4.2s1.9-1.7,3.2-2.9c.1-.1.2-.3.1-.4s-.2-.3-.3-.3L9,35.22s-1.1-2.4-1.8-3.9a.51.51,0,0,0-.7-.1l-.1.1C5.74,32.82,4.64,35.22,4.64,35.22Z' transform='translate(0 -0.11)' fill='%23ccc'/%3E%3C/svg%3E");
	}

.rating-box {
    background-position: 0 -31px;
    background-repeat: repeat-x;
    float: left;
    height: 15px;
    margin: 0 5px 0 0;
    position: relative;
    width: 69px;
}

.rating-box .rating {
    background-position: 0 0;
    background-repeat: repeat-x;
    height: 14px;
    left: 0;
    position: absolute;
    top: 0;
}


.product-review {
    display: inline-block;
    font-size: 14px;
    padding: 8px 0;
}







.eblogList__card:hover .eblogList__card:before {
	background: rgb(0 0 0 / 74%);
}




.eblogList__cards {
    width: 100%;
    height: 100%;
    display: flex;
    box-sizing: content-box;
    gap: 16px;
    z-index: 1;
}


.eblogList__cards_cat {
    width: 100%;
    height: 100%;
    box-sizing: content-box;
    gap: 16px;
    z-index: 1;
}



.eblogList__cards_cat .eblogList__card {
    position: relative;
    display: inline-flex;
    align-items: center;
	width: 203px;
    height: 200px;
    background-color: #f5f6f7;
    border-radius: 4px;
    float: none;
	margin-right: 4px;
}


.eblogList__cards_cat .eblogList__card:nth-child(5n) {
	margin-right: 0px;
}




.eblogList__card {
    position: relative;
    display: inherit;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 200px;
    background-color: #f5f6f7;
    border-radius: 4px;
}

.eblogList__card:before {
    position: absolute;
    content: '';
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,.6);
    border-radius: 4px;
    z-index: 1;
}

.eblogList__card a {
    display: inherit;
    justify-content: inherit;
    align-items: inherit;
    width: inherit;
    height: inherit;
}


.eblogList__card-title {
    position: absolute;
    font-weight: 600;
    font-size: 16px;
    color: #fff;
    text-align: center;
    line-height: normal;
    padding: 0px 10px;
    z-index: 5;
    margin: 40% 0px;
}


.eblogList__card:hover .eblogList__card-title {color: gold;}



.eblogList__card-image {
    width: 100%;
    height: 100%;
    border-radius: 4px;
}





.rate {width: 0%;}
.rate1 {width: 20%;}
.rate2 {width: 40%;}
.rate3 {width: 60%;}
.rate4 {width: 80%;}
.rate5 {width: 100%;}

.rating-box, .rating-box .rating
{
	background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='13.68' height='43.89' viewBox='0 0 13.68 43.89'%3E%3Ctitle%3Estar%3C/title%3E%3Cpath d='M4.68,4.31l-4.34.5a.27.27,0,0,0-.3.24v.06c-.1.1,0,.3.1.4,1.34,1.1,3.2,2.9,3.2,2.9s-.5,2.5-.9,4.2c0,.2,0,.3.2.4A.3.3,0,0,0,3,13c1.5-.9,3.8-2.1,3.8-2.1s2.3,1.3,3.8,2.1a.3.3,0,0,0,.4,0,.7.7,0,0,0,.2-.4c-.3-1.7-.9-4.2-.9-4.2s1.9-1.7,3.2-2.9c.1-.1.2-.3.1-.4s-.2-.3-.3-.3l-4.4-.5s-1-2.4-1.8-4c0-.1-.2-.2-.3-.2a.52.52,0,0,0-.4.2C5.78,1.91,4.68,4.31,4.68,4.31Z' transform='translate(0 -0.11)' fill='%23ffd500'/%3E%3Cpath d='M4.64,35.22l-4.3.5A.28.28,0,0,0,0,36V36c-.1.2,0,.3.1.4,1.3,1.2,3.2,2.9,3.2,2.9s-.5,2.5-.9,4.2c0,.2,0,.3.2.4a.28.28,0,0,0,.4,0c1.5-.9,3.8-2.1,3.8-2.1s2.3,1.3,3.8,2.1a.28.28,0,0,0,.4,0,.7.7,0,0,0,.2-.4c-.3-1.7-.9-4.2-.9-4.2s1.9-1.7,3.2-2.9c.1-.1.2-.3.1-.4s-.2-.3-.3-.3L9,35.22s-1.1-2.4-1.8-3.9a.51.51,0,0,0-.7-.1l-.1.1C5.74,32.82,4.64,35.22,4.64,35.22Z' transform='translate(0 -0.11)' fill='%23ccc'/%3E%3C/svg%3E");
	}

.rating-box {
    background-position: 0 -31px;
    background-repeat: repeat-x;
    float: left;
    height: 15px;
    margin: 0 5px 0 0;
    position: relative;
    width: 69px;
}

.rating-box .rating {
    background-position: 0 0;
    background-repeat: repeat-x;
    height: 14px;
    left: 0;
    position: absolute;
    top: 0;
}



.amreview-summary-info {
    vertical-align: middle;
}

.amreview-summary-info, .amreview-summary-details {
    display: inline-block;
}


.amreview-summary-info .amreview-summary {
    float: left;
    font-size: 40px;
    line-height: 1;
    color:  var(--color-primary-p3-dark);
    margin: 0 25px 0 0;
    padding: 0;
}


.amreview-rating-wrapper {
    float: left;
}

.amreview-summary-info .amreview-count {
    display: inline-block;
    font-size: 14px;
    color: #999;
    margin-top: 4px;
    padding: 0;
    margin-bottom: 0;
}



.more-link {margin-top: 10px; align-items: center; font-size: 18px; color:  var(--color-primary-p3-light); margin-left: 5px;}


.more-link svg:last-child {
    margin-left: 5px;
}
.more-link i {
    font-size: 13px;
}

.more-link:hover i {
transform: translateX(2px);
}


.cart_clear {
	text-align: center;
    font-size: 22px;
    margin-top: 30px;
    background: #fff;
    padding: 25px;
}

.cart_clear i {
display: block;
    margin-bottom: 30px;
    font-size: 35px;
}



.desc-full #advice {
    padding: 0px;
    width: 100%;
}

.desc-full .rating-box {float: right;}


.desc-full .product-layout {float: left;width: 200px;margin-right: 15px;margin-top: 5px;}
.desc-full .product-layout .product-thumb {height: 170px;}




	.catlist-a i {color:  var(--color-primary-p3-dark);}
	.catlist-a:hover i {color:  var(--color-primary-p3-light);}


	.uliuliahuli .favmod {    
		margin: 0px;
		padding: 0px;
		cursor: pointer;
		display: block;
		float: left;
		padding: 10px 15px;
		border-bottom: none;
	    margin: 2px;}

	.uliuliahuli .favmod:hover {background: #d6d6d7;border-radius: 8px;}

	.uliuliahuli .favmod .favmod-add {color:  var(--color-primary-p3-dark);}

	.sc-kHpSfa .product-thumb {height: 150px;}


	.dop-item {
		padding: 10px;
		margin: 10px 0px;
	}

	.dop-item:hover {
	box-shadow: 0 0 15px rgb(0 0 0 / 6%);
     }

	.dop-item-i {
		margin-right: 15px;
		width: 38px;
	}

	.dop-item-i i {
		color: #656c7d;
		font-size: 30px;
		-webkit-transition: color .3s ease;
		transition: color .3s ease;
		display: block;
		width: 38px;
	}

	.dop-item:hover .dop-item-i i {
		color:  var(--color-primary-p3);
	}

	.dop-item-info {
		-ms-flex-direction: column !important;
		flex-direction: column !important;
		display: -ms-flexbox !important;
		display: -webkit-flex !important;
		display: flex !important;
	}

	
	.dop-item-title {
		line-height: 15px;
		margin-bottom: 7px;
		font-weight: 500;
		text-decoration: underline !important;
		-webkit-transition: color .3s ease;
		transition: color .3s ease;
		color: #272323;
		font-size: 12px;
	}

	.dop-item-text {
		line-height: 18px;
		color: #818181;
		font-size: 11px;
	}


	

.item3 {
    width: 100%;
    height: auto;
    overflow: hidden;
    position: relative;
    background-color: rgb(229 255 230 / 10%) !important;
    -webkit-box-shadow: 0px 0px 13px 0px rgb(82 63 105 / 5%);
    box-shadow: 0px 0px 13px 0px rgb(82 63 105 / 5%);
    border-radius: 0.25rem;
    text-align: center;
}
.item3:after {
    content: ' ';
    width: 404px;
    height: 555px;
    position: absolute;
    bottom: 49%;
    left: -13px;
    border-radius: 20%;
    background: #ffffff54;
    z-index: 0;
    animation: wave 17s infinite linear;
}



.item3 img {opacity: 0.8;}
.item3:hover img {opacity: 1;}


.ya-share2 {
    text-align: center;
    position: relative;
    margin-top: 50px;
    border-top: solid 1px #e6e6e6;
    padding-top: 10px;
}


.blog-share .ya-share2 {
	text-align: center;
    position: relative;
    margin-top: 5px;
	border-top: solid 1px #e4e4e4;
    padding-top: 10px;
}



.hXGkGvxx .owl-controls {display: none;}
.hXGkGvxx:hover .owl-controls {display: block;}





@media screen and (max-width: 1063px) {
	.hero__btnContainer {
		padding-top: 5px;
	}
	
	#content-info .product-layout.product-layout-featured {
		width: 100%;
		height: 180px;
	}
	

	.product-thumb .image a {
		height: 160px;
	}

	.product-thumb .image a img {height: 155px;}


	.desc-full #advice {
		padding: 0px;
		width: 100%;
	}

	}
	


	@media screen and (min-width: 1200px) {
	
		.contact-static {
			-ms-flex: 0 0 58.3333333333%;
			flex: 0 0 58.3333333333%;
			max-width: 58.3333333333%;
	   }
		.contact-map {
			-ms-flex: 0 0 41.6666666667%;
			flex: 0 0 41.6666666667%;
			max-width: 41.6666666667%;
	   }


	   .contact-posit {
		-ms-flex: 0 0 57%;
		flex: 0 0 57%;
		max-width: 57%;
   }
	.contact-posit2 {
		-ms-flex: 0 0 43%;
		flex: 0 0 43%;
		max-width: 43%;
   }




	}
	
	.ls-contact-location {
		background-color: rgb(255, 255, 255);
		border: 1px solid #ececec;
		color: #777;
		margin-bottom: 30px !important;
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-ms-flex-wrap: wrap;
		flex-wrap: wrap;
		margin-right: -15px;
		margin-left: -15px;
   }
	.no-gutters {
		margin-right: 0;
		margin-left: 0;
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-ms-flex-wrap: wrap;
		flex-wrap: wrap;
   }
	.ls-contact-location-store-title {
		color: #272323;
		font-weight: 500;
		font-size: 18px;
		line-height: 32px;
		margin-bottom: 13px;
   }
	.ls-contact-location-address {
		margin-bottom: 35px;
		color: #0078ac;
   }
	.ls-contact-location-info {
		padding: 30px;
   }
	.ls-contact-location-title {
		color: #272323;
		font-size: 16px;
		line-height: 22px;
		margin-bottom: 20px;
   }



   .header__logo-d { max-width: 100%;}




	
	@media screen and (max-width: 900px) {



		.cart-total__submit {width: 100% !important;}


		#payments > div {
			width: 100% !important;
		}

		.videotube {
			margin: 0px auto;
			margin-top: 200px;
			padding: 5px;
			width: 90%;
			max-width: 100%;
			text-align: center;
			animation-name: showAuthBorder;
			animation-duration: 1s;
			animation-fill-mode: forwards;
			position: relative;
			animation-name: fadeInUp;
			animation-duration: 0.8s;
			border: 1px solid rgb(235, 235, 235);
		}


		.dop>a {width: 100% !important;
			margin-bottom: 15px !important;
			border-top: dashed 1px #f1f1f1;
			padding-top: 15px;}


		.header__logo-mob { max-width: 100%;}


		.icon-bar {
			display: -webkit-box;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: reverse;
			flex-direction: column-reverse;
			-webkit-tap-highlight-color: rgba(15,119,176,.1);
			background-color: #fff;
			box-shadow: 0 2px 10px 0 rgb(0 0 0 / 12%);
		}


		.sub-icon-bar {
			display: -webkit-box;
			display: flex;
			max-width: 100vw;
			padding: 10px;
			box-sizing: border-box;
			-webkit-box-align: stretch;
			align-items: stretch;
			overflow: hidden;
		}


		.sub-icon-bar a {
			-webkit-box-flex: 1;
			flex-grow: 1;
			display: -webkit-box;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			flex-direction: column;
			-webkit-box-align: center;
			align-items: center;
			-webkit-box-pack: justify;
			justify-content: space-between;
			position: relative;
			font-size: calc(10px + .4vw);
			font-size: 11px;
			line-height: 13px;
			text-decoration: none;
			color: #999;
			touch-action: none;
			-webkit-user-select: none;
			width: 20%;
			-webkit-transition: .2s cubic-bezier(.4,0,.2,1);
			transition: .2s cubic-bezier(.4,0,.2,1);
			-webkit-transition-property: color;
			transition-property: color;
			-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
		}

		.sub-icon-bar a:hover span {
			color: var(--color-primary-p3-light) !important;
		 
		 }
		 
		 .active {
			   color: var(--color-primary-p3-light);
		 }
		 
		 .activecat {
			   color: var(--color-primary-p3-light) !important;
		 }

		 .activecat-location path { fill: var(--color-primary-p3-light) !important;}
		 



		 
		 .sub-ico1 {
			position: relative;
			-webkit-box-flex: 1;
			flex-grow: 1;
			display: -webkit-box;
			display: flex;
			-webkit-box-align: center;
			align-items: center;
			height: 24px;
			width: 24px;
			color: #000;
			font-size: 24px;
		}


		.sub-ico2 {
			margin-top: 5px;
			color: #808d9a;
		}




		.contact-posit {
			position: relative;
			width: 100%;
			padding-right: 0;
			padding-left: 0;
			margin-top: 5px;
	   }
		.contact-posit2 {
			position: relative;
			width: 100%;
			padding-right: 0;
			padding-left: 0;
			margin-top: 20px;
	   }
	



		.contact-static {
			position: relative;
			width: 100%;
			padding-right: 0;
			padding-left: 0;
	   }
		.contact-map {
			position: relative;
			width: 100%;
			padding-right: 0;
			padding-left: 0;
	   }
	



		body.overflow-hidden {
			overflow: hidden;
			height: 100%;
			padding-right: 16px;
		}


	.hero__btnContainer {
		padding-top: 5px;
	}

	.ifmvMZ, .nomobile, .cKSkd {
		display: none !important;
	}


	.dyfpCa {width: 50%;}

	.product-thumb .button-group a.add_to_cart {font-size: 11px;}

.link-category {    overflow-x: auto;
    overflow-y: hidden;
    width: 100%;
    margin: 0 auto;
    white-space: nowrap;
    justify-content: unset;
    height: 40px;
    padding-top: 5px;
    margin-top: 5px;
	text-align: center;}

	.link-category a {	color: var(--color-primary-p3-light);}



	.hr-tab {
		padding-bottom: 0 !important;
	}

	.hr-tab2 {
		padding-top: 0 !important;
	}


	.eblogList__card {
		height: 100%;
	}


	.eblogList__card-title {
		margin: 32% 0px;
	}



	.product-thumb {
		height: 100%;
		padding: 5px;
	}

	#content-cat .product-layout.product-layout-featured {
		width: 49.4%;
	}



	.product-thumb h4 {
		font-size: 12px;
	}


	.jwNNnX {
		width: 100%;
		padding-right: 0;
	}

	.cXXhTb {
		padding: 0;
		border: none;
	}

	.cXXhTb .owl-theme .custom-nav .owl-prev, .cXXhTb .owl-theme .custom-nav .owl-next {
		display: none !important;
	}

	.main-rinok .owl-thumb-item img {
		width: 60px;
		height: auto;
		margin: 5px;
	}

	.tabs .uliuliahuli {
		display: -webkit-flex;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		-ms-flex-pack: center;
		justify-content: center;
		-webkit-box-align: center;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-flex-flow: row wrap;
		-ms-flex-flow: row wrap;
		flex-flow: row wrap;
		margin-bottom: 10px;
	}


	.desc-full .product-layout {
		float: left;
		width: 140px;
		margin-right: 15px;
		margin-top: 5px;
	}


	.desc-full .product-layout .product-thumb {
		height: 140px;
		margin-bottom: 0px;
	}

	.dyfpCa {
		width: 100%;
	}

	.eUIgzn {
		display: none;
	}

	.sPFrk {
		display: none;
	}


	.owl-carousel .owl-item img {
		max-height: 220px !important;
	}




	.sc-qQkqj h1 {
		font-size: 20px;
		line-height: 25px !important;
		margin-bottom: 10px;
	}

	.product-thumb .image a img {
		height: 130px;
	}

	.product-thumb .image a {
		height: 130px;
	}

	.buttons-row>div {
		height: auto;
	}


	.cat-brands .product-thumb {
		height: 150px;
		padding: 10px;
	}

	.dFgovI {
		font-weight: 600;
		line-height: 55px;
		font-size: 18px;
		color: var(--color-primary-p3-dark);
	}

	.more-link {
		margin-top: 10px;
		align-items: center;
		font-size: 14px;
		color: var(--color-primary-p3);
		margin-left: 5px;
	}

	#content-info .product-thumb .image {
		margin-top: 15px;
	}


	#content-info .product-thumb {
		height: 170px;
	}

	.cat-desc h2 {
		font-size: 14px;
		line-height: 20px;
	}

	.cat-desc h3 {
		font-size: 14px;
		line-height: 20px;
	}

	.cat-desc p {
		font-size: 11px;
	}

	.hHGKwK .dyfpCa {width: 50%;}

	.headroom {display: block;}


	.hcatroom {min-height: 48px;}

	.eNsSPe {
		position: fixed;
		z-index: 10;
		top: 0px;
		left: 0px;
		right: 0px;
		padding: 0px 16px;
		background: rgb(255, 255, 255);
		box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
		transition: transform 0.2s ease-in-out 0s;
	}


	.headroom .scrolledf.out {
		transform: translateY(-100%);
		
	}


	.hBspgl {
		display: flex;
		-webkit-box-pack: justify;
		justify-content: space-between;
		-webkit-box-align: stretch;
		align-items: stretch;
		height: 100%;
		min-height: 48px;
	}
	
	

	.iVtAtO {
		display: flex;
		-webkit-box-align: center;
		align-items: center;
		-webkit-box-pack: start;
		justify-content: flex-start;
		flex: 0 0 auto;
		width: 15%;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	
	.eeyqGF {
		display: flex;
		-webkit-box-pack: center;
		justify-content: center;
		-webkit-box-align: center;
		align-items: center;
		text-align: center;
		flex: 1 1 0%;
		overflow-x: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}

	.header__logo {
		width: 145px;
	}

	
	.iEsZvo {
		position: relative;
		display: inline-block;
		vertical-align: middle;
		margin: 0px;
		padding: 0px;
		font-family: inherit;
		text-decoration: none;
		text-align: center;
		line-height: normal;
		white-space: nowrap;
		border: 0px;
		outline: 0px;
		cursor: pointer;
		overflow: hidden;
		transition: all 0.2s ease 0s;
		border-radius: 4px;
		color: rgb(57, 57, 57);
		background-color: transparent;
		box-shadow: none;
	}
	.iVtAtO > * {
		display: inline-block;
		vertical-align: middle;
		max-width: 100%;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}


	.iVtAtO .sc-jgHCyG > span {
		padding-right: 24px;
		padding-left: 8px;
	}

	.iEsZvo .sc-cOajty {
		display: block;
		padding: 9px 16px;
		font-size: 0px;
		font-weight: 400;
	}


	.jAnegm {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}



.iEsZvo .sc-AzgDb {
    position: relative;
    display: inline-block;
    vertical-align: middle;
    height: calc(24px);
    font-size: calc(24px);
    line-height: calc(24px);
    opacity: 1;
    margin: -2px -8px;
}

.iEsZvo {
    position: relative;
    display: inline-block;
    vertical-align: middle;
    margin: 0px;
    padding: 0px;
    font-family: inherit;
    text-decoration: none;
    text-align: center;
    line-height: normal;
    white-space: nowrap;
    border: 0px;
    outline: 0px;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.2s ease 0s;
    border-radius: 4px;
    color: rgb(57, 57, 57);
    background-color: transparent;
    box-shadow: none;
}

.iEsZvo i {
    color: rgb(57, 57, 57) !important;
}



.bhdLno {
    speak: none;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    -webkit-font-smoothing: antialiased;
}


.iEsZvo .sc-AzgDb::before {
    display: block;
}

.iBDRGY::before {
    font-family: icon-main;
    content: "";
}

.bhdLno::before {
    font-size: inherit;
    line-height: inherit;
}


.eeyqGF > * {
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    height: 100%;
    max-width: 100%;
    overflow-x: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}


.fDSWsf {
    transform: translateY(0px);
}


.ipwmPt {
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: end;
    justify-content: flex-end;
    flex: 0 0 auto;
    width: 15%;
    white-space: nowrap;
    text-overflow: ellipsis;
}


.ipwmPt > * {
    display: inline-block;
    vertical-align: middle;
    max-width: 100%;
    white-space: nowrap;
    text-overflow: ellipsis;
}


.gHFzAI {
    font-size: 0px;
}


.bORbIW {
    border: none;
    margin: 0px;
    padding: 0px;
    outline: none;
    overflow: visible;
    cursor: pointer;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    background: transparent;
    color: inherit;
    font: inherit;
    text-align: center;
    -webkit-font-smoothing: inherit;
    display: flex;
    -webkit-box-pack: end;
    justify-content: flex-end;
    -webkit-box-align: center;
    align-items: center;
    width: 40px;
    height: 38px;
}


.dLQGEk {
    position: absolute;
    padding-bottom: 24px;
    width: 100%;
    visibility: visible;
    opacity: 1;
    transform: translate3d(0px, 0px, 0px);
    overflow: hidden;
    transition: opacity 0.2s linear 0s, transform 0.2s linear, visibility 0s linear;
}


.daPpPm {
    position: relative;
    z-index: -1;
    padding: 16px 0px 24px;
    background: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px;
}



.bpQQda {
    left: 8px;
}

.bpQQda {
    position: absolute;
    top: 4px;
    pointer-events: none;
    left: 4px;
}




.dBDcDn .sc-Fyfyc {
    padding-left: 40px;
}



.bkYTbJ .sc-Fyfyc {
    width: 100%;
    padding: 5px 32px 7px;
    background: rgb(255, 255, 255);
    color: rgb(51, 51, 51);
    display: inline-block;
    vertical-align: middle;
    zoom: 1;
    font: inherit;
    margin: 0px;
    overflow: visible;
    transition: border-color 0.2s ease 0s;
    height: 32px;
    border-radius: 8px;
    border: none;
}


.cRZSjA .sc-Fyfyc {
    padding-top: 0px;
    padding-bottom: 0px;
    background-color: rgb(245, 245, 245);
}

.dBDcDn .sc-Fyfyc {
    border: 1px solid rgb(235, 235, 235);
}


.bkYTbJ {
    width: 100%;
    position: relative;
    font-size: 14px;
}


.cRZSjA {
    padding: 8px 0px;
}


.bpQQda {
    position: absolute;
    top: 4px;
    pointer-events: none;
    left: 4px;
}



.dBDcDn .sc-Fyfyc:focus
{
	
outline: 0;
outline-offset: 0;
border: 1px solid  #4caf50;
}


@font-face {
	font-family: 'icon-main';
	src: url(/templates/lifesport/fonts/icon-main.eot);
	src: url(/templates/lifesport/fonts/icon-main.eot?#iefix) format('eot'),
	  url(/templates/lifesport/fonts/icon-main.woff) format('woff'),
	  url(/templates/lifesport/fonts/icon-main.ttf) format('truetype'),
	  url(/templates/lifesport/fonts/icon-main.svg#icon-main) format('svg');
	font-weight: normal;
	font-style: normal;
	font-display: swap;
  }



  .jZapKD {
    display: none;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    -webkit-tap-highlight-color: transparent;
}

.ddGCXK {
    display: block;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 999;
    -webkit-tap-highlight-color: transparent;
	font-family: "Cutest", sans-serif;
}





.lg-hide-menu {
    display: none;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    -webkit-tap-highlight-color: transparent;
}

.lg-true-menu {
    display: block;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 999;
    -webkit-tap-highlight-color: transparent;
	font-family: "Cutest", sans-serif;
    margin-top: 50px;
}






.ct-hide-menu {
    display: none;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    -webkit-tap-highlight-color: transparent;
}

.ct-true-menu {
    display: block;
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 999;
    -webkit-tap-highlight-color: transparent;
	font-family: "Cutest", sans-serif;
    margin-top: 50px;
}




.ioplIy::before {
    font-family: icon-main;
    content: "";
}


.sticky-container {
    position: fixed;
    bottom: 0;
    width: 100%;
    z-index: 550;
	display: block;
}





.ks_dinamic_count {
    color: #fff;
    background: var(--color-primary-p3);
    width: 17px;
    height: 17px;
    padding-top: 0px;
    text-align: center;
    border-radius: 50px;
    position: absolute;
    top: -5px;
    right: 10px;
    font-size: 12px;
    font-weight: bold;

}


.fxpIX {
    padding-top: 0px;
    padding-bottom: 0px;
    margin-bottom: 50px;
}
.bBzwtQ {
    position: relative;
    width: 100%;
    min-height: calc(100vh - 48px);
    height: calc(100vh - 48px);
    overflow: auto scroll;
    padding-bottom: 130px;
    background-color: rgb(255, 255, 255);
}


.bBzwtQ > * + ::after {
    content: "";
    position: absolute;
    top: 0px;
    left: 12px;
    right: 12px;
    height: 1px;
    background-color: rgb(245, 245, 245);
}

.hhxtfx {
    min-height: 48px;
    padding-top: 4px;
    padding-left: 16px;
    padding-bottom: 4px;
    cursor: default;
}

.hhxtfx:hover {
    background-color: rgba(112, 146, 254, 0.04);
}

.gOWskc {
    position: relative;
    cursor: pointer;
    display: flex;
    align-items: flex-start;
    min-height: 52px;
    padding: 12px 8px 12px 12px;
}

.kJYLAl {
    position: absolute;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    width: 100%;
    height: 100%;
    top: 0px;
    left: 0px;
    padding-top: 4px;
    padding-left: 16px;
    cursor: default;
    color: rgb(51, 51, 51);
}


.HFbtI {
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.jwDgIA {
    display: block;
    line-height: 24px;
    font-weight: 400;
    font-size: 14px;
}

.icon-catlist {
    flex-shrink: 0;
    margin-right: 8px;
    width: 24px;
    height: 24px;
    font-size: 18px;
}

.fkwbXo {
    position: absolute;
    right: 0px;
    margin-right: 16px;
    align-self: center;
}


.cm_menn {
    padding: 0 20px;
    max-height: 100%;
    padding-top: 20px;
    position: relative;
    width: 100%;
    min-height: calc(100vh - 48px);
    height: calc(100vh - 48px);
    overflow: auto scroll;
    padding-bottom: 130px;
    background-color: rgb(255, 255, 255);
}

.cm_phones {
    padding: 20px;
    background: #fff;
    box-shadow: 0px 0px 10px rgb(0 0 0 / 4%);
    border-radius: 6px;
    margin-bottom: 10px;
}

.cm-content-title {
    font-weight: 500;
    font-size: 18px;
    line-height: 22px;
    margin-bottom: 20px;
}

.cm-content-title-a {
    font-weight: 500;
    font-size: 13px;
    line-height: 22px;
    margin-bottom: 20px;
}



.cm_mobile_menu_phones-item svg {
    display: inline-block;
    width: 15px;
    height: 15px;
    margin-right: 4px;
}

.cm_mobile_menu_phones-item {
    font-size: 16px;
    line-height: 20px;
    text-decoration: underline;
    color: #0a78bf;
    margin-top: 5px;
}


.cm_phones li {
    line-height: 17px;
    color: #777;
    margin-bottom: 10px;
}

.UnJMN {
    display: inline-block;
    margin: 0;
    padding: 0;
}
.fjwdNm {
    width: auto;
}



.eKBirH {
	margin-top: 115px;
}



.eTBBht {
    margin-top: -30px;
    display: flex;
    flex-flow: row nowrap;
    -webkit-box-pack: center;
    justify-content: center;
    z-index: 8;
}


.eTBBht .headroom--unpinned {
    transform: translateY(100%);
}




.eTBBht .headroom {
    position: fixed;
    bottom: 0px;
    width: 100%;
    transition: transform 200ms ease-in-out 0s;
	z-index: 9;
}



.hLsUmn {
    border: none;
    margin: 0px;
    width: auto;
    outline: none;
    overflow: visible;
    appearance: none;
    -webkit-tap-highlight-color: transparent;
    font: inherit;
    text-align: center;
    -webkit-font-smoothing: inherit;
    height: 40px;
    padding: 8px 20px;
    border-radius: 8px;
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    background: var(--color-primary-p3);
    color: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
	z-index: 999;
}


.ceQeTi {
    line-height: 24px;
    font-weight: 400;
    font-size: 16px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-height: 24px;
}


.eTBBht .scrolledf.out {
	transform: translateY(100%);
}


.eTdbQ {
    width: auto;
    height: 40px;
    margin-bottom: 8px;
    transform: translateX(-50%);
    box-shadow: rgb(0 0 0 / 8%) 0px 8px 16px 0px;
}

.gnHLLb {
    padding-bottom: 0px !important;
}



.iIeIkWm {
    color: var(--color-primary-p3-dark);
	position: relative;
}


.iIeIkWm:hover {
	color: var(--color-primary-p3);
}


.related-news {    
	margin-top: 20px;
    border-top: solid 2px #f5f5f5;
    padding-top: 15px;
}


#promo_code {
    width: 65% !important;
}


.cart-item__counter {
    position: relative;
    max-width: 0 !important;
    width: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
}


.cart-item__price-value {
    font-size: 13px !important;
    color: #32373e !important;
}

.cart-item__price {
    color: #7b8084;
    margin-bottom: 5px !important;
}

.cart-item__total {
    color: #32373e;
    font-size: 13px !important;
}


.counter {
    height: 22px !important;
}

.ks_take_count, .ks_add_count {
    height: 20px !important;
	line-height: 20px !important;
    font-size: 16px !important;
}


.ks_count_goods {
    height: 20px !important;
}



.cart-item__name {
    margin-bottom: 5px !important;
}


.eblogList__cards_cat .eblogList__card {
	width: 49%;
    height: 150px;
	margin-right: 7px;
}


.eblogList__cards_cat .eblogList__card:nth-child(5n) {
	margin-right: 7px;
}


.eblogList__cards_cat .eblogList__card:nth-child(2n) {
	margin-right: 0px;
}


.filtr-rinok-table td {
	display: inline-block;
}


.filtr-rinok-table .value {display: flex;}

}


@media screen and (max-width: 1100px) {

	.wrapper {
		max-width: 980px;
		min-width: 320px;
		width: 100%;
	}

	.XqbgT {
		max-width: 980px;
		min-width: 320px;
		width: 100%;
	}

	.catlist-a {
		width: 19.78%;
	}

	.product-thumb .button-group a.add_to_cart {
		font-size: 12px;
	}

	.ibDbuL {
		margin-top: 100px;
	}




	.buttons-row>div {
		height: 42px;
	}


}


.ebxpdw a {
    display: -ms-flexbox !important;
    display: -webkit-flex !important;
    display: flex !important;
}

.searchajleft {margin-right: 5px;}

.searchajleft img {
	width: 70px !important;
    height: 70px !important;
}


.blognews {margin-top: 30px;}


#userinfo {

	box-sizing: border-box;
    margin: 0px;
    margin-top: 25px;
    padding: 24px 16px 40px;
    border-radius: 8px;
    background-color: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
    line-height: 24px;
}




.ui-form .wide, .form-group .form-control {
    padding: 4px 10px;
    background: #f9f9fb;
    color: rgb(51, 51, 51);
    display: inline-block;
    vertical-align: middle;
    zoom: 1;
    font: inherit;
    margin: 0px;
    overflow: visible;
    transition: border-color 0.2s ease 0s;
    height: 32px;
    border: 1px solid #dfdfdf;
    border-radius: 8px;
}


.ui-form  .timezoneselect {    padding: 4px 10px;
    background: #f9f9fb;
    color: rgb(51, 51, 51);
    display: inline-block;
    vertical-align: middle;
    zoom: 1;
    font: inherit;
    margin: 0px;
    overflow: visible;
    transition: border-color 0.2s ease 0s;
    height: 32px;
    border: 1px solid #dfdfdf;
    border-radius: 8px;}


	.bbcodes {    border: none;
		margin: 0px;
		width: auto;
		outline: none;
		overflow: visible;
		appearance: none;
		-webkit-tap-highlight-color: transparent;
		font: inherit;
		text-align: center;
		-webkit-font-smoothing: inherit;
		height: 32px;
		padding: 4px 16px;
		border-radius: 8px;
		position: relative;
		display: inline-flex;
		-webkit-box-align: center;
		align-items: center;
		-webkit-box-pack: center;
		justify-content: center;
		cursor: pointer;
		transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
		border-radius: 8px;
		color: #fff;
		background-color: var(--color-primary-p3);}


		.bbcodes:hover {
			background: var(--color-primary-p3-dark);
			color: #fff;
		}





		.maincategories .icon5 {
		   --fa-primary-color: rgb(0 0 0);
           --fa-secondary-color: #0078ac;
           --fa-secondary-opacity: 1.0;
		}

		.maincategories .icon5 {
			--fa-primary-color: rgb(0 0 0);
			--fa-secondary-color: #0078ac;
			--fa-secondary-opacity: 1.0;
		 }


	
	   


/*
  Menu dropdown
 */


 #advice_list {    
    border-radius: 8px;
    background-color: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
}

.menu a,.menu li{
  display:block;width:100%
  }
  .menu{background:#fafafa;border-radius:2px;box-shadow:0 2px 4px 0 rgba(0,0,0,.16),0 2px 8px 0 rgba(0,0,0,.12);color:#757575;
    padding: 0;width: 100%;
    right: 0 !important;
    position: absolute;
    top: 23px !important;transform:scale(0);transition:transform .2s;z-index:96;
  overflow: hidden;}
    .menu li.menu-separator:hover,.menu li:hover{background:#eee}.menu.show{transform:scale(1)}
    .menu.menu--right{transform-origin:top right}.menu.menu--left{transform-origin:top left}
    .menu li{min-height:32px !important;line-height:16px !important;margin:4px 0 !important;padding:0 16px !important}
    .menu li.menu-separator{background:#eee;height:1px;min-height:0;margin:12px 0;padding:0}
    .menu li:first-child{margin-top:0}.menu li:last-child{margin-bottom:0}
    .menu a{color:inherit;height:32px;line-height:32px !important;padding:0 !important;text-decoration:none;white-space:nowrap;
      display: block;
    }
    .menu a:hover{color:#444}


.aleft, .aright {
    display: inline
}
.aleft {
    float: left
}
.aright {
    float: right
}
#advice {
    padding: 15px
}

#advice .page-header {
    padding-bottom: 9px;
    margin: 20px 0;
    overflow: hidden;
    border-bottom: 1px solid #eee
}
#advice .page-header .h1 {
    padding: 15px 0 10px;
    font-size: 24px
}
#advice button, .advice-form button {
    height: 32px;
    transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
    position: relative;
    display: inline-block;
    vertical-align: middle;
    margin: 5px;
    padding: 8px;
    font-size: 13px;
    text-decoration: none;
    text-align: center;
    line-height: normal;
    white-space: nowrap;
    border: 0px;
    outline: 0px;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.2s ease 0s;
    border-radius: 4px;
    color: rgb(255 255 255);
    background-color: #4caf50;
    box-shadow: none;
}
#advice button:hover, .advice-form button:hover {
    text-decoration: none;
    background: #363a3c;
}
#advice button:focus, .advice-form button:focus {
    background: #363a3c;
    border-color: #363a3c;
    color: #fff;
}
.advice {
    overflow: hidden;
    position: relative;
    margin: 9px 0
}
.advice_aside {
    width: 85px;
    overflow: hidden;
    padding-right: 15px
}
.advice_aside a {
    display: block;
    background: #D6E8F1;
    color: #549CAC;
    padding: 3px 5px 4px;
    text-align: center;
    margin: 0 0 3px;
    border-radius: 2px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px
}
.advice_aside a:hover {
    text-decoration: none;
    color: #fff;
    background: #549CAC
}
.advice_section {
    overflow: hidden !important;
    -moz-border-radius: 2px;
    position: relative;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    padding: 15px;
    border: 1px solid #efe9e9;
    width: 100%;
}
.advice.advice-danger .advice_section {
    border-color: #C24E41
}
.advice.advice-danger .advice_section::after {
    border: 1px solid #C24E41;
    padding: 15px 0;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    content: 'Негативный';
    color: #C24E41;
    position: absolute;
    top: 40px;
    left: 80px;
    padding: 3px 10px;
    text-shadow: 1px 1px 0 rgba(255, 255, 255, 1);
    font-weight: 700;
    text-align: center
}
.advice.advice-success .advice_section {
    border-color: #6DA157
}
.advice.advice-success .advice_section::after {
    border: 1px solid #6DA157;
    padding: 15px 0;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    content: 'Позитивный';
    color: #6DA157;
    position: absolute;
    top: 40px;
    left: 80px;
    padding: 3px 10px;
    text-shadow: 1px 1px 0 rgba(255, 255, 255, 1);
    font-weight: 700;
    text-align: center
}
.advice.advice-default .advice_section::after {
    border: 1px solid #595C61;
    padding: 15px 0;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    content: 'Нейтральный';
    color: #595C61;
    position: absolute;
    top: 40px;
    left: 80px;
    padding: 3px 10px;
    text-shadow: 1px 1px 0 rgba(255, 255, 255, 1);
    font-weight: 700;
    text-align: center
}
.advice_header {
    overflow: hidden;
    position: relative;
    width: 100%;
    display: inline-block;
    vertical-align: top;
}
.advice_header sup, .advice_header sub {
    display: block
}
.advice_header sup {
    margin-bottom: 12px
}
.advice_body {
    overflow: hidden;
    font-size: 14px;
    color: #5b5b5b;
    word-break: normal;
    width: 100%;
    position: relative;
    display: inline-block;
}
.advice_foto {
    width: 50px;
    height: 50px;
    border-radius: 2px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    margin: 0 15px 0 0
}
.advice_name {
    color: #758797;
    font-size: 18px
}
.advice_name a {
    color: #758797
}
.advice_date {
    color: #AAAAAB;
    padding: 0 10px;
    font-size: 14px
}
.advice_header .aright {
    text-align: right
}
.advice_catq a, .advice_full {
    border-radius: 2px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    padding: 2px 5px 3px;
    border: 1px solid #7B9D04;
    text-align: center;
    font-size: 12px;
    color: #7B9D04
}
.advice_catq a:hover, .advice_full:hover {
    text-decoration: none;
    background: #E3ECF5
}
.advice_full {
    display: inline-block;
    margin-right: 15px
}
.advice_web a {
    background: #E3ECF5;
    display: inline-block;
    border-radius: 2px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    padding: 2px 5px 3px;
    border: 1px solid #C6D1DC;
    text-align: center;
    font-size: 12px;
    color: #54575C
}
.advice_web a:hover {
    text-decoration: none;
    background: #549CAC;
    color: #fff;
    border-color: transparent
}
.advice_answer {
    border-top: 1px solid #E8F2F7;
    padding: 0 15px 15px;
    background: rgba(227, 236, 245, 0.5);
    position: relative;
    border-left: 35px solid rgba(0, 0, 0, 0.3)
}
.advice_answer_h {
    margin: 0 -15px 15px;
    padding: 10px 15px;
    border-top: 2px solid #C6D1DC;
    border-bottom: 1px solid #C6D1DC
}
.advice_answer_t {
    display: block;
    position: absolute;
    left: 0;
    bottom: 0;
    top: 0;
    line-height: 13px;
    color: #fff;
    -moz-transform: rotate(-90deg);
    -webkit-transform: rotate(-90deg);
    -o-transform: rotate(-90deg);
    writing-mode: lr-tb;
    font-size: 16px
}
.advice_stars {
    color: #758797;
    font-size: 16px
}
.advice_navi {
    padding-left: 0;
    margin: 20px 0;
    list-style: none;
    text-align: center;
    font-size: 14px
}
.advice_navi li {
    display: inline
}
.advice_navi li > a, .advice_navi li > span {
    display: inline-block;
    padding: 5px 14px 6px;
    background-color: #fff;
    border-radius: 2px;
    border-bottom: 1px solid #C6D1DC
}
.advice_navi li > a:hover, .advice_navi li > a:focus {
    text-decoration: none;
    background-color: #eee
}
.advice_navi .next > a, .advice_navi .next > span {
    background-color: #D6E8F1;
    color: #549CAC;
    float: right
}
.advice_navi .active span {
    border-color: #7B9D04;
    color: #7B9D04
}
.advice_navi .next > a:hover, .advice_navi .next > a:focus {
    background: #549CAC;
    color: #fff
}
.advice_navi .previous > a, .advice_navi .previous > span {
    float: left
}
.advice_navi .disabled > a, .advice_navi .disabled > a:hover, .advice_navi .disabled > a:focus, .advice_navi .disabled > span {
    color: #777;
    background-color: #E7EEF5;
    cursor: not-allowed
}
.advice_cat {
    overflow: hidden;
    padding: 9px 0;
    margin: 0;
    list-style: none;
    text-align: center
}
.advice_cat > li {
    display: inline-block;
    margin: 0 5px
}
.advice_cat > li > a {
    display: block;
    padding: 3px 15px;
    border-radius: 2px;
    background: #F9FCFF;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5)
}
.advice_cat > li > a:hover {
    color: #fff;
    text-decoration: none;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
    background-color: #7B9D04
}
.advice_cat > li > a.active, .advice_cat > li > a.active:hover {
    color: #fff;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
    background-color: #08c
}
.radio_stars {
    float: left
}
.radio_star {
    display: inline-block;
    width: 26px;
    height: 26px;
    margin: 0 3px 0 0;
    vertical-align: -6px;
    background: url(/templates/lifesport/advice/assets/star.png) no-repeat
}
.radio_star.empty {
    display: inline-block;
    margin: 0 3px 0 0;
    vertical-align: -6px;
    background: url(/templates/lifesport/advice/assets/star.png) 0 -26px no-repeat
}
.radio_stars_text {
    border-radius: 2px;
    display: inline-block;
    font-size: 16px;
    padding: 6px 10px;
    color: #7B9D04;
    border: 1px solid #7B9D04;
    margin-left: 10px
}
.advice_inf {
    padding: 10px 15px;
    background-color: #f3f3f3;
    vertical-align: middle;
    overflow: hidden;
    border-radius: 8px;
}
.advice_sort span {
    display: block;
    float: left;
    padding: 6px 10px
}
.advice_sort div {
    position: relative;
    display: inline-block
}
.advice_sort select {
    display: inline-block;
    border: 1px solid #C6D1DC;
    padding: 6px 3px 7px 5px;
    margin: 0;
    height: auto;
    font: inherit;
    outline: none;
    line-height: 1.2;
    background: #f8f8f8;
    -webkit-appearance: none;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px
}
@media screen and (-webkit-min-device-pixel-ratio:0) {
    .advice_sort select {
        padding-right: 30px
    }
}
.advice_sort select:focus {
    -webkit-box-shadow: 0 0 3px 1px #c00;
    -moz-box-shadow: 0 0 3px 1px #c00;
    box-shadow: 0 0 3px 1px #c00
}
.advice_sort div:after {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    font-size: 60%;
    line-height: 30px;
    padding: 0 12px;
    background: #435056 url(/templates/lifesport/advice/assets/adv_arr.png) no-repeat center center;
    color: #fff;
    pointer-events: none;
    -webkit-border-radius: 0 2px 2px 0;
    -moz-border-radius: 0 2px 2px 0;
    border-radius: 0 2px 2px 0
}
.no-pointer-events .advice_sort div:after {
    content: none
}
#advice_add #addaform {
    background: #EDF5FD;
    border-radius: 6px;
    -webkit-border-radius: 6px;
    -moz-border-radius: 6px;
    padding: 10px;
    margin: 0
}
#advice_add input {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box
}
#advice_add fieldset {
    padding: 0;
    margin: 0;
    border: 0;
    min-width: 0
}
#advice_add legend {
    display: block;
    width: 100%;
    padding: 0;
    margin-bottom: 20px;
    font-size: 21px;
    line-height: inherit;
    color: #333;
    border: 0;
    border-bottom: 1px solid #e5e5e5
}
#advice_add label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700
}
#advice_add input[type="checkbox"] {
    margin: 4px 0 0;
    margin-top: 1px \9;
    line-height: normal
}
#advice_add input[type="file"] {
    display: block
}
#advice_add input[type="file"]:focus, #advice_add input[type="checkbox"]:focus {
    outline: thin dotted;
    outline: 5px auto -webkit-focus-ring-color;
    outline-offset: -2px
}
#advice_add output {
    display: block;
    padding-top: 7px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555
}
#advice_add .af-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    -webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s
}
#advice_add .af-control:focus {
    border-color: #66afe9;
    outline: 0;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 8px rgba(102, 175, 233, 0.6);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 8px rgba(102, 175, 233, 0.6)
}
#advice_add .af-control::-moz-placeholder {
    color: #777;
    opacity: 1
}
#advice_add .af-control:-ms-input-placeholder {
    color: #777
}
#advice_add .af-control::-webkit-input-placeholder {
    color: #777
}
#advice_add textarea.af-control {
    height: auto
}
#advice_add .advice-form {
    margin: 10px 0;
    overflow: hidden
}
#advice_add .a_checkbox {
    position: relative;
    display: block;
    min-height: 20px;
    margin-top: 10px;
    margin-bottom: 10px
}
#advice_add .a_checkbox label {
    padding-left: 20px;
    margin-bottom: 0;
    font-weight: 400;
    cursor: pointer
}
#advice_add .a_checkbox input[type="checkbox"] {
    position: absolute;
    margin-left: -20px;
    margin-top: 4px \9
}
#advice_add .a_checkbox + #advice_add .a_checkbox {
    margin-top: -5px
}
#advice_add .a_checkbox-inline {
    display: inline-block;
    padding-left: 20px;
    margin-bottom: 0;
    vertical-align: middle;
    font-weight: 400;
    cursor: pointer
}
#advice_add .a_checkbox-inline + #advice_add .a_checkbox-inline {
    margin-top: 0;
    margin-left: 10px
}
.advice_errors {
    background: #FEF6F3;
    border-radius: 3px;
    padding: 10px;
    margin: 10px 0
}
.a_label {
    display: inline-block;
    padding: 3px 5px 2px;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: 2px
}
.a_label:empty {
    display: none
}
.a_label-default {
    background-color: #777
}
.a_label-primary {
    background-color: #428bca
}
.a_label-success {
    background-color: #5cb85c
}
.a_label-info {
    background-color: #5bc0de
}
.a_label-warning {
    background-color: #f0ad4e
}
.a_label-danger {
    background-color: #d9534f
}
.advice_stat {
    border: 1px solid #C6D1DC;
    border-radius: 2px
}
.advice_stat div {
    padding: 2px 5px;
    border-bottom: 1px solid #C6D1DC
}
.advice_stat div:last-child {
    border: none
}
.advice_stat .aright {
    margin-left: 5px
}
.advice_block {
    overflow: hidden;
    position: relative;
    padding: 5px 5px 5px 50px;
    margin: 10px 0;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05)
}
.advice_block .avatar {
    float: left;
    width: 40px;
    height: 40px;
    margin: 0 5px 0 -45px;
    border-radius: 3px;
    text-align: center
}
.advice_block .avatar img {
    position: relative;
    width: 40px;
    height: 40px;
    border-radius: 4px
}
.advice_block .advice_num {
    margin: 5px 0;
    float: left;
    background: rgba(119, 119, 119, 1);
    color: #fff;
    border-radius: 3px;
    font-size: 11px;
    padding: 0 5px;
    height: 14px;
    line-height: 14px
}
.advice_block .advice_btext {
    overflow: hidden;
    background: #f5f5f5;
    border-radius: 3px;
    padding: 10px
}
.advice_block.advice-success .advice_btext {
    background: #DFF0D8
}
.advice_block.advice-danger .advice_btext {
    background: #FEF6F3
}
.advice_btext_h {
    margin-bottom: .5em
}
.advice_btext_h span {
    display: inline-block;
    font-size: 14px;
    font-weight: 700;
    line-height: normal;
    padding: 0
}
.advice_meta {
    float: right;
    font-size: 12px;
    cursor: default;
    color: #aaa
}
.advice_block_answ {
    background: rgba(217, 83, 79, 0.5);
    border-radius: 3px;
    padding: 2px 5px;
    position: absolute;
    right: 5px;
    font-size: 11px;
    color: #fff;
    bottom: 5px
}
.advice_padd {
    padding: 0 20px
}
.advice_padd h1 {
    font-size: 18px;
    color: #428BCA;
    margin: 0
}
.advice_info {
    text-align: center;
    padding: 10px
}
.close {
    float: right;
    font-size: 21px;
    font-weight: 700;
    line-height: 1;
    color: #000;
    text-shadow: 0 1px 0 #fff;
    opacity: .2;
    filter: alpha(opacity=20)
}
.close:hover, .close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
    opacity: .5;
    filter: alpha(opacity=50)
}
button.close {
    padding: 0;
    cursor: pointer;
    background: transparent;
    border: 0;
    -webkit-appearance: none
}
.modal-open {
    overflow: hidden
}
.modal {
    display: none;
    overflow: hidden;
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 950;
    -webkit-overflow-scrolling: touch;
    outline: 0
}
.modal.fade .modal-dialog {
    -webkit-transform: translate(0, -25%);
    -ms-transform: translate(0, -25%);
    -o-transform: translate(0, -25%);
    transform: translate(0, -25%);
    -webkit-transition: -webkit-transform .3s ease-out;
    -o-transition: -o-transform .3s ease-out;
    transition: transform .3s ease-out
}
.modal.in .modal-dialog {
    -webkit-transform: translate(0, 0);
    -ms-transform: translate(0, 0);
    -o-transform: translate(0, 0);
    transform: translate(0, 0)
}
.modal-open .modal {
    overflow-x: hidden;
    overflow-y: auto
}
.modal-dialog {
    position: relative;
    width: auto;
    margin: 10px
}
.modal-content {
    position: relative;
    background-color: #fff;
    border: 1px solid #999;
    border: 1px solid rgba(0, 0, 0, 0.2);
    border-radius: 6px;
    -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
    box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    outline: 0
}
.modal-backdrop {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 940;
    background-color: #000
}
.modal-backdrop.fade {
    opacity: 0;
    filter: alpha(opacity=0)
}
.modal-backdrop.in {
    opacity: .5;
    filter: alpha(opacity=50)
}
.modal-header {
    padding: 15px;
    border-bottom: 1px solid #e5e5e5;
    min-height: 16.42857143px
}
.modal-header .close {
    margin-top: -2px
}
.modal-title {
    margin: 0;
    line-height: 1.42857143
}
.modal-body {
    position: relative;
    padding: 15px
}
.modal-footer {
    padding: 15px;
    text-align: right;
    border-top: 1px solid #e5e5e5
}
.modal-footer .btn + .btn {
    margin-left: 5px;
    margin-bottom: 0
}
.modal-footer .btn-group .btn + .btn {
    margin-left: -1px
}
.modal-footer .btn-block + .btn-block {
    margin-left: 0
}
.modal-scrollbar-measure {
    position: absolute;
    top: -9999px;
    width: 50px;
    height: 50px;
    overflow: scroll
}
@media (min-width:768px) {
    .modal-dialog {
        width: 600px;
        margin: 30px auto
    }
    .modal-content {
        -webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5)
    }
    .modal-sm {
        width: 300px
    }
}
@media (min-width:992px) {
    .modal-lg {
        width: 900px
    }
}
.alert {
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px
}
.alert h4 {
    margin-top: 0;
    color: inherit
}
.alert .alert-link {
    font-weight: 700
}
.alert > p, .alert > ul {
    margin-bottom: 0
}
.alert > p + p {
    margin-top: 5px
}
.alert-dismissable, .alert-dismissible {
    padding-right: 35px
}
.alert-dismissable .close, .alert-dismissible .close {
    position: relative;
    top: -2px;
    right: -21px;
    color: inherit
}
.alert-success {
    background-color: #dff0d8;
    border-color: #d6e9c6;
    color: #3c763d
}
.alert-success hr {
    border-top-color: #c9e2b3
}
.alert-success .alert-link {
    color: #2b542c
}
.alert-info {
    background-color: #d9edf7;
    border-color: #bce8f1;
    color: #31708f
}
.alert-info hr {
    border-top-color: #a6e1ec
}
.alert-info .alert-link {
    color: #245269
}
.alert-warning {
    background-color: #fcf8e3;
    border-color: #faebcc;
    color: #8a6d3b
}
.alert-warning hr {
    border-top-color: #f7e1b5
}
.alert-warning .alert-link {
    color: #66512c
}
.alert-danger {
    background-color: #f2dede;
    border-color: #ebccd1;
    color: #a94442
}
.alert-danger hr {
    border-top-color: #e4b9c0
}
.alert-danger .alert-link {
    color: #843534
}
@-webkit-keyframes progress-bar-stripes {
    from {
        background-position: 40px 0
    }
    to {
        background-position: 0 0
    }
}
@-o-keyframes progress-bar-stripes {
    from {
        background-position: 40px 0
    }
    to {
        background-position: 0 0
    }
}
@keyframes progress-bar-stripes {
    from {
        background-position: 40px 0
    }
    to {
        background-position: 0 0
    }
}
.progress {
    overflow: hidden;
    height: 20px;
    margin-bottom: 20px;
    background-color: #f5f5f5;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1)
}
.progress-bar {
    float: left;
    width: 0;
    height: 100%;
    font-size: 12px;
    line-height: 20px;
    color: #fff;
    text-align: center;
    background-color: #337ab7;
    -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    -webkit-transition: width .6s ease;
    -o-transition: width .6s ease;
    transition: width .6s ease
}
.progress-striped .progress-bar, .progress-bar-striped {
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    -webkit-background-size: 40px 40px;
    background-size: 40px 40px
}
.progress.active .progress-bar, .progress-bar.active {
    -webkit-animation: progress-bar-stripes 2s linear infinite;
    -o-animation: progress-bar-stripes 2s linear infinite;
    animation: progress-bar-stripes 2s linear infinite
}
.progress-bar-success {
    background-color: #5cb85c
}
.progress-striped .progress-bar-success {
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent)
}
.progress-bar-info {
    background-color: #5bc0de
}
.progress-striped .progress-bar-info {
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent)
}
.progress-bar-warning {
    background-color: #f0ad4e
}
.progress-striped .progress-bar-warning {
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent)
}
.progress-bar-danger {
    background-color: #d9534f
}
.progress-striped .progress-bar-danger {
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent)
}
.advice_photo {
    overflow: hidden
}
.advice_photo_preview {
    width: 100px;
    overflow: hidden;
    float: left;
    padding: 0 10px 0 0;
    margin: 0 10px 0 0
}
.advice_photo_preview img {
    width: 100px;
    padding: 4px;
    line-height: 1.42857143;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    -webkit-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
    display: inline-block;
    height: auto
}
.advice_photo_upload {
    overflow: hidden !important
}
.advice_photo_upload button {
    margin: 10px 0 0;
    display: block;
    width: 100%;
    border-radius: 2px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    padding: 6px 10px 7px;
    border: 1px solid #EEA236;
    text-align: center;
    font-size: 12px;
    color: #fff;
    cursor: pointer;
    background: #F0AD4E
}
.advice_photo_upload button:hover {
    text-decoration: none;
    background: #F4971F
}
.advice_box {
    margin: 10px;
    padding: 9px;
    border-radius: 3px;
    border: 1px solid #e3e3e3;
    background-image: -webkit-linear-gradient(top, #e8e8e8 0%, #f5f5f5 100%);
    background-image: -o-linear-gradient(top, #e8e8e8 0%, #f5f5f5 100%);
    background-image: -webkit-gradient(linear, left top, left bottom, from(#e8e8e8), to(#f5f5f5));
    background-image: linear-gradient(to bottom, #e8e8e8 0%, #f5f5f5 100%);
    background-repeat: repeat-x;
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffe8e8e8', endColorstr='#fff5f5f5', GradientType=0);
    border-color: #dcdcdc;
    -webkit-box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 0 rgba(255, 255, 255, 0.1);
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 0 rgba(255, 255, 255, 0.1)
}
.advice_box:first-child {
    margin-top: 3px
}
.advice_box > h4 {
    text-transform: uppercase;
    padding: 5px 5px 10px;
    border-bottom: 1px solid #DCDCDC;
    margin: 0 0 10px
}
.advice_box_c {
    overflow: hidden
}
.advice_topuser {
    overflow: hidden;
    position: relative;
    padding: 5px;
    margin: 10px 0;
    border: 1px solid #799EDC;
    background: #fff;
    border-radius: 3px
}
.advice_topuser:nth-child(1) {
    border-color: #FF6E39
}
.advice_topuser:nth-child(2) {
    border-color: #FFB300
}
.advice_topuser:nth-child(3) {
    border-color: #8EDA00
}
.advice_tu_num {
    position: absolute;
    left: 0;
    top: 0;
    z-index: 2;
    color: #fff;
    font-weight: 700;
    font-size: 14px;
    vertical-align: middle;
    font-family: Tahoma, sans-serif;
    padding: 3px 5px;
    border-radius: 0 6px 6px 6px;
    background: rgba(0, 0, 0, 0.2)
}
.advice_topuser:nth-child(1) .advice_tu_num {
    background: #FF6E39
}
.advice_topuser:nth-child(2) .advice_tu_num {
    background: #FFB300
}
.advice_topuser:nth-child(3) .advice_tu_num {
    background: #8EDA00
}
.advice_tu_avatar {
    float: left;
    width: 50px;
    height: 50px;
    margin: 0 5px 0 0;
    border-radius: 3px;
    text-align: center
}
.advice_tu_avatar img {
    position: relative;
    width: 50px;
    height: 50px;
    border-radius: 4px
}
.advice_tu_text {
    overflow: hidden
}
.advice_tu_text > span {
    font-size: 14px;
    font-weight: 700;
    display: block
}
.advice_tu_text > span em {
    font-weight: 400;
    font-size: 12px;
    color: #606060
}
.advice_tu_t_m {
    margin: 8px 0 0;
    background: #f5f5f5;
    border-radius: 3px;
    overflow: hidden;
    padding: 5px
}
.advice_tu_sort {
    right: 0;
    top: 0;
    background: rgba(0, 0, 0, 0.1) url(/templates/lifesport/advice/assets/list.png) no-repeat center center;
    width: 24px;
    height: 24px;
    padding: 5px;
    border-radius: 3px;
    text-indent: -9999px;
    border: none;
    outline: none;
    cursor: pointer;
    position: absolute
}
.advice_tu_sort:hover {
    opacity: .8
}
.advice_dropdown {
    position: relative
}
.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 160px;
    padding: 5px 0;
    margin: 2px 0 0;
    list-style: none;
    font-size: 14px;
    text-align: left;
    background-color: #fff;
    border: 1px solid #ccc;
    border: 1px solid rgba(0, 0, 0, 0.15);
    border-radius: 4px;
    -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
    -webkit-background-clip: padding-box;
    background-clip: padding-box
}
.dropdown-menu > li > a {
    display: block;
    padding: 3px 20px;
    clear: both;
    font-weight: 400;
    line-height: 1.42857143;
    color: #333;
    white-space: nowrap
}
.dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
    text-decoration: none;
    color: #262626;
    background-color: #f5f5f5
}
.dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
    color: #fff;
    text-decoration: none;
    outline: 0;
    background-color: #337ab7
}
.dropdown-menu > .disabled > a, .dropdown-menu > .disabled > a:hover, .dropdown-menu > .disabled > a:focus {
    color: #777
}
.dropdown-menu > .disabled > a:hover, .dropdown-menu > .disabled > a:focus {
    text-decoration: none;
    background-color: transparent;
    background-image: none;
    filter: progid:DXImageTransform.Microsoft.gradient(enabled = false);
    cursor: not-allowed
}
.open > .dropdown-menu {
    display: block
}
.open > a {
    outline: 0
}
.advice_dropdown > .dropdown-menu {
    right: 0;
    left: auto
}

.advice_utility {
    float: right;
    margin: 3px 0 3px 0
}
.advice_utility_title {
    float: left;
    color: #808080;
    margin: 1px 4px 0 0;
    font-size: 11px
}
.advice_utility_btn {
    display: block;
    float: left;
    margin: 0 2px 0 0;
    padding: 0 4px 2px 4px;
    border: 1px solid;
    border-radius: 3px;
    font-size: 11px;
    text-decoration: none;
    position: relative;
}
.advice_utility_up_text_count {
    text-align: center
}
.advice_utility_btn:hover::after {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: block;
    color: #006837;
    text-align: center;
}
.advice_utility_btn.up:hover::after {
    background: #bae8c2;
    content: "+1";
}
.advice_utility_btn.down:hover::after {
    background: #e8baba;
    content: "-1";
}
.advice_utility_btn.up .advice_utility_text, .advice_utility_btn.down .advice_utility_text {
    margin: 0 3px 0 0
}
.advice_utility_btn .advice_utility_text {
    color: #808080
}
.advice_utility_btn.up .advice_utility_text_count {
    color: #29b54a
}
.advice_utility_btn.down .advice_utility_text_count {
    color: #f00
}
.advice_utility_btn.down:hover {
    border: 1px solid #e8baba;
}
.advice_utility_btn.up:hover {
    border: 1px solid #bae8c2;
}
.advice_utility_btn.active .advice_utility_text_count {
    font-weight: bold
}
.advice_utility_btn.up.active {
    background-color: #bae8c2;
    border-color: #bae8c2;
    cursor: text;
    text-decoration: none;
}
.advice_utility_btn.down.active {
    background-color: #e8baba;
    border-color: #e8baba;
    cursor: text;
    text-decoration: none;
}
.advice_utility_btn.active:hover::after, .advice_utility_cont.active .advice_utility_btn:hover::after {
    display: none;
}
.advice_utility_cont.active .advice_utility_btn:hover {
    border-color: #ccc;
    cursor: text;
    text-decoration: none;
}
.advice_utility_cont.active .advice_utility_btn {
    pointer-events: none
}



.progress-pie-chart {
    border-radius: 50%;
    background-color: #E5E5E5;
    position: relative;
}
.ppc-progress {
    content: "";
    position: absolute;
    border-radius: 50%;
}
.ppc-progress .ppc-progress-fill {
    content: "";
    position: absolute;
    border-radius: 50%;
    background: #81CE97;
    transform: rotate(60deg);
}

.ppc-percents {
    content: "";
    position: absolute;
    border-radius: 50%;
    background: #fff;
    text-align: center;
    display: table;
}
.ppc-percents span {
    display: block;
    font-size: 2.6em;
    font-weight: bold;
    color: #81CE97;
}

.pcc-percents-wrapper {
    display: table-cell;
    vertical-align: top;
    background-repeat: no-repeat;
    border-radius: 50%;
    background-size: 100%;
}
.pcc-percents-wrapper span {
    background-color: #EE7449;
    padding: 2px 5px;
    display: inline-block;
    color: #fff;
    font-size: 13px;
    border-radius: 4px;
    margin-top: 10px;
}
.progress-pie-chart {
  margin: 0 auto;
}

.advice_comm_add {
  -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    background: #f7f4ed;
    padding: 20px;
    font-size: 12px;
    margin: 30px 0;
    position: relative;
}
.advice_comm_add::before {
    content: '';
    position: absolute;
    border-style: solid;
    top: -8px;
    left: 45px;
    border-width: 0 8px 8px 8px;
    border-color: transparent transparent #f7f4ed transparent;
}
.com_head {
    color: #560029;
    font-size: 22px;
    font-weight: normal;
    margin: 15px 0;
}
.advice_comm {
  overflow: hidden;
  margin: 5px 0;
  padding: 10px 0 15px 0;
  border-bottom: 1px dotted #560029;
}
.advice_comm:last-child {
  border: none;
  padding-bottom: 0px;
}
.advice_comm a {
    color: #560029;
    text-decoration: underline;
}
.advice_comm a:hover {
  text-decoration: none;
}
.advice_comm_h {
  overflow: hidden;
  color: #707070;
  font-size: 11px;
}
.advice_comm_h .rsider a {
  margin: 0 10px;
}
.advice_comm_h .group_back {
  background: #FF8F00;
  font-size: 9px;
  color: #fff;
  position: relative;
  padding: 2px 5px 3px 10px;
}
.advice_comm_h .group_back::before, .advice_comm_h .group_back::after {
  position: absolute;
  content: '';
  top: 0;
  border-style: solid;
  border-width: 8px 0 8px 5px;
}
.advice_comm_h .group_back::before {
  border-color: transparent transparent transparent #fff;
  left: 0;
}
.advice_comm_h .group_back::after {
  border-color: transparent transparent transparent #FF8F00;
  right: -5px;
}
.advice_comm_c {
  overflow: hidden;
  padding: 5px 10px;
  color: #333333;
}
.comment_answer {
  margin: 5px 10px;
}
.comment_numb {
  display: inline-block;
  border: 1px solid #882d4f;
  color: #882d4f;
  padding: 0px 2px;
  line-height: 12px;
}
.advice_post_title {
  overflow: hidden;
  margin: 0 0 10px 0;
}
.advice_add_c {
    overflow: hidden;
    padding: 15px 0;
}
.advice_add_c .lsidel {
    overflow: hidden !important;
}
.advice_add_c .rsider {
    padding: 0 0 0 15px;
    width: 200px;
    overflow: hidden;
}
.advice_add_btn {
    background: #f2f2f2;
    margin: 15px 0;
    padding: 15px 20px;
}

.advice_add_btn button {
  -webkit-border-radius: 4;
  -moz-border-radius: 4;
  border-radius: 4px;
  color: #ffffff;
  font-size: 20px;
  background: #3498db;
  padding: 10px 20px 10px 20px;
  text-decoration: none;
  border: none;
  outline: none;
  cursor: pointer;
}
.rev_rat_name {
    text-decoration: none;
    color: #000;
    font-size: 12px;
    margin: 10px 0 5px 0;
    display: block;
}
.advice_add_btn button:hover {
  background: #3cb0fd;
  text-decoration: none;
}
.advice_user_ava {
    margin-left: 2px;
    margin-right: 5px;
    overflow: hidden;
    width: 30px;
    height: 30px;
    float: left;
}
.advice_user_ava img {
    width: 28px;
    height: 28px;
    border: 1px solid #bebfb8;
}
.text_area_comm {
  width: 100%;
}
.advice_input {
    overflow: hidden !important;
}
.advice_input input, .reviews_input textarea {
    width: 97% !important;
    border: 1px solid #918f90;
    padding: 5px 5px;
}
.advice_input input:focus, .advice_input textarea:focus {
    border-color: rgba(190, 191, 183, 0.8);
    outline: 0;
    outline: thin dotted \9;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(190, 191, 183, 0.6);
    -moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(190, 191, 183, 0.6);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(190, 191, 183, 0.6);
}
.advice_inf {
    font-size: 12px;
    color: #636363;
    display: block;
    margin: 5px 0 15px 0;
}

.advice_utility {
    float: right;
    margin: 3px 0 3px 0
}
.advice_utility_title {
    float: left;
    color: #808080;
    margin: 1px 4px 0 0;
    font-size: 11px
}
.advice_utility_btn {
    display: block;
    float: left;
    margin: 0 2px 0 0;
    padding: 0 4px 2px 4px;
    border: 1px solid;
    border-radius: 3px;
    font-size: 11px;
    text-decoration: none;
    position: relative;
}
.advice_utility_up_text_count {
    text-align: center
}
.advice_utility_btn:hover::after {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: block;
    color: #006837;
    text-align: center;
}
.advice_utility_btn.up:hover::after {
    background: #bae8c2;
    content: "+1";
}
.advice_utility_btn.down:hover::after {
    background: #e8baba;
    content: "-1";
}
.advice_utility_btn.up .advice_utility_text, .advice_utility_btn.down .advice_utility_text {
    margin: 0 3px 0 0
}
.advice_utility_btn .advice_utility_text {
    color: #808080
}
.advice_utility_btn.up .advice_utility_text_count {
    color: #29b54a
}
.advice_utility_btn.down .advice_utility_text_count {
    color: #f00
}
.advice_utility_btn.down:hover {
    border: 1px solid #e8baba;
}
.advice_utility_btn.up:hover {
    border: 1px solid #bae8c2;
}
.advice_utility_btn.active .advice_utility_text_count {
    font-weight: bold
}
.advice_utility_btn.up.active {
    background-color: #bae8c2;
    border-color: #bae8c2;
    cursor: text;
    text-decoration: none;
}
.advice_utility_btn.down.active {
    background-color: #e8baba;
    border-color: #e8baba;
    cursor: text;
    text-decoration: none;
}
.advice_utility_btn.active:hover::after, .advice_utility_cont.active .advice_utility_btn:hover::after {
    display: none;
}
.advice_utility_cont.active .advice_utility_btn:hover {
    border-color: #ccc;
    cursor: text;
    text-decoration: none;
}
.advice_utility_cont.active .advice_utility_btn {
    pointer-events: none
}


/*----------------------------
    The file upload form
-----------------------------*/
.photo_up #drop{
  border: 1px dashed #CCCCCC;
  background: rgba(255,255,224,0.2);
  padding: 30px 25px;
  text-align: center;
  text-transform: uppercase;
  font-size:16px;
  font-weight:bold;
  color:#7f858a;
}
.photo_up #drop a {
    background-color:#007a96;
    padding:12px 26px;
    color:#fff;
    font-size:14px;
    cursor:pointer;
    display:inline-block;
    margin-top:12px;
    line-height:1;
}
.photo_up #drop a:hover{
    background-color:#0986a3;
}
.photo_up #drop input{
    display:none;
}
.photo_up ul {
  margin: 0;
  list-style:none;
}
.photo_up ul li{
    background-color:#333639;
    background-image:-webkit-linear-gradient(top, #333639, #303335);
    background-image:-moz-linear-gradient(top, #333639, #303335);
    background-image:linear-gradient(top, #333639, #303335);
    border-top:1px solid #3d4043;
    border-bottom:1px solid #2b2e31;
    padding:15px;
    height: 52px;
    position: relative;
}

.photo_up ul li input{
    display: none;
}

.photo_up ul li p{
    width: 144px;
    overflow: hidden;
    white-space: nowrap;
    color: #EEE;
    font-size: 16px;
    font-weight: bold;
    position: absolute;
    top: 20px;
    left: 100px;
}

.photo_up ul li i{
    font-weight: normal;
    font-style:normal;
    color:#7f7f7f;
    display:block;
}

.photo_up ul li canvas{
    top: 15px;
    left: 32px;
    position: absolute;
}

.photo_up ul li span{
    width: 15px;
    height: 12px;
    background: url('/templates/lifesport/advice/assets/icons.png') no-repeat;
    position: absolute;
    top: 34px;
    right: 33px;
    cursor:pointer;
}

.photo_up ul li.working span{
    height: 16px;
    background-position: 0 -12px;
}

.photo_up ul li.error p{
    color:red;
}


@-webkit-keyframes passing-through {
  0% {
    opacity: 0;
    -webkit-transform: translateY(40px);
    -moz-transform: translateY(40px);
    -ms-transform: translateY(40px);
    -o-transform: translateY(40px);
    transform: translateY(40px);
  }
  30%, 70% {
    opacity: 1;
    -webkit-transform: translateY(0px);
    -moz-transform: translateY(0px);
    -ms-transform: translateY(0px);
    -o-transform: translateY(0px);
    transform: translateY(0px);
  }
  100% {
    opacity: 0;
    -webkit-transform: translateY(-40px);
    -moz-transform: translateY(-40px);
    -ms-transform: translateY(-40px);
    -o-transform: translateY(-40px);
    transform: translateY(-40px);
  }
}
@-moz-keyframes passing-through {
  0% {
    opacity: 0;
    -webkit-transform: translateY(40px);
    -moz-transform: translateY(40px);
    -ms-transform: translateY(40px);
    -o-transform: translateY(40px);
    transform: translateY(40px);
  }
  30%, 70% {
    opacity: 1;
    -webkit-transform: translateY(0px);
    -moz-transform: translateY(0px);
    -ms-transform: translateY(0px);
    -o-transform: translateY(0px);
    transform: translateY(0px);
  }
  100% {
    opacity: 0;
    -webkit-transform: translateY(-40px);
    -moz-transform: translateY(-40px);
    -ms-transform: translateY(-40px);
    -o-transform: translateY(-40px);
    transform: translateY(-40px);
  }
}
@keyframes passing-through {
  0% {
    opacity: 0;
    -webkit-transform: translateY(40px);
    -moz-transform: translateY(40px);
    -ms-transform: translateY(40px);
    -o-transform: translateY(40px);
    transform: translateY(40px);
  }
  30%, 70% {
    opacity: 1;
    -webkit-transform: translateY(0px);
    -moz-transform: translateY(0px);
    -ms-transform: translateY(0px);
    -o-transform: translateY(0px);
    transform: translateY(0px);
  }
  100% {
    opacity: 0;
    -webkit-transform: translateY(-40px);
    -moz-transform: translateY(-40px);
    -ms-transform: translateY(-40px);
    -o-transform: translateY(-40px);
    transform: translateY(-40px);
  }
}
@-webkit-keyframes slide-in {
  0% {
    opacity: 0;
    -webkit-transform: translateY(40px);
    -moz-transform: translateY(40px);
    -ms-transform: translateY(40px);
    -o-transform: translateY(40px);
    transform: translateY(40px);
  }
  30% {
    opacity: 1;
    -webkit-transform: translateY(0px);
    -moz-transform: translateY(0px);
    -ms-transform: translateY(0px);
    -o-transform: translateY(0px);
    transform: translateY(0px);
  }
}
@-moz-keyframes slide-in {
  0% {
    opacity: 0;
    -webkit-transform: translateY(40px);
    -moz-transform: translateY(40px);
    -ms-transform: translateY(40px);
    -o-transform: translateY(40px);
    transform: translateY(40px);
  }
  30% {
    opacity: 1;
    -webkit-transform: translateY(0px);
    -moz-transform: translateY(0px);
    -ms-transform: translateY(0px);
    -o-transform: translateY(0px);
    transform: translateY(0px);
  }
}
@keyframes slide-in {
  0% {
    opacity: 0;
    -webkit-transform: translateY(40px);
    -moz-transform: translateY(40px);
    -ms-transform: translateY(40px);
    -o-transform: translateY(40px);
    transform: translateY(40px);
  }
  30% {
    opacity: 1;
    -webkit-transform: translateY(0px);
    -moz-transform: translateY(0px);
    -ms-transform: translateY(0px);
    -o-transform: translateY(0px);
    transform: translateY(0px);
  }
}
@-webkit-keyframes pulse {
  0% {
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -ms-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
  }
  10% {
    -webkit-transform: scale(1.1);
    -moz-transform: scale(1.1);
    -ms-transform: scale(1.1);
    -o-transform: scale(1.1);
    transform: scale(1.1);
  }
  20% {
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -ms-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
  }
}
@-moz-keyframes pulse {
  0% {
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -ms-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
  }
  10% {
    -webkit-transform: scale(1.1);
    -moz-transform: scale(1.1);
    -ms-transform: scale(1.1);
    -o-transform: scale(1.1);
    transform: scale(1.1);
  }
  20% {
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -ms-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
  }
}
@keyframes pulse {
  0% {
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -ms-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
  }
  10% {
    -webkit-transform: scale(1.1);
    -moz-transform: scale(1.1);
    -ms-transform: scale(1.1);
    -o-transform: scale(1.1);
    transform: scale(1.1);
  }
  20% {
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -ms-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
  }
}
.dropzone, .dropzone * {
  box-sizing: border-box;
}
.dropzone {
  min-height: 150px;
  border: 1px dashed rgba(0, 0, 0, 0.3);
  background: #ebebeb;
  padding: 10px 15px;
  font-size: 18px;
  line-height: 24px;
}
.dropzone.dz-clickable {
  cursor: pointer;
}
.dropzone.dz-clickable * {
  cursor: default;
}
.dropzone.dz-clickable .dz-message, .dropzone.dz-clickable .dz-message * {
  cursor: pointer;
}
.dropzone.dz-started .dz-message {
  display: none;
}
.dropzone.dz-drag-hover {
  border-style: solid;
}
.dropzone.dz-drag-hover .dz-message {
  opacity: 0.5;
}
.dropzone .dz-message {
  text-align: center;
  margin: 2em 0;
}
.dropzone .dz-preview {
  position: relative;
  display: inline-block;
  vertical-align: top;
  margin: 16px;
  min-height: 100px;
}
.dropzone .dz-preview:hover {
  z-index: 1000;
}
.dropzone .dz-preview:hover .dz-details {
  opacity: 1;
}
.dropzone .dz-preview.dz-file-preview .dz-image {
  border-radius: 6px;
  background: #999;
}
.dropzone .dz-preview.dz-file-preview .dz-details {
  opacity: 1;
}
.dropzone .dz-preview.dz-image-preview {
  background: white;
  border-radius: 6px;
}
.dropzone .dz-preview.dz-image-preview .dz-details {
  -webkit-transition: opacity 0.2s linear;
  -moz-transition: opacity 0.2s linear;
  -ms-transition: opacity 0.2s linear;
  -o-transition: opacity 0.2s linear;
  transition: opacity 0.2s linear;
}
.dropzone .dz-preview .dz-remove {
  font-size: 14px;
  text-align: center;
  display: block;
  cursor: pointer;
  border: none;
}
.dropzone .dz-preview .dz-remove:hover {
  text-decoration: underline;
}
.dropzone .dz-preview:hover .dz-details {
  opacity: 1;
}
.dropzone .dz-preview .dz-details {
  z-index: 20;
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0;
  font-size: 13px;
  min-width: 100%;
  max-width: 100%;
  padding: 2em 1em;
  text-align: center;
  color: rgba(0, 0, 0, 0.9);
  line-height: 150%;
}
.dropzone .dz-preview .dz-details .dz-size {
  margin-bottom: 1em;
  font-size: 16px;
}
.dropzone .dz-preview .dz-details .dz-filename {
  white-space: nowrap;
}
.dropzone .dz-preview .dz-details .dz-filename:hover span {
  border: 1px solid rgba(200, 200, 200, 0.8);
  background-color: rgba(255, 255, 255, 0.8);
}
.dropzone .dz-preview .dz-details .dz-filename:not(:hover) {
  overflow: hidden;
  text-overflow: ellipsis;
}
.dropzone .dz-preview .dz-details .dz-filename:not(:hover) span {
  border: 1px solid transparent;
}
.dropzone .dz-preview .dz-details .dz-filename span, .dropzone .dz-preview .dz-details .dz-size span {
  background-color: rgba(255, 255, 255, 0.4);
  padding: 0 0.4em;
  border-radius: 3px;
}
.dropzone .dz-preview:hover .dz-image img {
  -webkit-transform: scale(1.05, 1.05);
  -moz-transform: scale(1.05, 1.05);
  -ms-transform: scale(1.05, 1.05);
  -o-transform: scale(1.05, 1.05);
  transform: scale(1.05, 1.05);
  -webkit-filter: blur(8px);
  filter: blur(8px);
}
.dropzone .dz-preview .dz-image {
  border-radius: 6px;
  overflow: hidden;
  width: 100px;
  height: 120px;
  position: relative;
  display: block;
  z-index: 10;
}
.dropzone .dz-preview .dz-image img {
  display: block;
  border-radius: 6px;
}
.dropzone .dz-preview.dz-success .dz-success-mark {
  -webkit-animation: passing-through 3s cubic-bezier(0.77, 0, 0.175, 1);
  -moz-animation: passing-through 3s cubic-bezier(0.77, 0, 0.175, 1);
  -ms-animation: passing-through 3s cubic-bezier(0.77, 0, 0.175, 1);
  -o-animation: passing-through 3s cubic-bezier(0.77, 0, 0.175, 1);
  animation: passing-through 3s cubic-bezier(0.77, 0, 0.175, 1);
}
.dropzone .dz-preview.dz-error .dz-error-mark {
  opacity: 1;
  -webkit-animation: slide-in 3s cubic-bezier(0.77, 0, 0.175, 1);
  -moz-animation: slide-in 3s cubic-bezier(0.77, 0, 0.175, 1);
  -ms-animation: slide-in 3s cubic-bezier(0.77, 0, 0.175, 1);
  -o-animation: slide-in 3s cubic-bezier(0.77, 0, 0.175, 1);
  animation: slide-in 3s cubic-bezier(0.77, 0, 0.175, 1);
}
.dropzone .dz-preview .dz-success-mark, .dropzone .dz-preview .dz-error-mark {
  pointer-events: none;
  opacity: 0;
  z-index: 500;
  position: absolute;
  display: block;
  top: 50%;
  left: 50%;
  margin-left: -27px;
  margin-top: -27px;
}
.dropzone .dz-preview .dz-success-mark svg, .dropzone .dz-preview .dz-error-mark svg {
  display: block;
  width: 54px;
  height: 54px;
}
.dropzone .dz-preview.dz-processing .dz-progress {
  opacity: 1;
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  -ms-transition: all 0.2s linear;
  -o-transition: all 0.2s linear;
  transition: all 0.2s linear;
}
.dropzone .dz-preview.dz-complete .dz-progress {
  opacity: 0;
  -webkit-transition: opacity 0.4s ease-in;
  -moz-transition: opacity 0.4s ease-in;
  -ms-transition: opacity 0.4s ease-in;
  -o-transition: opacity 0.4s ease-in;
  transition: opacity 0.4s ease-in;
}
.dropzone .dz-preview:not(.dz-processing) .dz-progress {
  -webkit-animation: pulse 6s ease infinite;
  -moz-animation: pulse 6s ease infinite;
  -ms-animation: pulse 6s ease infinite;
  -o-animation: pulse 6s ease infinite;
  animation: pulse 6s ease infinite;
}
.dropzone .dz-preview .dz-progress {
  opacity: 1;
  z-index: 1000;
  pointer-events: none;
  position: absolute;
  height: 16px;
  left: 50%;
  top: 50%;
  margin-top: -8px;
  width: 80px;
  margin-left: -40px;
  background: rgba(255, 255, 255, 0.9);
  -webkit-transform: scale(1);
  border-radius: 8px;
  overflow: hidden;
}
.dropzone .dz-preview .dz-progress .dz-upload {
  background: #333;
  background: linear-gradient(to bottom, #666, #444);
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  width: 0;
  -webkit-transition: width 300ms ease-in-out;
  -moz-transition: width 300ms ease-in-out;
  -ms-transition: width 300ms ease-in-out;
  -o-transition: width 300ms ease-in-out;
  transition: width 300ms ease-in-out;
}
.dropzone .dz-preview.dz-error .dz-error-message {
  display: block;
}
.dropzone .dz-preview.dz-error:hover .dz-error-message {
  opacity: 1;
  pointer-events: auto;
}
.dropzone .dz-preview .dz-error-message {
  pointer-events: none;
  z-index: 1000;
  position: absolute;
  display: block;
  display: none;
  opacity: 0;
  -webkit-transition: opacity 0.3s ease;
  -moz-transition: opacity 0.3s ease;
  -ms-transition: opacity 0.3s ease;
  -o-transition: opacity 0.3s ease;
  transition: opacity 0.3s ease;
  border-radius: 8px;
  font-size: 13px;
  top: 130px;
  left: -10px;
  width: 140px;
  background: #be2626;
  background: linear-gradient(to bottom, #be2626, #a92222);
  padding: 0.5em 1.2em;
  color: white;
}
.dropzone .dz-preview .dz-error-message:after {
  content: '';
  position: absolute;
  top: -6px;
  left: 64px;
  width: 0;
  height: 0;
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-bottom: 6px solid #be2626;
}

.fr_images {
  padding: 9px;
  background-color: #f5f5f5;
  border: 1px solid #e3e3e3;
  border-radius: 3px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
  box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
  margin: 10px 10px 10px 0;
}
.fr_images > * {
    padding: 4px;
  line-height: 1.42857143;
  background-color: #ffffff;
  border: 1px solid #dddddd;
  border-radius: 4px;
  -webkit-transition: all 0.2s ease-in-out;
  -o-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
  display: inline-block;
  max-width: 100%;
  height: 70px;
  margin: 0 0 5px 0;
  vertical-align: top;
}
.fr_images img {
  width: 100px;
  display: block;
  height: 70px;
}
#fr_img_edit {
padding: 9px;
  background-color: #f5f5f5;
  border: 1px solid #e3e3e3;
  border-radius: 3px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
  box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
  margin: 10px;
}
#fr_img_edit > * {
  padding: 4px;
  line-height: 1.42857143;
  background-color: #ffffff;
  border: 1px solid #dddddd;
  border-radius: 4px;
  -webkit-transition: all 0.2s ease-in-out;
  -o-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
  display: inline-block;
  max-width: 100%;
  height: 70px;
  margin: 3px;
  vertical-align: top;
  overflow: hidden;
  position: relative;
}
#fr_img_edit a {
  display: block;
  position: absolute;
  top: 4px;
  left: 4px;
  right: 4px;
  background: rgba(0,0,0,0.4);
  color: #fff;
  text-align: center;
  text-decoration: none;
}
#fr_img_edit a:hover {
  background: rgba(255,255,255,0.8);
  color: #CC0000;
}
#fr_img_edit img {
  width: 100px;
  display: block;
  height: 70px;
}
.prev_img {
    background: #ccc;
    padding: 2px;
    border-radius: 5px;
    vertical-align: top;
    margin: 5px;
    overflow: hidden;
    display: inline-block;
}
.prev_img:hover {
    background: #2E81B7;
}
.prev_img img {
    width: 80px;
}


.main-top.lne i {
	width: 20px;
}

.lne li {
	padding-bottom: 3px;
	border-bottom: 1px dashed #222431;
	padding-top: 5px;
}

button.owl-prev {
	border-radius: 0px 4px 4px 0px;
}

button.owl-next {
	border-radius: 4px 0px 0px 4px;
}

.no-img img {
	display: none;
	color: #eee;
	font-family: arial;
}


.main-content {
	position: relative;
}


.main-rinok {
	position: relative;
	background: #fff;
}

.hr-tab {
	padding-top: 15px;
	padding-bottom: 15px;
	border-top: 1px solid #f1f1f1;
}


.hr-tab2 {
	padding-top: 15px;
	padding-bottom: 15px;
	border-bottom: 1px solid #f1f1f1;
}



.dop>a {
    width: 49%;
    display: inline-block;
    margin-bottom: 25px;
    color: #000000;
    font-weight: 500;
    font-size: 32px;
}

.dop table {
    font-size: 32px;
    vertical-align: middle;
    display: unset;
}



.dop b {
	font-size: 32px;
	vertical-align: middle;
}


.dop span {
	margin-left: 21px;
	font-size: 16px;
}


.main-rinok .owl-theme .custom-nav {
	position: absolute;
	top: 40%;
	left: 0;
	right: 0;
}


.main-content .owl-theme .custom-nav {
	position: absolute;
	top: 40%;
	bottom: 0px;
	left: -15px;
	right: -15px;
	display: flex;
	-webkit-box-pack: justify;
	justify-content: space-between;
}


.disabled {
	opacity: 0.5;
}

.ttle {
	color: #fff;
	font-size: 1.4rem;
}

.ttle span {
	text-shadow: none;
}

.mfp-with-zoom .mfp-container,
.mfp-with-zoom.mfp-bg {
	opacity: 0;
	-webkit-backface-visibility: hidden;
	-webkit-transition: all 0.3s ease-out;
	-moz-transition: all 0.3s ease-out;
	-o-transition: all 0.3s ease-out;
	transition: all 0.3s ease-out;
}

.card-hd {
	background: #181a26;
	padding: 1.25rem 1.25rem 0px 1.25rem;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
}

.opis {
	background: #282b40;
	border-radius: 4px;
	padding: 1.25rem;
}

hr.st {
	border: 0;
	height: 1px;
	background-image: -webkit-linear-gradient(left, #363950, #43a593, #363950);
	background-image: -moz-linear-gradient(left, #363950, #43a593, #363950);
	background-image: -ms-linear-gradient(left, #363950, #43a593, #363950);
	background-image: -o-linear-gradient(left, #363950, #43a593, #363950);
}

.price-tag {
	display: inline-block;
	height: 40px;
	line-height: 40px;
	padding: 0px 15px;
	color: #ffffff;
	background-color: #828ce0;
	text-shadow: 1px 1px 1px #6b75cb;
	font-weight: bold;
	font-size: 1.1em;
	position: relative;
	border-radius: 4px;
}

.price-tag::after {
	content: "";
	position: absolute;
	top: 10%;
	left: 91%;
	width: 5px;
	height: 5px;
	border-radius: 2.5px;
	background-color: #181a26;
}

.mfp-with-zoom.mfp-ready .mfp-container {
	opacity: 1;
}

.mfp-with-zoom.mfp-ready.mfp-bg {
	opacity: 0.8;
}

.mfp-with-zoom.mfp-removing .mfp-container,
.mfp-with-zoom.mfp-removing.mfp-bg {
	opacity: 0;
}





.owl-theme .custom-nav .owl-prev,
.owl-theme .custom-nav .owl-next {
	position: absolute;
	z-index: 1;
	pointer-events: visible;
	padding: 0px;
	border: none;
	width: 32px;
	height: 32px;
	outline: none;
	cursor: pointer;
	background: center center no-repeat rgb(255, 255, 255);
	border-radius: 8px;
	box-shadow: rgba(0, 0, 0, 0.06) 0px 4px 8px 0px;
	transition-property: opacity, visibility;
	transition-duration: 0.1s;
	display: flex;
	-webkit-box-align: center;
	align-items: center;
	-webkit-box-pack: center;
	justify-top: center;
}

.owl-theme .custom-nav .owl-prev i,
.owl-theme .custom-nav .owl-next i {
	font-size: 1.2rem;
	color: #000;
	margin-left: 5px;
}

.owl-theme .custom-nav .owl-prev {
	left: 10px;
}

.owl-theme .custom-nav .owl-next {
	right: 10px;
}


.main-slide1, .main-slide2, .main-slide3, .main-slide4, .main-slide5, .main-slide6, .main-slide7, .main-slide8, .main-slide9, .main-slide10 {
	position: relative;
}


.main-slide1 .owl-theme .custom-nav, .main-slide2 .owl-theme .custom-nav, .main-slide3 .owl-theme .custom-nav, .main-slide4 .owl-theme .custom-nav, .main-slide5 .owl-theme .custom-nav, .main-slide6 .owl-theme .custom-nav, .main-slide7 .owl-theme .custom-nav, .main-slide8 .owl-theme .custom-nav, .main-slide9 .owl-theme .custom-nav, .main-slide10 .owl-theme .custom-nav {
	position: absolute;
	top: 40%;
	bottom: 0px;
	left: -15px;
	right: -15px;
	display: flex;
	-webkit-box-pack: justify;
	justify-content: space-between;
}

.owl-prev:focus {
	outline: 0;
}

.owl-next:focus {
	outline: 0;
}




.skrinshoty img {
	width: 100%;
	height: 250px;
	object-fit: cover;
	max-height: 280px;
	border-radius: 4px;
	border: 5px solid #373a4a;
	transition: 0.3s;
}

.skrinshoty img:hover {
	border: 5px solid #7c86d9;
	transition: 0.3s;
	opacity: 0.8;
}

.bg-grad {
	background: radial-gradient(farthest-corner at 30px 20px, #2f3240, #222430);
	border-bottom-left-radius: 4px;
	border-bottom-right-radius: 4px;
}

.iff a:hover {
	text-decoration: none;
}

ul.iff li {
	background: rgba(54, 57, 73, 0.4);
	margin-bottom: 5px;
	border-radius: 4px;
	padding: 10px 12px;
	color: #cecece;
	transition: 0.3s;
}

ul.iff li:last-child {
	margin-bottom: 0px;
}

ul.iff li span {
	color: #fff;
}

ul.iff li a {
	color: #fff;
}

ul.iff li a:hover {
	color: #eee;
	text-decoration: none;
}

ul.iff li i {
	color: rgba(130, 140, 224, 0.6);
	transition: 0.3s;
	vertical-align: middle;
}

ul.iff li:hover i {
	color: #fff;
	transition: 0.3s;
}

ul.iff li:hover {
	background: #828ce0;
	color: #fff;
	transition: 0.3s;
}

.cardl {
	background: rgba(54, 57, 73, 0.4);
	margin-bottom: 5px;
	border-radius: 4px;
	padding: 10px 12px;
	color: #cecece;
	transition: 0.3s;
}

.f2 {
	font-size: 2rem;
}

.addbody {
	background-color: #fff;
	overflow: hidden;
	padding: 30px;
	position: relative;
	border-left: 1px solid #ebedf2;
}

.addleft {
	width: 80px;
	position: absolute;
	top: 0;
	left: 0;
	bottom: 0;
}

.addcard {
	background-color: #fff;
	overflow: hidden;
	padding-left: 80px;
	position: relative;
	border-radius: 4px;
	-webkit-box-shadow: 0px 0px 13px 0px rgba(236, 236, 241, 0.44);
	box-shadow: 0px 0px 13px 0px rgba(236, 236, 241, 0.44);
}

.flog {
	font-family: 'Roboto Black';
	font-size: 40px;
	width: 100%;
	text-transform: uppercase;
	background: #36394f;
	display: table;
	color: white;
	border-radius: 5px;
	mix-blend-mode: multiply;
	padding: 5px 10px;
	text-align: center;
}

.ficn {
	width: 40px;
	height: 40px;
	text-align: center;
	font-size: 1.2rem;
	padding: 10px;
	background: #7d809c;
	color: #fff;
	border-radius: 4px;
}

.flst ul {
	list-style-type: circle;
}

.flst li {
	padding-top: 5px;
}

#footer {
	background-color:  var(--color-primary-p3-dark);
	padding: 1.3rem 2rem;
	clear: both;
	margin: 30px 0 0 0;
	font-size: 12px;
	position: relative;
	flex: 0 0 auto;
	width: 100%;
}

.sui li {
	border-bottom: 1px dashed #ebedf2;
}

.usrc {
	padding: 1rem 1.2rem;
	border: 1px solid #ebedf2;
	margin: 4px;
	border-radius: 0.25rem;
}

.usrc img {
	width: 80px;
	height: 80px;
	border-radius: 50%;
	object-fit: cover;
}

.sta li {
	margin-bottom: 15px;
	border-bottom: 1px dashed #d4d6e6;
}

.socb a {
	font-size: 1.1rem;
	width: 100%;
	display: block;
	text-align: center;
	color: #fff;
	height: 38px;
	background: #4a76a8;
	border-radius: 0.25rem;
	padding: 5px;
	transition: 0.3s;
}

.socb a:hover {
	background-color: #3d6898;
	text-decoration: none;
	transition: 0.3s;
	color: #fff;
}

.soct a {
	font-size: 1.1rem;
	width: 100%;
	display: block;
	text-align: center;
	color: #fff;
	height: 38px;
	background: #5682a3;
	border-radius: 0.25rem;
	padding: 5px;
	transition: 0.3s;
}

.soct a:hover {
	background-color: #456c8a;
	text-decoration: none;
	transition: 0.3s;
	color: #fff;
}

.socb img {
	width: 28px;
	height: 28px;
	border-radius: 50%;
	margin-right: 5px;
}

.isoc {

	font-size: 2rem !important;
	margin-bottom: 1.2rem;
}

ul.timeline {
	list-style-type: none;
	position: relative;
}

ul.timeline:before {
	content: ' ';
	background: #f5f2f8;
	display: inline-block;
	position: absolute;
	left: 29px;
	width: 2px;
	height: 100%;
	z-index: 400;
}

ul.timeline>li {
	margin: 20px 0;
	padding-left: 20px;
}

ul.timeline>li:before {
	content: ' ';
	background: white;
	display: inline-block;
	position: absolute;
	border-radius: 50%;
	border: 2px solid #6b75cb;
	left: 20px;
	width: 20px;
	height: 20px;
	z-index: 400;
}

.lnk a {
	color: #6f7292;
	transition: 0.3s;
}

.lnk a:hover {
	color: #000;
	transition: 0.3s;
	text-decoration: none;
}

.usava img {
	width: 40px;
	height: 40px;
	object-fit: cover;
	border-radius: 50%;
}

.acom a {
	color: #000;
	transition: 0.3s;
}

.acom a:hover {
	color: #7b7b7b;
	transition: 0.3s;
	text-decoration: none;
}

.lik {
	opacity: 0.7;
	transition: 0.3s;
}

.lik:hover {
	opacity: 1;
	transition: 0.3s;
}

.lik i {
	font-size: 13px;
	font-weight: bold;
	color: #9092a7;
}

a.lik:hover i {
	font-size: 13px;
	font-weight: bold;
	color: #E9573F;
}

.hov {
	transition: 0.3s;
	border-top: 1px solid #ededea;
}

.hov:hover {
	transition: 0.3s;
	background: #e6e6e6;
}

.w-13 {
	padding: 15px !important;
	font-size: 17px;
	font-weight: 700;
	-webkit-border-radius: 5px 5px 0 0;
	-moz-border-radius: 5px 5px 0 0;
	-ms-border-radius: 5px 5px 0 0;
	-o-border-radius: 5px 5px 0 0;
	border-radius: 5px 5px 0 0;
	line-height: 17px;
}


.bgpath {
	background-image: repeating-linear-gradient(-45deg, rgba(82, 91, 171, 0.25), rgba(82, 91, 171, 0.25) 1px, transparent 1px, transparent 6px) !important;
	background-size: 8px 8px !important;
}

.nice-nav {
	width: 100%;
	height: 100%;
	transition: all 0.4s ease-in-out 0s;
}

.nice-nav.open {
	margin-left: -250px;
	display: block;
}

.nice-nav>.user-info {
	padding: 10px 15px;
	color: #fff;
	border-bottom: 1px solid #ddd;
	min-height: 41px;
}

.nice-nav .user-info .user-name,
.nice-nav .user-info img {
	float: left;
}

.nice-nav>.user-info>.user-name {
	padding: 0px 10px;
}

.user-info>.user-name h5 {
	text-transform: uppercase;
	font-size: 16px;
}

.user-info>.user-name span {
	font-size: 80%;
	color: #555;
	font-style: italic;
}

.catimg {
	width: 20px;
	height: 20px;
	object-fit: cover;
	margin-right: 5px;
	vertical-align: text-top;
}

.nice-nav li.child-menu span.toggle-right {
	text-align: right;
	float: right;
	display: inline-block;
	position: absolute;
	right: 0;
	padding: 15px;
	color: #000;
	top: 0;
	background: #f8f9fa;
	bottom: 0;
}

.nice-nav li.child-menu span.toggle-right:focus {
	background: #000 !important;
}

.nice-nav ul li a {
	padding: 12px;
	background: #ffffff;
	border-bottom: 1px solid #f5f5f9;
	display: block;
	color: #6b6e84;
	position: relative;
}

.nice-nav ul li a:hover {
	text-decoration: none;
	background: #f5f5f9;
	transition: 0.2s;
	color: #000;
}

.nice-nav ul li a:focus {
	text-decoration: none;
	background: #f5f5f9;
	transition: 0.2s;
	color: #000;
}

a.active1 {
	background: #eaeaf7 !important;
	border-color: #eaeaf7 !important;
}

.child-menu-ul img {
	display: none;
}

.nice-nav ul li:last-child a {
	border-bottom: 0px;
}

.nice-nav ul {
	margin: 0;
	list-style: none;
	padding: 0px;
}

.nice-nav ul li.child-menu ul {
	background: #aaa;
	display: none;
}

.nice-nav ul li.child-menu ul li a {
	background: #f8f9fa;
	padding: 10px 30px;
	font-size: 90%;
}

.row-flex,
.row-flex>div[class*='col-'] {
	display: -webkit-box;
	display: -moz-box;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	flex: 1 1 auto;
}

.row-flex-wrap {
	-webkit-flex-flow: row wrap;
	align-content: flex-start;
	flex: 0;
}

.row-flex>div[class*='col-'] {
	margin: -.2px;
}

.f09 {
	font-size: 0.9rem;
}

a.lcard {
	display: block;
	color: inherit;
	text-align: center;
	padding: 5px;
	border: 1px solid #ebedf2;
	-webkit-border-radius: .25rem;
	border-radius: .25rem;
	transition: 0.2s;
}

a.lcard:hover {
	display: block;
	color: inherit;
	text-align: center;
	-webkit-box-shadow: 0 0px 13px #d6dee4;
	box-shadow: 0 0px 13px #d6dee4;
	-webkit-border-radius: .25rem;
	border-radius: .25rem;
	transition: 0.2s;
}

.followed-user-entry {
	padding: 0px;
	margin: auto;
	background-color: #fff;
	border-radius: 4px 4px 4px 4px;
	border-color: #e1e8ed;
	border-width: 1px;
	border-style: solid;
	max-width: 420px;
	min-height: 280px;
}

.followed-user-top {
	height: 100px;
	background-color: #f8f8f8;
	border-radius: 4px 4px 0px 0px;

	overflow-y: hidden ! important;
	overflow-x: hidden ! important;
	background-color: #f8f8f8;
	background-image: url('http://placekitten.com/g/500/200');
	/*background-size: cover;*/
	background-size: cover;
	background-repeat: no-repeat;
	background-position: top left;
	cursor: pointer;

	border-bottom-color: #e1e8ed;
	border-bottom-width: 1px;
	border-bottom-style: solid;
}

.followed-user-bottom {
	padding-left: 12px;
	background-color: white;
}


.followed-user-img {
	width: 70px;
	height: 70px;

	border-radius: 5px !important;
	border-color: #fff;
	border-width: 3px;
	border-style: solid;

	margin-top: -35px;
	cursor: pointer;
}

.followed-user-img-wrapper {}

.followed-user-name {
	color: rgb(41, 47, 51);
	margin-top: 6px;
	margin-bottom: 0px;
	cursor: pointer;
}

.followed-user-name:hover {
	text-decoration: underline;
}

.followed-user-screenname {
	color: rgb(102, 117, 127);
	margin-top: 0px;
	margin-bottom: 4px;
	font-size: 0.95em;
	cursor: pointer;
}

.user-screenname-span:hover {
	text-decoration: underline;
}


.followed-user-description {
	color: rgb(102, 117, 127);
	margin-bottom: 10px;
}

.gray-theme.fr-box.fr-basic .fr-element {
	z-index: 9999
}

.twig-24 {
	font-family: 'twig-24';
	font-variant: normal;
	font-weight: normal;
	speak: none;
	text-transform: none;
	-webkit-font-smoothing: antialiased;
}

.auth img {
	width: 20px;
	height: 20px;
	border-radius: 50%;
	object-fit: cover;
}

.comments-tree-list {
	list-style: none;
	padding: 0px;
}

.fr-element {
	z-index: 99999;
}

.mass_comments_action {
	background: #f7f7f7;
	margin: 15px -16px 0px -16px;
	padding: 10px 15px 10px 15px;
	border-top: 1px solid #dfdfdf;
	border-bottom: 1px solid #dfdfdf;
	text-align: right;
	display: none;
}

.scroll-pup {
	z-index: 999999;
}



.fr-placeholder {
	z-index: 999
}

/*---Подсветка кода в теге [code]---*/
pre code {
	display: block;
	padding: 1.25em;
	background: #272938;
	overflow: auto;
	white-space: pre;
	border-radius: 0.25rem;
	color: #dedee6 !important;
	margin-top: 1rem;
	margin-bottom: 1rem;
}

pre .comment,
pre .template_comment,
pre .diff .header,
pre .doctype,
pre .lisp .string,
pre .javadoc {
	color: #93a1a1;
	font-style: italic;
}

pre .keyword,
pre .css .rule .keyword,
pre .winutils,
pre .javascript .title,
pre .method,
pre .addition,
pre .css .tag,
pre .lisp .title {
	color: #8CC152;
}

pre .number,
pre .command,
pre .string,
pre .tag .value,
pre .phpdoc,
pre .tex .formula,
pre .regexp,
pre .hexcolor {
	color: #48CFAD;
}

pre .title,
pre .localvars,
pre .function .title,
pre .chunk,
pre .decorator,
pre .builtin,
pre .built_in,
pre .lisp .title,
pre .identifier,
pre .title .keymethods,
pre .id {
	color: #5D9CEC;
}

pre .tag .title,
pre .rules .property,
pre .django .tag .keyword {
	font-weight: bold;
}

pre .attribute,
pre .variable,
pre .instancevar,
pre .lisp .body,
pre .smalltalk .number,
pre .constant,
pre .class .title,
pre .parent,
pre .haskell .label {
	color: #F6BB42;
}

pre .preprocessor,
pre .pi,
pre .shebang,
pre .symbol,
pre .diff .change,
pre .special,
pre .keymethods,
pre .attr_selector,
pre .important,
pre .subst,
pre .cdata {
	color: #FC6E51;
}

pre .deletion {
	color: #dc322f;
}

pre .tex .formula {
	background: #eee8d5;
}


.navbar-light li.active {
	background-color: #e7e8ef;
	border-color: #e7e8ef;
	color: #68667f;
	border-radius: 0.4rem;
	transition: 0.3s;
}

.navbar-light li.active:hover {
	background-color: #dedfe9;
	border-color: #dedfe9;
	color: #6f6d87;
	transition: 0.05s;
}

.navbar-dark li.active {
	background-color: #ffffff;
	border-color: #e7e8ef;
	color: #fff !important;
	border-radius: 0.4rem;
	transition: 0.05s;
}

.navbar-dark li.active:hover {
	background-color: #f7f7f7;
	border-color: #e7e8ef;
	color: #fff !important;
	border-radius: 0.4rem;
	transition: 0.1s;
}


@media (min-width: 576px) {
	.tb {
		margin-top: 0px;
		margin-bottom: 0px
	}

	#dwth {
		width: min-content;
	}
}

@media (min-width: 768px) {
	.tb {
		margin-top: 0px;
		margin-bottom: 0px
	}

	#dwth {
		width: min-content;
	}
}

@media (min-width: 992px) {
	.tb {
		margin-bottom: 30px
	}

	#dwth {
		min-width: 200px !important;
	}
}

@media (min-width: 1200px) {
	.tb {
		margin-bottom: 30px
	}

	#dwth {
		min-width: 200px !important;
	}
}

@media (min-width: 1399px) {
	.tb {
		margin-bottom: 30px
	}

	#dwth {
		min-width: 200px !important;
	}
}

fieldset {
	border: 1px solid rgba(0, 0, 0, 0.1);
	padding: 20px;
	margin-bottom: 25px;
}

.pagination {
	display: inline-block;
	padding-left: 0;
	margin: 0 0 15px;
	border-radius: 4px
}

.pagination>li {
	display: inline
}

.pagination>li>a,
.pagination>li>span {
	position: relative;
	float: left;
	padding: 5px 12px;
	line-height: 1.42857143;
	margin: 0 3px;
	font-size: 1.1rem;
	color: #535c71;
	text-decoration: none;
	background-color: #e7e7f3;
	transition: .3s;
}

.pagination>li:first-child>a,
.pagination>li:first-child>span {
	margin-left: 0;
	border-top-left-radius: 4px;
	border-bottom-left-radius: 4px
}

.pagination>li:last-child>a,
.pagination>li:last-child>span {
	border-top-right-radius: 4px;
	border-bottom-right-radius: 4px
}

.pagination>li>a:hover,
.pagination>li>.pagination>li>a:focus,
.pagination>li> {
	z-index: 2;
	color: #8c8fab;
	background-color: #cccce0;
}

.pagination>li>a:hover {
	z-index: 2;
	color: #8c8fab;
	background-color: #cccce0;
}

.pagination>.active>a,
.pagination>.active>span,
.pagination>.active>a:hover,
.pagination>.active>span:hover,
.pagination>.active>a:focus,
.pagination>.active>span:focus {
	z-index: 3;
	color: #fff;
	cursor: default;
	background-color: #337ab7;
	border-color: #337ab7
}

.pagination>.disabled>span,
.pagination>.disabled>span:hover,
.pagination>.disabled>span:focus,
.pagination>.disabled>a,
.pagination>.disabled>a:hover,
.pagination>.disabled>a:focus {
	color: #777;
	cursor: not-allowed;
	background-color: #fff;
	border-color: #ddd
}

.pagination-lg>li>a,
.pagination-lg>li>span {
	padding: 10px 16px;
	font-size: 18px;
	line-height: 1.3333333
}

.pagination-lg>li:first-child>a,
.pagination-lg>li:first-child>span {
	border-top-left-radius: 6px;
	border-bottom-left-radius: 6px
}

.pagination-lg>li:last-child>a,
.pagination-lg>li:last-child>span {
	border-top-right-radius: 6px;
	border-bottom-right-radius: 6px
}

.pagination-sm>li>a,
.pagination-sm>li>span {
	padding: 5px 10px;
	font-size: 12px;
	line-height: 1.5
}

.pagination-sm>li:first-child>a,
.pagination-sm>li:first-child>span {
	border-top-left-radius: 3px;
	border-bottom-left-radius: 3px
}

.pagination-sm>li:last-child>a,
.pagination-sm>li:last-child>span {
	border-top-right-radius: 3px;
	border-bottom-right-radius: 3px
}

.pagination>li span {
	position: relative;
	float: left;
	padding: 5px 13px;
	line-height: 1.42857143;
	margin: 0 3px;
	font-size: 1.1rem;
	text-decoration: none;
	background-color: #f2f2f9;
	transition: .3s;
	background-image: repeating-linear-gradient(-45deg, rgba(82, 91, 171, 0.25), rgba(82, 91, 171, 0.25) 1px, transparent 1px, transparent 6px) !important;
	background-size: 8px 8px !important;
}


.box {
	cursor: pointer;
	height: 160px;
	position: relative;
	overflow: hidden;
	width: 100%;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	text-align: center;
}

.box img {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	max-width: 150px;
	max-height: 150px;
	margin: auto;
	transition: 1s;
	-o-object-fit: contain;
	object-fit: contain;
}

.box .overbox {
	background-color: rgba(31, 32, 41, 0.7);
	position: absolute;
	top: 0;
	left: 0;
	color: #fff;
	z-index: 1;
	-webkit-transition: all 320ms ease-out;
	-moz-transition: all 320ms ease-out;
	-o-transition: all 320ms ease-out;
	-ms-transition: all 320ms ease-out;
	transition: all 320ms ease-out;
	opacity: 0;
	text-align: center;
	width: 100%;
	height: 100%;
	padding: 35px 20px;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
}


.box:hover .overbox {
	opacity: 1;
}

.box .overtext {
	-webkit-transition: all 220ms ease-out;
	-moz-transition: all 220ms ease-out;
	-o-transition: all 220ms ease-out;
	-ms-transition: all 220ms ease-out;
	transition: all 220ms ease-out;
	transform: translateY(40px);
	-webkit-transform: translateY(40px);
}

.box .title {
	font-size: 13px;
	text-transform: uppercase;
	opacity: 0;
	transition-delay: 0.1s;
	transition-duration: 0.2s;
}

.box:hover .title,
.box:focus .title {
	opacity: 1;
	transform: translateY(0px);
	-webkit-transform: translateY(0px);
}

.box .tagline {
	font-size: 13px;
	opacity: 0;
	transition-delay: 0.2s;
	transition-duration: 0.2s;
	font-family: arial;
}

.box:hover .tagline,
.box:focus .tagline {
	opacity: 1;
	transform: translateX(0px);
	-webkit-transform: translateX(0px);
}

#bsh {
	-webkit-box-shadow: 0px 0px 13px 0px rgba(82, 63, 105, 0.1);
	box-shadow: 0px 0px 13px 0px rgba(82, 63, 105, 0.1);
}

.opaque {
	background: #161623 !important;
	transition: 0.3s;
	border-radius: 0 !important;
}

.noimg img {
	display: none;
}

#online a {
	color: #8CC152;
}

.profoto {
	width: 20px;
	height: 20px;
	border-radius: 50%;
	vertical-align: text-top;
	object-fit: cover;
}

.commfoto {
	width: 19px;
	height: 19px;
	border-radius: 50%;
	object-fit: cover;
}

.dropdown-menu a:hover {
	text-decoration: none;
	cursor: pointer;
}

.dropdown-menu button:hover {
	text-decoration: none;
	cursor: pointer;
}

.tags {
	margin-top: 5px;
}

.tags a {
	color: #a9acc5;
	background: #f7f8fa;
	padding: 3px 6px 3px 6px;
	border-radius: 0.2rem;
	transition: 0.3s;
	font-weight: 200;
	font-size: 12px;
}

.tags a:hover {
	color: #b3b3b3;
	background: #eaeaea;
	text-decoration: none;
	cursor: pointer;
}

.clouds_medium a {
	color: #b3b3b3;
	background: #f3f3f3;
	padding: 0px 6px 3px 6px;
	border-radius: 0.2rem;
	font-size: 13px;
	transition: 0.3s;
	margin: 3px;
}

.clouds_medium a:hover {
	color: #b3b3b3;
	background: #eaeaea;
	padding: 0px 6px 3px 6px;
	border-radius: 0.2rem;
	font-size: 13px;
	text-decoration: none;
	cursor: pointer;
}

.clouds_xsmall a {
	color: #b3b3b3;
	background: #f3f3f3;
	padding: 0px 6px 3px 6px;
	border-radius: 0.2rem;
	font-size: 13px;
	transition: 0.3s;
	margin: 3px;
}

.clouds_xsmall a:hover {
	color: #b3b3b3;
	background: #eaeaea;
	padding: 0px 6px 3px 6px;
	border-radius: 0.2rem;
	font-size: 13px;
	text-decoration: none;
	cursor: pointer;
}

.clouds_xlarge a {
	color: #b3b3b3;
	background: #f3f3f3;
	padding: 0px 6px 3px 6px;
	border-radius: 0.2rem;
	font-size: 13px;
	transition: 0.3s;
	margin: 3px;
}

.clouds_xlarge a:hover {
	color: #b3b3b3;
	background: #eaeaea;
	padding: 0px 6px 3px 6px;
	border-radius: 0.2rem;
	font-size: 13px;
	text-decoration: none;
	cursor: pointer;
}

.auth a {
	color: #4e040b;
	padding: 3px 6px 3px 6px;
	border-radius: 0.2rem;
	transition: 0.3s;
	font-weight: bold;
}

.auth a:hover {
	color: #75757b;
	background: #eaeaea;
	text-decoration: none;
	cursor: pointer;
}

.f90 {
	font-size: 15px;
}


.ava {
	width: 100px;
	height: 100px;
	object-fit: cover;
}

.isize i {
	color: #a9a9ca;
}

.dropdown-menu {
	-webkit-box-shadow: 0px 0px 50px 0px rgba(82, 63, 105, 0.15);
	box-shadow: 0px 0px 50px 0px rgba(82, 63, 105, 0.15);
}

.authbg {
	background-color: #1f2029;
	background-image: url(/templates/lifesport/images/pat-back.svg);
	background-position: center;
	background-repeat: repeat;
	background-size: 25%;
}

ol.spb span:first-child span {
	color: #434349;
}

.hr1 {
	margin-top: 1rem;
	margin-bottom: 1rem;
	border: 0;
	border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.shtitle {
	line-height: 1 !important;
}


.shtitle a {
	color: #000;
	font-size: 20px;
	transition: 0.3s;
	font-weight: bold;
	text-decoration: none !important;
}

.shtitle a:hover {
	color: #0072bc;
	text-decoration: none;
}

.shtitle-news a {
	color: #000 !important;
	font-size: 26px;
	transition: 0.3s;
	font-weight: bold;
	text-decoration: none !important;
}


.shtitle-news a:hover {
	color: #6b75cb !important;
	text-decoration: none !important;
	transition: 0.3s;
}

#dle-speedbar a {
	color: #000 !important;
}

#dle-speedbar {
	color: #3f51b5;
}

.qq-upload-button {
	font-weight: 700;
	border: 1px solid #0098d0;
	background-color: #0098d0;
	-webkit-box-shadow: 0 0 0 2px #fff;
	-moz-box-shadow: 0 0 0 2px #fff;
	-ms-box-shadow: 0 0 0 2px #fff;
	-o-box-shadow: 0 0 0 2px #fff;
	box-shadow: 0 0 0 2px #fff;
	height: 39px;
	line-height: 39px !important;
	color: #fff;
	cursor: pointer;
	padding: 0 15px;
	text-align: center;
}

.ui-dialog-buttonset button {
	background: #fff;
	border: 1px solid #dfdfdf;
	color: #656D78;
	padding: 2px 8px 4px 8px;
	font-size: 90%;
	border-radius: 0.25rem;
	margin-left: 6px;
	margin-right: 6px;
	transition: 0.3s;
}

.ui-dialog-buttonset button:hover {
	background: #f1f1f1;
	border: 1px solid #dfdfdf;
	color: #656D78;
	padding: 2px 8px 4px 8px;
	font-size: 90%;
	border-radius: 0.25rem;
	margin-left: 6px;
	margin-right: 6px;
	cursor: pointer;
}

::-webkit-input-placeholder {
	/* Chrome */
	color: #c4c6d8 !important;
}

:-ms-input-placeholder {
	/* IE 10+ */
	color: #c4c6d8 !important;
}

::-moz-placeholder {
	/* Firefox 19+ */
	color: #c4c6d8 !important;
	opacity: 1;
}

:-moz-placeholder {
	/* Firefox 4 - 18 */
	color: #c4c6d8 !important;
	opacity: 1;
}

/* --- Поля форм --- */
select,
textarea,
input[type="text"],
input[type="password"],
input[type="file"],
input[type="datetime"],
input[type="datetime-local"],
input[type="date"],
input[type="month"],
input[type="time"],
input[type="week"],
input[type="number"],
input[type="email"],
input[type="url"],
input[type="search"],
input[type="tel"],
input[type="color"] {
	font-family: "Cutest", sans-serif;
	padding: 10px;
	font-size: 14px;
	color: #a5a7c1;
	background-color: #fff;
	transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
	width: 100%;
}

textarea {
	margin: 0;
	overflow: auto;
	vertical-align: top;
	resize: vertical;
}

textarea:focus,
select:focus,
input[type="text"]:focus,
input[type="password"]:focus,
input[type="file"]:focus,
input[type="datetime"]:focus,
input[type="datetime-local"]:focus,
input[type="date"]:focus,
input[type="month"]:focus,
input[type="time"]:focus,
input[type="week"]:focus,
input[type="number"]:focus,
input[type="email"]:focus,
input[type="url"]:focus,
input[type="search"]:focus,
input[type="tel"]:focus,
input[type="color"]:focus,
.uneditable-input:focus {
	background-color: #fff;
}

input[type="radio"],
input[type="checkbox"] {
	line-height: normal;
	margin: -2px 6px 0 0;
	vertical-align: middle;
}

input[type="file"],
input[type="image"],
input[type="submit"],
input[type="reset"],
input[type="button"],
input[type="radio"],
input[type="checkbox"] {
	width: auto;
}

select[multiple],
select[size],
textarea {
	height: auto;
}

::-moz-placeholder,
:-moz-placeholder,
::-webkit-input-placeholder {
	opacity: 0.6;
}

input[type="file"],
input[type="image"] {
	padding: 0;
	border-width: 0;
	background: none;
	box-shadow: none;
	-webkit-box-shadow: none;
}

.wide,
.bb-editor textarea,
.ui-dialog textarea,
select#category,
.timezoneselect,
.quick-edit-text {
	width: 100% !important;
}

#searchuser,
#searchinput {
	width: 100% !important;
	margin-bottom: 10px;
}

table.xfields input {
	width: 100%;
}

table.xfields tr>td:first-child {
	padding-right: 10px;
}

/* Настройка стандартной капчи */
.form_submit .c-capcha {
	float: right;
}

.c-capcha {
	position: relative;
}

.c-capcha:after {
	clear: both;
	display: block;
	content: "";
}

.c-capcha>a {
	float: left;
	margin-right: 5px;
}

.c-capcha img {
	position: relative;
	display: block;
	width: 100px;
	height: 36px;
	border-radius: 20px;
	z-index: 1;
	padding: 1px;
	background: #fff;
	border: 1px solid #dcdcdc;
	-webkit-transition: all ease .2s;
	transition: all ease .2s;
}

.c-capcha:hover img {
	box-shadow: 0 6px 20px 0 rgba(0, 0, 0, 0.2);
	-webkit-box-shadow: 0 6px 20px 0 rgba(0, 0, 0, 0.2);
	-webkit-transform: scale(1.3, 1.3);
	transform: scale(1.3, 1.3);
	border-color: #1a1a1a;
}

.c-capcha>input {
	float: left;
	width: 150px;
	text-align: center;
}

/* Настройка стандартной капчи при ответах на комментарии */
.dle-captcha {
	position: relative;
}

.dle-captcha:after {
	clear: both;
	display: block;
	content: "";
}

.dle-captcha>a {
	float: left;
	margin-right: 5px;
}

.dle-captcha img {
	position: relative;
	display: block;
	width: 130px;
	height: 46px;
	-webkit-transition: all ease .2s;
	transition: all ease .2s;
}

.dle-captcha>input {
	float: left;
	width: 130px;
}

/* --- Вывод результатов голосования на сайте --- */
.voteprogress,
.pollprogress {
	overflow: hidden;
	height: 9px;
	margin-bottom: 10px;
	background-color: #e7e7e7;
	border-radius: 3px;
	margin-top: 6px;
}

.voteprogress span,
.pollprogress span {
	text-indent: -9999px;
	height: 9px;
	display: block;
	overflow: hidden;
	background-color: #656fc3;
}

.arrow_box {
	position: relative;
	background: #f5f5f9;
	border: 1px solid #f5f5f9;
	padding: 1.25rem;
	border-radius: 0.25rem;
}

.arrow_box:after,
.arrow_box:before {
	bottom: 100%;
	left: 30px;
	border: solid transparent;
	content: " ";
	height: 0;
	width: 0;
	position: absolute;
	pointer-events: none;
}

.arrow_box:after {
	border-color: rgba(255, 255, 255, 0);
	border-bottom-color: #f5f5f9;
	border-width: 9px;
	margin-left: -9px;
}

.arrow_box:before {
	border-color: rgba(0, 0, 0, 0);
	border-bottom-color: #f5f5f9;
	border-width: 10px;
	margin-left: -10px;
}

.xfieldsnote {
	display: inline-block;
	margin-left: 5px;
	font-size: 90%;
	color: #c5
}

#cd-timeline {
	position: relative;
}

#cd-timeline::before {
	content: '';
	position: absolute;
	top: 0;
	left: 20px;
	height: 100%;
	width: 2px;
	background: #f5f5f9;
}

.cd-timeline-block {
	position: relative;
	margin: 2em 0;
}

.cd-timeline-block::after {
	clear: both;
	content: "";
	display: table;
}

.cd-timeline-block:first-child {
	margin-top: 0;
}

.cd-timeline-block:last-child {
	margin-bottom: 10px;
}


.cd-timeline-img {
	position: absolute;
	top: 0;
	left: 0;
	width: 42px;
	height: 42px;
	border-radius: 50%;
	border: 2px solid #ebedf5;
}

.cd-timeline-img img {
	display: block;
	width: 100%;
	height: 100%;
	position: relative;
	border-radius: 50%;
	padding: 2px;
}

.cd-timeline-img.cd-picture {
	background: #f5f6fa;
}


.cd-timeline-content {
	position: relative;
	margin-left: 52px;
	background: rgba(245, 245, 249, 0.74);
	border-radius: 0.25em;
	padding: 0.5rem 1.2rem 0.5rem 1.2rem;
}

.cd-timeline-content::after {
	clear: both;
	content: "";
	display: table;
}

.cd-timeline-content p,
.cd-timeline-content .cd-read-more,
.cd-timeline-content .cd-date {
	font-size: 13px;
	font-size: 0.8125rem;
}

.cd-timeline-content .cd-read-more,
.cd-timeline-content .cd-date {
	display: inline-block;
}

.cd-timeline-content p {
	margin: 0;
}

.cd-timeline-content .cd-read-more {
	float: right;
	padding: .8em 1em;
	background: #acb7c0;
	color: #ffffff;
	border-radius: 0.25em;
}

.no-touch .cd-timeline-content .cd-read-more:hover {
	background-color: #bac4cb;
}

.cd-timeline-content .cd-date {
	float: left;
	padding: .8em 0;
	opacity: .7;
}

.cd-timeline-content::before {
	content: '';
	position: absolute;
	top: 14px;
	right: 100%;
	height: 0;
	width: 0;
	border: 7px solid transparent;
	border-right: 7px solid rgb(247, 247, 250);
}

@media only screen and (min-width: 768px) {
	.cd-timeline-content h2 {
		font-size: 1rem;
		font-weight: bold;
		color: #8a8c9e;
	}

	.fnm {
		font-size: 0.8rem;
		font-weight: 100;
		color: #b7b6bb;
	}

	.cd-timeline-content .cd-read-more,
	.cd-timeline-content .cd-date {
		font-size: 14px;
		font-size: 0.875rem;
	}
}

.cd-timeline-block:nth-child(even) .cd-timeline-content::before {
	top: 24px;
	left: auto;
	right: 100%;
	border-color: transparent;
	border-right-color: #ffffff;
}

.cd-timeline-block:nth-child(even) .cd-timeline-content .cd-read-more {
	float: right;
}

.cd-timeline-block:nth-child(even) .cd-timeline-content .cd-date {
	left: auto;
	right: 122%;
	text-align: right;
}

.cssanimations .cd-timeline-content.is-hidden {
	visibility: hidden;
}

.cssanimations .cd-timeline-content.bounce-in {
	visibility: visible;
	-webkit-animation: cd-bounce-2 0.6s;
	-moz-animation: cd-bounce-2 0.6s;
	animation: cd-bounce-2 0.6s;
}

.rep li {
	font-size: 80%;
}

.rep>li:before {
	content: '';
	width: 32px;
	background: #f5f5f9;
	position: absolute;
	height: 2px;
	margin-top: 20px;
	left: -32px;
}

ol li ol {
	margin-left: 52px;
	position: relative;
}


ol li ol li:before {
	content: '';
	width: 32px;
	background: #f5f5f9;
	position: absolute;
	height: 2px;
	margin-top: 20px;
	left: -32px;
}


.cFIwCf {
	position: sticky;
	top: 72px;
}


.gnHLLb {
	padding-bottom: 36px;
}


.offer-sidebar__buttons {
	margin-bottom: 15px;
}

.offer-sidebar__buttons div {
	margin-bottom: 8px
}


.offer-sidebar__buttons .price-button {
	display: block;
	padding: 8px 20px;
	font-weight: 500;
	border-radius: 4px;
	position: relative;
	font-size: 22px;
	word-wrap: break-word;
	text-align: center;
	cursor: pointer;
	transition: background-color 0.2s ease-in-out 0s, box-shadow 0.2s ease-in-out 0s;
	background: #f3f3f3;
	color: #000;
	width: 100%;
	margin-bottom: 5px;
}



.offer-sidebar__buttons .contact-button {
	display: block;
	height: 40px;
	padding: 8px 20px;
	font-weight: 500;
	border-radius: 4px;
	position: relative;
	color: #fff;
	font-size: 16px;
	background: rgb(76 175 80);
	word-wrap: break-word;
	cursor: pointer;
	text-align: center;
	box-shadow: rgba(0, 0, 0, 0.04) 0px 2px 4px 0px;
}

.offer-sidebar__buttons .contact-button:hover {
	background: #4ba64f;
	box-shadow: rgba(0, 0, 0, 0.06) 0px 4px 8px 0px;
}

.offer-sidebar__buttons .contact-button.activated {
	cursor: default
}

.offer-sidebar__buttons .contact-button [data-icon] {
	position: absolute;
	margin-top: 2px;
	top: 16px;
	left: 55px;
}


.offer-sidebar__buttons .contact-button .spoiler {
	font-weight: 400;
	font-size: 11px;
	border-bottom: 1px dotted #accaee;
	color: #fff
}

.offer-sidebar__buttons .contact-button .spoiler:hover {
	background: #0098d0
}


.sc-xOkv li {
	list-style: none;
}


.offer-sidebar__buttons .contact-button .fa {
	font-size: 20px;
	right: 5px;
	position: relative;
}


.offer-sidebar__box {
	margin-bottom: 10px;
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	-ms-border-radius: 3px;
	-o-border-radius: 3px;
	border-radius: 3px;
	box-sizing: border-box;
	position: relative;
	background: #fff
}

.offer-sidebar__box-title {
	font-size: 16px;
	text-align: left;
	line-height: 20px;
	color: #414141;
	margin: 0 0 10px
}


.offer-user__location {
	margin: 0 -1px;
	padding: 10px 10px 52px;
	box-sizing: border-box;
	position: relative;
	background: url(/templates/lifesport/images/karta.svg) 50% 0 no-repeat;
}


.offer-user__address {
	padding: 10px 15px;
	border-radius: 3px;
	background: #fff;
	position: relative;
	font-size: 20px;
	text-align: center;
}


.offer-user__image {
	width: 80px;
	height: 80px;
	border: 3px solid #fff;
	border-radius: 50%;
	box-sizing: border-box;
	margin-top: -40px;
	margin-left: -40px;
	position: absolute;
	top: 100%;
	left: 50%;
	background: #efefef;
	text-align: center;
	overflow: hidden;
}


.offer-user__details {
	padding: 50px 16px 15px;
	text-align: center;
}


.offer-user__details h4 {
	margin-bottom: 5px;
	font-size: 20px;
	font-weight: bold;
	color: #0098d0;
}


.offer-user__details .user-since {
	margin-bottom: 15px;
	display: block;
	color: #7c919b;
}


.offer-sidebar__box .user-offers {
	margin: 0;
	display: block;
	height: 40px;
	padding: 8px 20px;
	font-weight: 500;
	border-radius: 4px;
	position: relative;
	color: #ffffff;
	font-size: 16px;
	word-wrap: break-word;
	cursor: pointer;
	text-align: center;
	background: rgb(116, 188, 37);
	box-shadow: rgba(0, 0, 0, 0.04) 0px 2px 4px 0px;
}


.offer-sidebar__box .user-offers:hover {
	background-color: rgb(104 168 35);
	color: #fff;
}


.offer-user__image {
	width: 80px;
	height: 80px;
	border: 3px solid #fff;
	border-radius: 50%;
	box-sizing: border-box;
	margin-top: -40px;
	margin-left: -40px;
	position: absolute;
	top: 100%;
	left: 50%;
	background: #efefef;
	text-align: center;
	overflow: hidden;
}


.offer-user__address address {
	font-size: 20px;
	line-height: 5px;
	display: inline-block;
	color: rgb(55 55 55);
}


.offer-user__address:after {
	width: 0;
	height: 0;
	border-style: solid;
	border-width: 7px 8px 0;
	border-color: #fff transparent transparent;
	position: absolute;
	top: 100%;
	left: 50%;
	margin-left: -8px;
	content: '';
}


.offer-user__address address p {
	margin-bottom: 2px;
}


.offer-user__image img {
	max-width: 100%;
	max-height: 100%;
}


.main-rinok .offerobserve {
	width: 100px;
	padding: 5px 0;
	left: 10px;
	top: 15px;
	position: absolute;
	z-index: 3;
}

.main-rinok .offerobserve:hover {
	text-decoration: none;
}


.layerlink {
	background: url(/templates/lifesport/images/back-fav.png);
}


.br5 {
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
}

.pdingtop9 {
	text-align: center;
	font-size: 32px;
}


.xx-large a {
	color: white;
}

.xx-large a:hover {
	color: white;
	text-decoration: none;
}


.pright-news {
	padding: 10px;
	height: 200px;
	position: relative;
}


.auth {
	margin-top: 5px;
	margin-bottom: 5px;
}


.pdingtop10 {
	padding: 4px;
	text-align: center;
	font-size: 12px;
	line-height: 16px;
	color: #000;
}


.noimg {

	color: #454d8c;
	font-size: 12px;
	text-align: justify;
	overflow: hidden;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
	height: 80px;
	cursor: default;

}


.pnews-rel {
	position: relative;
}


.v-panel {
	position: absolute;
	color: #000000;
	font-size: 12px;
	bottom: 50px;
	width: 400px;
	line-height: 28px;
	padding: 0 0 0 5px;
}


.v-panel .v-count a {
	color: #000;
}


.card-news-black .v-panel .v-count {
	float: right;
	font-size: 11px;
	line-height: 28px;
	text-align: center;
}


.v-panel .v-count {
	font-size: 13px;
}

.v-panel .p-description {

	margin-left: 5px;

}


.card-news-black:hover .date-news {
	display: block;
}

.card-news:hover .date-news {
	display: block;
}


.card-news .date-news {
	float: right;
	position: absolute;
	right: 10px;
	color: #000;
	text-align: right;
	bottom: 5px;
	font-size: 15px;
	padding: 0 0 0 5px;
	background: white;
	display: none;
}


.card-news-black .date-news {
	float: right;
	position: absolute;
	right: 10px;
	color: #fff;
	text-align: right;
	bottom: 5px;
	font-size: 15px;
	padding: 0 0 0 5px;
	background: #012;
	display: none;
}


.v-panel .date {
	font-style: normal;
	float: left;
	min-width: 64px;
	padding-right: 5px;
}


.v-panel .autor {
	display: block;

}


.f-panel {
	position: absolute;
	left: 0;
	right: 0px;
	bottom: 2px;
	font-size: 14px;
	line-height: 28px;
	color: #fff;
	padding: 0 0 0 5px;
	margin-top: 0px;

}


.f-panel .v-count {
	background-image: none;
	background-color: rgba(102, 102, 102, 0.5);
}


.f-panel .v-count a {
	color: #fff;
}

.f-panel .v-count {
	float: right;
	width: auto;
	font-size: 12px;
	line-height: 28px;
	text-align: center;
	padding: 0 10px;
	background: #9C27B0;
}

.f-panel .date {
	font-style: normal;
	float: left;
	min-width: 64px;
	padding-right: 5px;
}


.f-panel .comment {
	font-style: normal;
	float: left;
	padding-right: 5px;
}

.f-panel .views {
	font-style: normal;
	float: left;
	padding-right: 5px;
}

.f-panel .author {
	font-style: normal;
	float: left;
	padding-right: 5px;
}

.f-panel .author a {
	color: #fff;
}

.f-panel .autor {
	display: block;

}


.item-rinok {
	padding: 0;
}


.item-poster {
	padding: 25px 5px 0px 5px;
}

.item {
	padding: 5px;
}

.item-razv {
	padding: 10px;
}


.card-body-auth {
	padding: 10px;
	display: block;
	position: relative;
	background: white;
	width: 350px;
	margin: 0 auto;
}


.item svg {
	color: #3F51B5;
}


.card-news-site {
	display: block;
	position: relative;
	padding: 1.25rem;
}

.m-13 {
	display: block;
	color: #ffffff;
	font-size: 15px;

}


#navbarResponsive .menu-right {
	display: block;
	float: left;
	white-space: nowrap;
	display: flex;
	align-items: center;
	justify-content: right;
	text-align: right;
}


#navbarResponsive .menu-user {
	display: inline-block;
	line-height: 60px;
	font-size: 18px;
	width: 60px;
	height: 60px
}

#navbarResponsive .menu-user>a {
	display: inline-block;
	width: 60px;
	height: 60px;
	background: transparent;
	text-align: center;
	font-size: 24px;
	float: left;
	position: relative;
}


#navbarResponsive .menu-user>a .redround {
	display: inline;
	position: absolute;
	background-color: #fc000f;
	-webkit-border-radius: 100px;
	-moz-border-radius: 100px;
	border-radius: 100px;
	padding: 0 4px;
	text-align: center;
	line-height: 15px;
	right: 5px;
	top: 10px;
	font-style: normal;
	font-size: 13px;
	color: #fff;
	z-index: 1;
	-moz-box-shadow: 0 0 5px 5px #888;
	-webkit-box-shadow: 0 0 5px 5px #888;
	box-shadow: 0 0 5px 2px rgba(0, 0, 0, .5);
	text-shadow: 1px 1px 2px rgba(0, 0, 0, .41);
}


#navbarResponsive .menu-user>a:hover,
#navbarResponsive .menu-user:hover>a,
#navbarResponsive .menu-user.open>a {
	background: #212529
}

#navbarResponsive .menu-user.dropdown:hover>.dropdown-menu {
	display: block
}

#navbarResponsive .menu-user.w-dot>a:after {
	line-height: 0px;
	font-size: 0px;
	content: '';
	padding: 0;
	border-radius: 50%;
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	background: #fa7204;
	position: absolute;
	top: 50%;
	left: 50%;
	width: 8px;
	height: 8px;
	margin: 8px 0 0 8px
}


#navbarResponsive .dropdown-menu {
	background: #212529;
	border: 0;
	outline: 0;
	margin: -1px 0 0;
	text-align: left;
	font-size: 16px;
	font-weight: normal;
	color: #FFF;
	padding: 8px 0;
}


#navbarResponsive .dropdown-menu>li,
#navbarResponsive .events-popup {
	color: #FFF;
	display: block;
	line-height: 1em;
}


#navbarResponsive .dropdown-menu>li>a,
#navbarResponsive .events-popup>a {
	display: block;
	line-height: 1em;
	color: #FFF;
	position: relative;
	padding: 8px 12px !important;
}

#navbarResponsive .dropdown-menu>li>a:hover,
#navbarResponsive .events-popup>a:hover {
	background: #0072bc;
	color: #FFF;
}


#navbarResponsive .dropdown-menu>li>a,
#navbarResponsive .events-popup>a {
	display: block;
	line-height: 1em;
	color: #FFF;
	position: relative;
	padding: 8px 12px !important;
}


.card-razdel-f {
	font-weight: bold;
	background: #222;
	height: 18px;
	font-size: 13px;
	color: #fff;
	letter-spacing: 1px;
	line-height: 17px;
	width: 100%;
	text-align: center;
	display: block;
	top: 170px;
	position: absolute;
	left: 0px;
	z-index: 1;
	overflow: hidden;
}


.card-razdel-i {
	font-weight: bold;
	background: #28a745;
	height: 18px;
	font-size: 13px;
	color: #fff;
	letter-spacing: 1px;
	line-height: 17px;
	width: 100%;
	text-align: center;
	display: block;
	top: 170px;
	position: absolute;
	left: 0px;
	z-index: 1;
	overflow: hidden;
}


.card-razdel-p {
	font-weight: bold;
	background: #1e88e5;
	height: 18px;
	font-size: 13px;
	color: #fff;
	letter-spacing: 1px;
	line-height: 17px;
	width: 100%;
	text-align: center;
	display: block;
	top: 170px;
	position: absolute;
	left: 0px;
	z-index: 1;
	overflow: hidden;
}


.info-razv {

	padding-top: 25px;
	padding-right: 5px;
	padding-left: 5px;
	padding-bottom: 5px;
	text-align: center;
	height: 50px;
	color: black;
	font-weight: bold;
}

.box .tagline span {
	color: #ffc107;
}


.xx-large {
	color: white;
}


.related-news .owl-carousel .owl-item img {
	cursor: -webkit-zoom-in;
	cursor: -moz-zoom-in;
	display: block;
	margin: auto;
	vertical-align: middle;
	max-width: 145px;
	max-height: 170px;
	float: none;
	position: relative;
}


#kateg .dropdown-menu {
	transform: translate3d(0px, 35px, 0px) !important;
}

#kateg .dropdown-item {

	padding: 5px 0px;
}

#kateg .bootstrap-select .dropdown-menu.inner {
	margin-top: -35px;
	width: 525px;
}


.hrx {
	margin: 10px 0px 10px 0px;
	border: 0;
	border-top: 2px dashed var(--purple);
}


.auth-magaz {
	border: 1px solid #bdbdbd;
	padding: 5px;
	margin-bottom: 33px;
	margin: 0px 5px 10px 0px;
	float: left;
	position: relative;
	font-size: 15px;
	width: 264px;
}


.desc-magaz {
	float: left;
	margin-left: 5px;

}


.footer-desc .navbar-brand {
	display: inline-block;
	margin-right: 5px;
	font-size: 16px;
	line-height: inherit;
	white-space: nowrap;
	color: #e0e0e0;
	font-family: 'Roboto Black';
}

.footer-desc .navbar-brand:hover {
	text-decoration: none;
	color: #e0e0e0;
}


.footer-desc {
	margin: 0 auto;
	position: relative;
	width: 960px;
	text-align: center;
	color: #dcf4ff;
	font-size: 13px;
	text-align: justify;
	overflow: hidden;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
}

.text-desc-logo {
	font-size: 15px;
	color: #6c3cc5
}


.xfieldimagegallery {
	padding-inline-start: 0;
	padding-right: 5px;
	padding-left: 5px;
	padding-top: 10px;
	padding-bottom: 10px;
	margin-bottom: 0px;
}

.xfieldimagegallery li {
	float: left;
	border: 1px solid #000;
}


.xfields textarea,
.xprofile textarea {
	width: 100%;
	height: 186px;
	margin-top: 5px;
}

.xfields input[type="text"] {
	width: 100%;
}

.xfieldsdescr {
	width: 200px;
}

.xfields .bb-pane+textarea {
	margin-top: 0px;
}

.xfieldsnote {
	color: #838383;
	font-size: .9em;
}

.xfields_table td {
	vertical-align: top;
}

.xfieldsrow {
	padding-top: 5px;
	clear: both;
}

.xfieldscolleft {
	float: left;
	width: 30%;
	padding-top: 14px;
}

.xfieldscolright {
	float: left;
	width: 70%;
}

.file-box {
	width: 95%;
	max-width: 437px;
	border: 1px solid #B3B3B3;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	background-color: #F5F5F5;
	padding: 10px;
	margin-top: 10px;
}


.images_holder {
	overflow-x: scroll;
	position: relative;
	height: auto;
	max-height: 450px;
	width: 100%;
}


#images_while {
	width: auto;
	white-space: nowrap;
}


#images_while .inl {
	display: inline-block;
	margin-right: 10px;
	max-width: 87%;
}


#images_while .inl img {
	max-height: 420px;
	max-width: 100%;
	opacity: 1;
}

#images_while .inl img:hover {
	opacity: 0.4;
}


.xfieldimagegallery {
	margin: 0;
	padding: 0;
	list-style: none;
	clear: both;
}

.xfieldimagegallery li {
	list-style: none;
	margin: 0;
	padding: 0;
}

.xfieldimagegallery li img {
	float: left;
	margin-right: 5px;
	border: 5px solid #fff;
	width: 100px;
	height: 100%;
	transition: box-shadow 0.5s ease;
}

.xfieldimagegallery li img:hover {
	box-shadow: 0px 0px 7px rgba(0, 0, 0, 0.4);
}

.qq-uploader {
	position: relative;
	width: 100%;
}

.qq-upload-button {
	display: inline-block;
	margin-top: 5px;
	margin-bottom: 5px;
	cursor: pointer;
}

.qq-upload-drop-area {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	z-index: 2;
	max-width: 437px;
	background: #FF9797;
	text-align: center;
}

.qq-upload-drop-area span {
	display: block;
	position: absolute;
	top: 50%;
	width: 100%;
	margin-top: -8px;
	font-size: 16px;
}

.qq-upload-drop-area-active {
	background: #FF7171;
}

.uploadedfile {
	display: inline-block;
	width: 119px;
	height: 155px;
	margin: 10px 5px 5px 5px;
	border: 1px solid #B3B3B3;
	box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.3);
	-moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
	-webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
	text-align: center;
	background: #ffffff;

}

.uploadedfile .uploadimage {
	margin-top: 5px;
	width: 115px;
	height: 90px;
	display: table-cell;
	text-align: center;
	vertical-align: middle;
}

.uploadedfile .info {
	text-align: left;
	white-space: nowrap;
	margin: 0px 5px 0px 5px;
	overflow: hidden;
}

.btn.disabled,
.btn[disabled],
fieldset[disabled] .btn {
	cursor: not-allowed;
	pointer-events: none;
	opacity: 0.65;
	filter: alpha(opacity=65);
	-webkit-box-shadow: none;
	box-shadow: none;
}

.progress {
	overflow: hidden;
	margin-top: 10px;
	margin-bottom: 10px;
	background-color: whitesmoke;
	height: 10px;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	-ms-border-radius: 8px;
	-o-border-radius: 8px;
	border-radius: 8px;
	background: #eee;
	-webkit-box-shadow: 0 1px 0 white, 0 0px 0 1px rgba(0, 0, 0, 0.1) inset, 0 1px 4px rgba(0, 0, 0, 0.2) inset;
	box-shadow: 0 1px 0 white, 0 0px 0 1px rgba(0, 0, 0, 0.1) inset, 0 1px 4px rgba(0, 0, 0, 0.2) inset;
}

.progress .progress-bar {
	float: left;
	width: 0%;
	font-size: 12px;
	line-height: 20px;
	color: white;
	text-align: center;
	background-color: #428bca;
	-webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
	box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
	-webkit-transition: width 0.6s ease;
	transition: width 0.6s ease;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	-ms-border-radius: 8px;
	-o-border-radius: 8px;
	border-radius: 8px;
	-webkit-box-shadow: none;
	box-shadow: none;
	height: 8px;
}

.progress-bar span {
	position: absolute;
	width: 1px;
	height: 1px;
	margin: -1px;
	padding: 0;
	overflow: hidden;
	clip: rect(0 0 0 0);
	border: 0;
}

.progress-blue {
	background-image: -webkit-gradient(linear, left 0%, left 100%, from(#9bcff5), to(#6db9f0));
	background-image: -webkit-linear-gradient(top, #9bcff5, 0%, #6db9f0, 100%);
	background-image: -moz-linear-gradient(top, #9bcff5 0%, #6db9f0 100%);
	background-image: linear-gradient(to bottom, #9bcff5 0%, #6db9f0 100%);
	background-repeat: repeat-x;
	border: 1px solid #55aeee;
}


.marka-ul-rk {
	width: 100%;
	margin: 0;
	padding: 10px 10px;
}

.marka-ul-rk li {
	list-style: none;
	width: 49%;
	margin: 1px 0;
	display: inline-block;
}

.marka-ul-rk li div {
	width: 100px;
	border-radius: 3px;
	display: block;
	position: relative;
	float: left;
}


#btntextfilter {
	float: left;
	padding: 3px 12px 3px 12px;
	width: 100%;
	min-height: inherit;
	max-height: 30px;
	line-height: 30px;
	-webkit-box-sizing: border-box;
	box-sizing: border-box;
	padding-top: 0;
	padding-bottom: 0;
	background-color: #0096C7;
	background-image: none;
	border: none;
	-webkit-box-shadow: none;
	box-shadow: none;
	text-shadow: none;
	color: white
}


#btntextfilter:hover {

	background-color: #006b8e;

}


.scrollup {
	position: fixed;
	color: #6c757d;
	right: 50px;
	z-index: 999;
	bottom: 0px;
	padding: 15px 35px;
	font-size: 45px;
	cursor: pointer;
	display: none;
	text-align: center;
}

div.scrollup:hover {
	color: #848484;
	/* цвет заднего фона при наведении */
}



.item:hover .border_out {
	border: none;
}

.border_out {
	border: solid 3px #fff;
	width: calc(171px - 0px);
	height: 103px;
	position: absolute;
	top: 0px;
	left: 0px;
}


._hr__ {
	height: 1px;
	width: 100%;
	border-top: solid 1px #eee;
	position: absolute;
	top: 205px;
}

.filmitem {
	background: #a94dc2;
}

.new,
.filmitem,
.apkcache {
	width: 110px;
	position: absolute;
	left: -31px;
	top: 11px;
	padding: 5px 30px;
	color: #fff;
	font-size: 11px;
	font-weight: bold;
	transform: rotate(-45deg);
	transition: transform 2s;
	text-align: center;
	opacity: 0.8;
	z-index: 1;
}


.multitem {
	background: #FF9800;
}

.new,
.multitem,
.apkcache {
	width: 135px;
	position: absolute;
	left: -39px;
	top: 16px;
	padding: 5px 30px;
	color: #fff;
	font-size: 11px;
	font-weight: bold;
	transform: rotate(-45deg);
	transition: transform 2s;
	text-align: center;
	opacity: 0.8;
	z-index: 1;
}


.igritem {
	background: #394556;
}

.new,
.igritem,
.apkcache {
	width: 110px;
	position: absolute;
	left: -31px;
	top: 11px;
	padding: 5px 30px;
	color: #fff;
	font-size: 11px;
	font-weight: bold;
	transform: rotate(-45deg);
	transition: transform 2s;
	text-align: center;
	opacity: 0.8;
	z-index: 1;
}


.softitem {
	background: #2196F3;
}

.new,
.softitem,
.apkcache {
	width: 135px;
	position: absolute;
	left: -39px;
	top: 16px;
	padding: 5px 30px;
	color: #fff;
	font-size: 11px;
	font-weight: bold;
	transform: rotate(-45deg);
	transition: transform 2s;
	text-align: center;
	opacity: 0.8;
	z-index: 1;
}


.ismod {
	position: absolute;
	background: #ffb951;
	width: 80px;
	bottom: 4px;
	right: -20px;
	transform: rotate(-45deg);
	color: #fff;
	padding: 5px 30px;
	opacity: 0.8;
	z-index: 3;
	font-size: 11px;
	font-weight: bold;
}


.padd5 {
	padding: 5px;
}


.padd3 {
	padding: 3px;
}


.round15 {
	-webkit-border-radius: 15px;
	-moz-border-radius: 15px;
	border-radius: 15px;
}


.cl {
	clear: both;
}


#full-content .item:hover ._hrf__ {
	display: none;
}

._hrf__ {
	height: 1px;
	width: 100%;
	border-top: solid 1px #eee;
	position: absolute;
	top: 240px;
}


#full-content .item_holder {
	display: inline-block;
	width: 300px;
	text-align: center;
}

#full-content .item {
	background: #fff;
	overflow: hidden;
	width: 100% !important;
	position: relative;
	display: inline-block;
	height: auto;
	color: #fff;
	margin-bottom: 0px;
	outline: 1px solid #ddd;
}

#full-content .item:hover {
	background: #ddd;
	cursor: pointer;
	box-shadow: none;
}


#full-content .item .ico_cover {
	opacity: 0.25;
	background-size: cover !important;
	filter: blur(2px);
	-webkit-filter: blur(1px);
	position: absolute;
	width: 130%;
	height: 30%;
	box-shadow: 0px 5px 10px #aaa;
}


#full-content .item:hover .ico_cover {
	opacity: 0.6 !important;
}


#full-content .item:hover ._hr__ {
	display: none;
}


#full-content .item .padd_in {
	padding: 3px 7px;
}


#full-content .item .ico {
	position: relative;
	margin-top: -0px;
}

#full-content .item:hover img {
	border-radius: 10px;
	transition: .4s;
}

#full-content .item img {
	max-width: 200px;
	max-height: 200px;
	width: 95%;
	box-shadow: 0px 3px 3px #ddd;
	border: solid 3px #fff;
	border-radius: 20px;
	margin-top: 0px;
}


.item:hover .border_out_full {
	border: none;
}


.border_out_full {
	border: solid 3px #fff;
	width: calc(300px - 0px);
	height: 180px;
	position: absolute;
	top: 0px;
	left: 0px;
}


#full-content .item .title {
	width: 100%;
	margin-top: 10px;
	overflow: hidden;
	color: #000;
	margin-bottom: 10px;
	text-align: center;
	font-size: 20px;
	font-weight: bold;
	height: 50px;
}

#full-content .item .title .title_in {
	width: 100%;
}


#full-content .item .desc-razv {
	color: #333;
	text-align: left;
	font-size: 11px;
	height: 45px;
	overflow: hidden;
	margin-top: 5px;
}


#full-content .item .stitle {
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
	color: #333;
	text-align: left;
	font-size: 11px;
	height: 35px;
	overflow: hidden;
	margin-top: 5px;
}


#full-content .item .size {
	left: 7px;
	top: 265px;
	font-weight: bold;
}


#full-content .item .date {
	left: 7px;
	top: 240px;
}


#full-content .item .os,
#full-content .item .date,
#full-content .item .star,
#full-content .item .size,
#full-content .item .version {
	font-size: 13px;
}


#full-content .item .os,
#full-content .item .star,
#full-content .item .size,
#full-content .item .date,
#full-content .item .version,
#full-content .item .free {
	position: absolute;
}


#full-content .item .small_text {
	font-size: 11px;
	color: #555;
}


#full-content .item .small_text a {
	font-size: 11px;
	color: #555;
}


#full-content .item .version {
	left: 7px;
	top: 215px;
	color: #000;
	font-weight: bold;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
	width: 160px;
}


#full-content .item .version span {
	color: #3F51B5;

}


#full-content .item .free {
	left: 7px;
	top: 288px;
	text-transform: uppercase;
	color: #03a9f4;
	font-weight: 400;
}


.info-razv-padd {
	text-align: left;
	padding: 10px 5px;
	border-bottom: solid 1px #eee;
	border-top: solid 1px #eee;
}

.info-razv-down {
	margin-top: 5px;
	text-align: left;
	padding: 5px;
}

.full-info-text .fas {
	width: 20px;
	color: #000;
}

.full-info-text .far {
	width: 20px;
	color: #000;
}

.full-info-text .fal {
	width: 20px;
	color: #000;
}

.full-info-text .fab {
	width: 20px;
	color: #000;
}


.dropdown-menu .fas {
	width: 20px;
	color: #fff;
}

.dropdown-menu .far {
	width: 20px;
	color: #fff;
}

.dropdown-menu .fal {
	width: 20px;
	color: #fff;
}

.dropdown-menu .fab {
	width: 20px;
	color: #fff;
}


.acategory {
	font-weight: 400;
	color: #9d9d9d;
	opacity: 0.8;
	padding: 10px 0px;
	position: relative;
	display: block;
}

.acategory a {
	font-weight: 400;
	color: #9d9d9d;
	opacity: 0.8;
}

.acategory a:hover {
	font-weight: 400;
	color: #9d9d9d;
	opacity: 1;
}


.filtr-rinok-table {
	margin-top: 0 !important;
	table-layout: fixed;
	width: 100% !important;
	font-size: 16px;
}


.filtr-rinok-table table th {
	color: #9d9d9d;
}


.filtr-rinok-table table strong {
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
	display: block;
	color: var(--color-primary-p3-light);
	font-weight: 600;
}


.filtr-rinok-table table strong a {
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
	display: block;
	color: var(--color-primary-p3-light);
	font-weight: 700;
}


.filtr-rinok-table table strong a:hover {
	color: var(--color-primary-p3);
}


.filtr-rinok-table .item th {
	color: #9d9d9d;
	padding-right: 15px;
}


.filtr-rinok-desc {
	line-height: 20px;
	font-size: 14px;
	color: #000;
	margin-bottom: 0 !important;
	min-height: 200px;
	margin-top: 10px;
}

.filtr-rinok-time {
	font-size: 13px;
	color: #555;
	margin-top: 15px;
}


.filtr-rinok-dop {
	font-size: 22px;
	color: var(--color-primary-p3-light);
	font-weight: 700;
	margin-bottom: 30px;
	text-decoration: underline;
	text-decoration-color: black;
}


.texthide {
	display: none;
}


.last-rinok {

	display: block;

}


.last-rinok .box {
	cursor: pointer;
	height: 170px;
	position: relative;
	overflow: hidden;
	width: 100%;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	text-align: center;


}

.last-rinok .box img {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	max-width: 155px;
	max-height: 155px;
	margin: auto;
}


.userinfo-left {
	float: left;
	width: 235px;
}

.userinfo-right {
	float: right;
	width: 695px;
}


.item4 {
	width: 100%;
	height: auto;
	overflow: hidden;
	position: relative;
	background-color: rgb(229 255 230) !important;
	-webkit-box-shadow: 0px 0px 13px 0px rgba(82, 63, 105, 0.05);
	box-shadow: 0px 0px 13px 0px rgba(82, 63, 105, 0.05);
	border-radius: 0.25rem;
	text-align: center;
}

.item4:after {
	content: ' ';
	width: 960px;
	height: 925px;
	position: absolute;
	bottom: 76%;
	left: -13px;
	border-radius: 20%;
	background: #fff;
	z-index: 0;
	animation: wave 17s infinite linear;
}

@keyframes wave {
	from {
		-webkit-transform: rotate(0);
		transform: rotate(0);
	}

	from {
		-webkit-transform: rotate(360deg);
		transform: rotate(360deg);
	}
}


/** Copyright (c) 2019 Artem Malcov | https://www.pandoge.com/moduli_i_skripty/modul-statistiki-lightstat-30-dlya-dle **/

.lightstat_main * {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

.lightstat_main *:before,
.lightstat_main *:after {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

.lightstat_main {
	min-width: 230px;
	width: 100%;
	margin: 0 auto;
	font-family: arial;
	box-shadow: 0 4px 10px rgba(0, 0, 0, .1);
	border-radius: 8px;
}

.lightstat_progress {
	width: 100%;
	padding: 0 10px;
}

.lightstat_progress span {
	height: 4px;
	display: block;
	float: left;
}

.lightstat_progress span:nth-of-type(1) {
	border-top-left-radius: 2px;
	border-bottom-left-radius: 2px;
}

.lightstat_progress span:nth-last-of-type(1) {
	border-top-right-radius: 2px;
	border-bottom-right-radius: 2px;
}

.lightstat_body {
	background: #242043;
	border-radius: 8px 8px 0 0;
	padding: 15px 0 1px 0;
}

.lightstat_body.border_none_user {
	border-radius: 8px;
}

.lightstat_body .result_numb div {
	padding: 0 10px 11px 10px;
	color: #bbb;
	font-size: 14px;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, .6);
}

.lightstat_body .result_numb div span:nth-of-type(1) {
	width: 8px;
	height: 8px;
	display: inline-block;
	border-radius: 99px;
	margin: 4px 10px 0 0;
	vertical-align: top;
	box-shadow: 0px -1px 1px rgba(0, 0, 0, .6);
}

.lightstat_body .result_numb div span:nth-of-type(2) {
	float: right;
	color: #fff;
}

.lightstat_body .result_numb .lightstat_user span:nth-of-type(1) {
	border: 2px solid #d9823b;
}

.lightstat_body .result_numb .lightstat_guest span:nth-of-type(1) {
	border: 2px solid #a963b9;
}

.lightstat_body .result_numb .lightstat_bot span:nth-of-type(1) {
	border: 2px solid #36a7a5;
}

.lightstat_user_circle {
	background: #d9823b;
}

.lightstat_guest_circle {
	background: #a963b9;
}

.lightstat_bot_circle {
	background: #36a7a5;
}

.lightstat_is {
	color: #fff;
	font-size: 10px;
	text-transform: uppercase;
	padding: 18px 0 15px 28px;
	display: block;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, .6);
}

.lightstat_user_list {
	background: #fff;
	border-radius: 0 0 8px 8px;
	position: relative;
}

.lightstat_pandoge_com {
	width: 8px;
	height: 20px;
	position: relative;
	background: #222;
	display: block;
	position: absolute;
	top: 0;
	right: 20px;
	transition: .2s;
}

.lightstat_pandoge_com:after {
	content: "";
	position: absolute;
	left: 0;
	bottom: 0;
	width: 0;
	height: 0;
	border-bottom: 4px solid #d1d5d8;
	border-left: 4px solid transparent;
	border-right: 4px solid transparent;
}

.lightstat_pandoge_com:hover {
	height: 24px;
	transition: .2s;
}

.lightstat_user_list_title {
	color: #242043;
	font-size: 10px;
	text-transform: uppercase;
	padding: 18px 0 17px 28px;
	display: block;
	font-weight: 700;
}

.lightstat_user_list_item {
	padding: 0 10px 20px 10px;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-ms-flex-wrap: wrap;
	-webkit-flex-wrap: wrap;
	flex-wrap: wrap;
	-ms-flex-pack: justify;
	-webkit-justify-content: space-between;
	justify-content: space-between;
}

.lightstat_user_list_item a {
	text-decoration: none !important;
	color: #242043;
}

.lightstat_user_list_item_avatar {
	background-size: cover !important;
	border-radius: 99px;
	width: 34px;
	height: 34px;
	display: block;
}

.lightstat_user_list_item_avatar:hover {
	opacity: .8;
}

.lightstat_user_list_item_info {
	font-size: 12px;
	font-weight: 700;
	width: calc(100% - 34px);
	padding: 1px 0 0 10px;
}

.lightstat_user_list_item_info span {
	display: block;
	font-weight: 400;
	padding: 2px 0 0 0;
	color: #888;
}

.lightstat_user_list_item_info span.online {
	color: #0e8952;
}

.lightstat_user_list_item_info a:hover {
	text-decoration: underline !important;
}

.full_list_visit {
	margin: auto;
	color: #242043;
	font-size: 10px;
	text-transform: uppercase;
	display: block;
	font-weight: 700;
	width: 120px;
	text-align: center;
	background: #fff;
	border-radius: 99px;
	height: 26px;
	line-height: 26px;
	border: 1px solid #888;
	box-shadow: 0 2px 4px rgba(0, 0, 0, .1);
}

.full_list_visit:hover {
	box-shadow: 0 4px 8px rgba(0, 0, 0, .2);
}

.full_list_visit_bg {
	position: absolute;
	bottom: 0;
	left: 0;
	right: 0;
	border-radius: 0 0 8px 8px;
	z-index: 2;
	background: -moz-linear-gradient(bottom, rgba(255, 255, 255, .1) 0, rgba(255, 255, 255, 1) 100%);
	background: -webkit-linear-gradient(bottom, rgba(255, 255, 255, .1) 0, rgba(255, 255, 255, 1) 100%);
	background: linear-gradient(to bottom, rgba(255, 255, 255, .1) 0, rgba(255, 255, 255, 1) 100%);
	padding: 20px 0;
}

.lightstat_user_list_item {
	display: none;
}

.lightstat_user_list .lightstat_user_list_item:nth-of-type(1),
.lightstat_user_list .lightstat_user_list_item:nth-of-type(2),
.lightstat_user_list .lightstat_user_list_item:nth-of-type(3) {
	display: flex;
}

.lightstat_light_theme .lightstat_body {
	background: #f1f5f7;
}

.lightstat_light_theme .lightstat_body {
	background: #f1f5f7;
}

.lightstat_light_theme .lightstat_user_list_item a {
	color: #030304;
}

.lightstat_light_theme .lightstat_user_list_title {
	color: #030304;
}

.lightstat_light_theme .lightstat_body .result_numb div span:nth-of-type(2) {
	color: #283e52;
}

.lightstat_light_theme .lightstat_body .result_numb div {
	color: #030304;
	text-shadow: none;
}

.lightstat_light_theme .lightstat_is {
	text-shadow: none;
	color: #283e52;
}

.lightstat_light_theme .lightstat_body .result_numb .lightstat_user span:nth-of-type(1) {
	border: 2px solid #0bb1d6;
	box-shadow: none;
}

.lightstat_light_theme .lightstat_body .result_numb .lightstat_guest span:nth-of-type(1) {
	border: 2px solid #ff6d00;
	box-shadow: none;
}

.lightstat_light_theme .lightstat_body .result_numb .lightstat_bot span:nth-of-type(1) {
	border: 2px solid #345471;
	box-shadow: none;
}

.lightstat_light_theme .lightstat_user_circle {
	background: #0bb1d6;
}

.lightstat_light_theme .lightstat_guest_circle {
	background: #ff6d00;
}

.lightstat_light_theme .lightstat_bot_circle {
	background: #345471;
}


.vhod-akk {


	width: 300px;
	text-align: center;
	margin: auto;
}


.vhod-akk .card-title {
	color: #000;
	font-size: 18px;
	margin-top: 10px;
}


.pfoto {

	width: 125px;
	height: 125px;
	object-fit: cover;
	border-radius: 50%;

}


#dle-speedbar {
	margin: 0 !important;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
	display: block;
}


.mfp-close:hover,
.mfp-close:focus {
	opacity: 1;
}


.modal-body .mfp-close {
	color: #333;
}


button.mfp-close,
button.mfp-arrow {
	overflow: visible;
	cursor: pointer;
	background: transparent;
	border: 0;
	-webkit-appearance: none;
	display: block;
	outline: none;
	padding: 0;
	z-index: 1046;
	box-shadow: none;
	touch-action: manipulation;
}


.mfp-close {
	width: 44px;
	height: 44px;
	line-height: 44px;
	position: absolute;
	right: 0;
	top: 0;
	text-decoration: none;
	text-align: center;
	opacity: 0.65;
	padding: 0 0 18px 10px;
	color: #FFF;
	font-style: normal;
	font-size: 28px;
	font-family: Arial, Baskerville, monospace;
}

.mfp-close,
.mfp-arrow,
.mfp-preloader,
.mfp-counter {
	-webkit-user-select: none;
	-moz-user-select: none;
	user-select: none;
}


.editnews-my {

	color: #607D8B;
	text-decoration: underline;
}


.search-main {
	background: #fff;
	margin-top: -10px;
	padding-top: 10px;
	padding-bottom: 10px;
}


.search-main-sub {
	background: #e0e0e0;
	padding-top: 10px;
	background-color: #fff6a5;
	transition: .3s;
	background-image: repeating-linear-gradient(-45deg, rgba(82, 91, 171, 0.25), rgba(82, 91, 171, 0.25) 1px, transparent 1px, transparent 6px) !important;
	background-size: 8px 8px !important;
}


.main-sliders-rate {
	height: 42px;
}

.main-sliders-rate a {
	position: relative;
	display: block;
	width: 50%;
	height: 42px;
	float: left;
	/*text-indent: 44px;*/
	line-height: 42px;
	font-size: 13px;
	font-weight: bold;
	text-decoration: none;
}

.main-sliders-rate a span {
	position: relative;
	display: block;
	width: 20px;
	margin: 0 auto;
	padding-left: 14px;
}

.main-sliders-rate a svg {
	position: absolute;
	width: 18px;
	height: 17px;
}

.main-sliders-rate a:nth-of-type(1) {
	background: #f5f7f5;
	color: #71ce3f;
}

.main-sliders-rate a:nth-of-type(1):hover {
	background: #71ce3f;
	color: #FFF;
}

.main-sliders-rate a:nth-of-type(1) svg {
	fill: #70cd3f;
	top: 12px;
	left: -10px;
}

.main-sliders-rate a:nth-of-type(1):hover svg {
	fill: #FFF;
}

.main-sliders-rate a:nth-of-type(2) {
	background: #e7e5e5;
	color: #ba3636;
}

.main-sliders-rate a:nth-of-type(2):hover {
	background: #b93636;
	color: #FFF;
}

.main-sliders-rate a:nth-of-type(2) svg {
	fill: #ba3636;
	top: 14px;
	left: -10px;
}

.main-sliders-rate a:nth-of-type(2):hover svg {
	fill: #FFF;
}


.f-com-boxs div {
	margin-right: 5px;
	color: #2196f3;
}

.f-com-boxs i {
	margin-right: 5px;
	color: #2196f3;
}

.f-com-boxs i:hover {
	color: #673ab7;
}


.bold {
	font-weight: bold;
}


button:active,
button:focus {
	outline: none !important;
}

button::-moz-focus-inner {
	border: 0 !important;
}

:focus {
	outline-style: none;
	outline-width: 0px !important;
	outline-color: none !important;
}


table.offers.redesigned .price,
table.offers.redesigned.userobserved-list .price,
listHandler table.offers.redesigned .price {
	font-size: 16px;
	line-height: 1.25;
}

table.offers.redesigned .price strong,
table.offers.redesigned.userobserved-list .price strong,
listHandler table.offers.redesigned .price strong {
	font-weight: 500;
}

table.offers.redesigned .thumb.scale4,
table.offers.redesigned.userobserved-list .thumb.scale4,
listHandler table.offers.redesigned .thumb.scale4 {
	position: relative;
	width: 216px;
	height: 152px;
	line-height: 152px;
	display: flex;
	align-items: center;
	justify-content: center;
	overflow: hidden;
}

table.offers.redesigned .thumb.scale4.nophoto,
table.offers.redesigned.userobserved-list .thumb.scale4.nophoto,
listHandler table.offers.redesigned .thumb.scale4.nophoto {
	border: 0;
	background: #f9f9f9;
}

table.offers.redesigned .thumb.scale4 img,
table.offers.redesigned.userobserved-list .thumb.scale4 img,
listHandler table.offers.redesigned .thumb.scale4 img {
	width: 100%;
	max-width: none;
	max-height: none;
}

@supports (-o-object-fit: cover) or (object-fit: cover) {

	table.offers.redesigned .thumb.scale4 img,
	table.offers.redesigned.userobserved-list .thumb.scale4 img,
	listHandler table.offers.redesigned .thumb.scale4 img {
		height: 100%;
		object-fit: scale-down;
	}
}

table.offers.redesigned .space h3,
table.offers.redesigned.userobserved-list .space h3,
listHandler table.offers.redesigned .space h3 {
	font-size: 20px;
	line-height: 1.2;
}

table.offers.redesigned .space h3 a,
table.offers.redesigned.userobserved-list .space h3 a,
listHandler table.offers.redesigned .space h3 a {
	background-color: transparent;
	transition: all 0.2s;
}


table.offers.redesigned .offer-wrapper .thumb.scale4:before {
	content: "";
	position: absolute;
	z-index: 1;
	top: 100%;
	left: 0;
	right: 0;
	box-shadow: 0 0 90px 20px rgba(0, 0, 0, .6);
}


table.offers.redesigned .offer-wrapper .thumb.scale4:after {
	content: "";
	position: absolute;
	width: 100%;
	height: 100%;
	top: 0;
	left: 0;
	background: transparent;
	-webkit-transition: background .3s ease;
	-moz-transition: background .3s ease;
	-o-transition: background .3s ease;
	transition: background .3s ease;
}


table.offers.redesigned .offer-wrapper:hover .thumb.scale4:after {
	background: rgba(0, 0, 0, .16);
}


table.offers.redesigned .space h3 strong,
table.offers.redesigned.userobserved-list .space h3 strong,
listHandler table.offers.redesigned .space h3 strong {
	font-weight: 400;
}

table.offers.redesigned tr .observelinkinfo [data-icon^=star],
table.offers.redesigned.userobserved-list tr .observelinkinfo [data-icon^=star],
listHandler table.offers.redesigned tr .observelinkinfo [data-icon^=star] {
	color: #002f34;
	font-size: 22px;
}

table.offers.redesigned .offer,
table.offers.redesigned.userobserved-list .offer,
listHandler table.offers.redesigned .offer {
	border-bottom: none;
	padding: 6px 0;
	height: auto;
	background: none;
}

table.offers.redesigned .offer-job .title-cell .space,
table.offers.redesigned.userobserved-list .offer-job .title-cell .space,
listHandler table.offers.redesigned .offer-job .title-cell .space {
	display: flex;
	flex-direction: column;
	min-height: 100%;
}

table.offers.redesigned .offer-job .title-cell .space .list-item__price,
table.offers.redesigned.userobserved-list .offer-job .title-cell .space .list-item__price,
listHandler table.offers.redesigned .offer-job .title-cell .space .list-item__price {
	margin-top: auto;
}

table.offers.redesigned .offer-wrapper,
table.offers.redesigned.userobserved-list .offer-wrapper,
listHandler table.offers.redesigned .offer-wrapper {
	padding: 8px;
	background: #fff;
	box-shadow: rgba(0, 0, 0, 0.04) 0px 2px 4px 0px;
	transition: all 0.2s;
	box-sizing: border-box;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	-ms-border-radius: 4px;
	-o-border-radius: 4px;
	border-radius: 4px;
}


table.offers.redesigned .offer-wrapper:hover {
	box-shadow: 0 2px 10px 0 rgba(0, 0, 0, .25);
}


table.offers.redesigned .offer-wrapper>table.fixed,
table.offers.redesigned.userobserved-list .offer-wrapper>table.fixed,
listHandler table.offers.redesigned .offer-wrapper>table.fixed {
	height: 144px;
}

table.offers.redesigned .offer-logo a,
table.offers.redesigned.userobserved-list .offer-logo a,
listHandler table.offers.redesigned .offer-logo a {
	color: #959595;
	font-size: 12px;
}

table.offers.redesigned .offer-logo a:hover,
table.offers.redesigned.userobserved-list .offer-logo a:hover,
listHandler table.offers.redesigned .offer-logo a:hover {
	text-decoration: none;
}

table.offers.redesigned .offer-logo img,
table.offers.redesigned.userobserved-list .offer-logo img,
listHandler table.offers.redesigned .offer-logo img {
	max-height: 80px;
	max-width: 120px;
	display: inline-block;
}

table.offers.redesigned .offer-logo__title,
table.offers.redesigned.userobserved-list .offer-logo__title,
listHandler table.offers.redesigned .offer-logo__title {
	display: inline-block;
	vertical-align: middle;
	margin: 0 5px;
}

table.offers.redesigned .offer .photo-cell,
table.offers.redesigned.userobserved-list .offer .photo-cell,
listHandler table.offers.redesigned .offer .photo-cell {
	width: 216px;
}

table.offers.redesigned .offer .title-cell,
table.offers.redesigned.userobserved-list .offer .title-cell,
listHandler table.offers.redesigned .offer .title-cell {
	box-sizing: border-box;
	padding-top: 0;
}

table.offers.redesigned .offer .bottom-cell,
table.offers.redesigned.userobserved-list .offer .bottom-cell,
listHandler table.offers.redesigned .offer .bottom-cell {
	height: 22px;
	padding-bottom: 10px;
}

table.offers.redesigned .offer .bottom-cell [data-icon],
table.offers.redesigned.userobserved-list .offer .bottom-cell [data-icon],
listHandler table.offers.redesigned .offer .bottom-cell [data-icon] {
	display: none;
}

table.offers.redesigned .offer .bottom-cell .breadcrumb+.breadcrumb span:before,
table.offers.redesigned.userobserved-list .offer .bottom-cell .breadcrumb+.breadcrumb span:before,
listHandler table.offers.redesigned .offer .bottom-cell .breadcrumb+.breadcrumb span:before {
	content: '';
	width: 3px;
	height: 1px;
	line-height: 1px;
	display: inline-block;
	vertical-align: middle;
	background: #406367;
	margin-right: 3px;
}

table.offers.redesigned .offer .bottom-cell .breadcrumb span,
table.offers.redesigned.userobserved-list .offer .bottom-cell .breadcrumb span,
listHandler table.offers.redesigned .offer .bottom-cell .breadcrumb span {
	font-size: 12px;
	font-weight: 400;
	color: #406367;
	line-height: 1;
	display: inline-block;
	margin-top: 0;
}

table.offers.redesigned .offer .bottom-cell .breadcrumb:last-child span,
table.offers.redesigned.userobserved-list .offer .bottom-cell .breadcrumb:last-child span,
listHandler table.offers.redesigned .offer .bottom-cell .breadcrumb:last-child span {
	margin-right: 0;
}

table.offers.redesigned .offer .bottom-cell .breadcrumb--job-type span,
table.offers.redesigned.userobserved-list .offer .bottom-cell .breadcrumb--job-type span,
listHandler table.offers.redesigned .offer .bottom-cell .breadcrumb--job-type span {
	margin-right: 8px;
}

table.offers.redesigned .offer .list-item__price,
table.offers.redesigned.userobserved-list .offer .list-item__price,
listHandler table.offers.redesigned .offer .list-item__price {
	font-size: 16px;
	padding: 10px 0 0 0;
}

table.offers.redesigned .offer .observelinkinfo,
table.offers.redesigned.userobserved-list .offer .observelinkinfo,
listHandler table.offers.redesigned .offer .observelinkinfo {
	padding-bottom: 0;
}

table.offers.redesigned .offer .observelinkinfo .suggesttitleright,
table.offers.redesigned.userobserved-list .offer .observelinkinfo .suggesttitleright,
listHandler table.offers.redesigned .offer .observelinkinfo .suggesttitleright {
	top: 7px;
	margin-right: 20px;
}

table.offers.redesigned .offer .observelinkinfo .suggesttitleright p,
table.offers.redesigned.userobserved-list .offer .observelinkinfo .suggesttitleright p,
listHandler table.offers.redesigned .offer .observelinkinfo .suggesttitleright p {
	display: none;
}

table.offers.redesigned .offer .observelinkinfo:hover .suggesttitleright p,
table.offers.redesigned.userobserved-list .offer .observelinkinfo:hover .suggesttitleright p,
listHandler table.offers.redesigned .offer .observelinkinfo:hover .suggesttitleright p {
	display: inline-block;
}

table.offers .space {
	padding: 0 10px;
}

table.offers .title-cell {
	display: block;
}

.tright {
	text-align: right;
}


.jcbRHX {
	display: inline-block;
	vertical-align: top;
	height: 100%;
	transition: opacity 0.3s ease 0s;
	opacity: 1;
	width: 144px;
	margin-right: 15px;
}


.eYPEZX {
	vertical-align: top;
	display: inline-block;
	width: 100%;
	height: 100%;
	box-sizing: border-box;
	position: relative;
}


.dUrmQP {
	position: relative;
	top: 0px;
	left: 0px;
	height: calc(100% - 32px);
	width: 100%;
	transition: fill 200ms ease 0s;
}


.bsRGkV {
	position: absolute;
	top: 0px;
	left: 0px;
	display: block;
	width: 100%;
	height: calc(100% - 32px);
	background-position: center center;
	background-size: 100%;
	background-repeat: no-repeat;
}


.eYPEZX:hover .sc-pzMyG {
	opacity: 1;
}


.bTECAR {
	position: absolute;
	bottom: 0px;
	left: 0;
	font-size: 12px;
	line-height: 1.43;
	font-weight: 600;
	height: 40px;
	width: 100%;
	color: rgb(51, 51, 51);
	white-space: normal;
	text-align: center;
	opacity: 0.8;
	transition: opacity 200ms ease 0s;
}


.container-cat-ico .owl-carousel.owl-drag .owl-item {
	height: 160px;
	margin: 0px auto;
	position: relative
}


.svg-1:hover .dUrmQP {
	fill: #d0eafa;
}


.svg-2:hover .dUrmQP {
	fill: #d7ebf0;
}


.svg-3:hover .dUrmQP {
	fill: #d7f0d7;
}


.svg-4:hover .dUrmQP {
	fill: #f0e6d7;
}

.svg-5:hover .dUrmQP {
	fill: #f0d7f0;
}


.svg-6:hover .dUrmQP {
	fill: #e1d7f0;
}


.jcbRHX .svg-1.selected .dUrmQP {
	fill: #d0eafa;
}


.jcbRHX .svg-2.selected .dUrmQP {
	fill: #d7ebf0;
}


.jcbRHX .svg-3.selected .dUrmQP {
	fill: #d7f0d7;
}


.jcbRHX .svg-4.selected .dUrmQP {
	fill: #f0e6d7;
}

.jcbRHX .svg-5.selected .dUrmQP {
	fill: #f0d7f0;
}


.jcbRHX .svg-6.selected .dUrmQP {
	fill: #e1d7f0;
}


@media only screen and (min-width: 1920px) {
	form.poiskmain input.posikfield {
		width: 448px;
	}
}


.bvDKng {
	color: rgb(133, 133, 133);
}


.col-rinok-right.navbar {
	background-color: #f0f8ff00;
	top: -25px;
	left: 0;
	right: 0;
	z-index: 0;
	transform: translateY(17%);
	position: sticky;
	transition: none;
	transition: transform 0.5s cubic-bezier(0.8, 0.2, 0.2, 0.8);
}


.col-rinok-right.navbar.out {
	transform: none;
	transform: translateY(4%);
}


.vDFIb {
	vertical-align: baseline;
	-webkit-box-align: center;
	align-items: center;
}


.vDFIb span:first-child {
	overflow: visible;
	text-overflow: initial;
}

.khARDW {
	max-width: 100%;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	font-size: inherit;
	font-weight: inherit;
	line-height: inherit;
	color: inherit;
}


.ihwwlI {
	padding-top: 80px;
	padding-bottom: 40px;
	position: relative;
}


.iCAwCk {
	padding-bottom: 32px;
}

.eYGQDi {
	max-width: 960px;
	min-width: 320px;
	width: 100%;
	margin-left: auto;
	margin-right: auto;
	position: relative;
}


.ihwwlI.ihwwlI>*+* {
	margin-top: 80px;
}


.ysDSL {
	max-width: 1066px;
	min-width: 320px;
	width: 100%;
	margin-left: auto;
	margin-right: auto;
	padding-left: 16px;
	padding-right: 16px;
}


.hHGKwK {
	box-sizing: border-box;
	margin: 0px -5px;
	min-width: 0px;
	flex-wrap: wrap;
	display: flex;
}


.iCAwCk::after {
	content: "";
	position: absolute;
	bottom: -1px;
	left: 0px;
	right: 0px;
	height: 1px;
	background: rgb(235, 235, 235);
}


.jWfcsB {
	box-sizing: border-box;
	margin: 0px;
	min-width: 0px;
	width: 20%;
	padding-right: 5px;
	padding-left: 5px;
	position: relative;
	display: flex;
	flex-direction: column;
}

.gGqvRj {
	padding: 5px 0px 4px;
}


.bvDKng {
	color: rgb(133, 133, 133);
}

.cINRQa {
	line-height: 24px;
	font-weight: 400;
	font-size: 14px;
}


.fIGvlW {
	margin-top: 0px;
	margin-bottom: 24px;
}


.hwCkmz:not(:last-child) {
	margin-bottom: 8px;
}


.hwCkmz {
	display: block;
	color: rgb(51, 51, 51);
}


.hwCkmz>span {
	color: inherit;
}

.eTuTmp {
	display: inline-block;
	vertical-align: baseline;
	line-height: 24px;
	font-weight: 400;
	font-size: 14px;
	color: rgb(51, 51, 51);
}

.bwUniB {
	color: rgb(133, 133, 133);
	font-weight: normal;
	font-style: normal;
	font-stretch: normal;
	letter-spacing: normal;
	line-height: 1.5;
	display: block;
	font-size: 0px;
	text-decoration: none;
	cursor: pointer;
	-webkit-tap-highlight-color: transparent;
}

.iEHwIo {
	min-width: 32px;
	font-size: initial;
	border-radius: 50%;
	color: rgb(255, 255, 255);
	background-color: rgb(70, 128, 194);
}


.jOoKFb {
	min-width: 32px;
	font-size: initial;
	border-radius: 50%;
	color: rgb(255, 255, 255);
	background-color: rgb(242, 114, 13);
}


.iNleqm {
	min-width: 32px;
	font-size: initial;
	border-radius: 50%;
	color: rgb(255, 255, 255);
	background-color: rgb(62, 91, 155);
}

.gRAGoJ {
	min-width: 32px;
	font-size: initial;
	border-radius: 50%;
	color: rgb(255, 255, 255);
	background-color: rgb(85, 172, 238);
}


.ebhdRG {
	border-radius: 50%;
	background-color: rgb(255, 255, 255);
	color: rgb(255, 0, 0);
}


.fjwdNm {
	width: auto;
}

.UnJMN {
	margin: 0px;
	padding: 0px;
	list-style-type: none;
	display: flex;
	font-size: 0px;
}


.ectcwZ {
	-webkit-box-pack: start;
	justify-content: flex-start;
	margin-bottom: 0px;
}

.ectcwZ {
	display: flex;
	flex-direction: row;
	margin-bottom: 40px;
}


.ysDSL .sc-fzoXzr {
	margin-bottom: 16px;
}

.eOBTWA {
	font-size: 14px;
	line-height: 1.33;
	letter-spacing: 0.2px;
}


.iLAGzl svg {
	display: block;
	width: 100%;
	height: auto;
}


.iLAGzl {
	display: inline-block;
	vertical-align: top;
	width: 135px;
	height: 40px;
	font-size: 0px;
	overflow: hidden;
}


.iLAGzl:last-child {
	margin-left: 8px;
}

.ysDSL .sc-pcJja {
	margin-top: 0px;
}


.EymPb {
	white-space: nowrap;
	color: rgb(133, 133, 133);
}

.cmjCky {
	display: block;
	line-height: 16px;
	font-weight: 400;
	font-size: 14px;
	letter-spacing: 0.2px;
	color: rgb(51, 51, 51);
}


.hjiATY:not(:last-child) {
	margin-right: 5px;
}


.flrnRv {
	padding: 15px 0px;
	position: relative;
	display: block;
}


.hEqrKK {
	display: inline-block;
	vertical-align: baseline;
	line-height: 16px;
	font-weight: 400;
	font-size: 12px;
	letter-spacing: 0.2px;
	color: rgb(51, 51, 51);
	height: 16px;
}


.iQLfDY {
	color: rgb(112, 146, 254);
	font-weight: normal;
	font-style: normal;
	font-stretch: normal;
	font-size: 12px;
	line-height: 1.33;
	letter-spacing: 0.2px;
}


.hEqrKK:not(:last-child)::after {
	content: "·";
	margin: 0px 4px;
	color: rgb(133, 133, 133);
}


.date-locat {
	padding: 0;
	list-style: none;
	font-size: 12px;
	color: #406367;
	line-height: 1.17;
	margin-bottom: 10px;
}


.date-locat li {
	display: inline-block;
	max-width: 100%;
	overflow: hidden;
	white-space: nowrap;
	vertical-align: top;
	text-overflow: ellipsis;
	-o-text-overflow: ellipsis;
}


.fav-add-full {
	position: relative;
}


.fav-add-full .favmod {
	font-size: 16px;
}


.fav-add-full .favmod .favmod-add {
	display: block;
	color: #fff;
}


.fav-add-full .favmod .favmod-unset {
	display: none;
}


.fav-add-full .favmod.active .favmod-add {
	display: none;
}


.fav-add-full .favmod.active .favmod-unset {
	display: block;
	color: red;
}


.main-rinok .offerobserve:hover .favmod-unset .pdingtop9 {
	color: #dc3545;
}


.main-rinok .offerobserve:hover .favmod-add .pdingtop9 {
	color: red;
}


.fav-add {
	right: 15px;
	bottom: 20px;
	position: absolute;
}

.fav-add .favmod {
	font-size: 16px;
}

.fav-add a:hover .favmod-add {
	opacity: 0.6 !important;
}

.fav-add a:hover .favmod-unset {
	opacity: 0.6 !important;
}


.fav-add .favmod .favmod-add {
	display: block;
	color: black;
	opacity: 1;
}


.fav-add .favmod .favmod-unset {
	display: none;
}


.fav-add .favmod.active .favmod-add {
	display: none;
}


.fav-add .favmod.active .favmod-unset {
	display: block;
	color: red;
	opacity: 1;
}


.rel {
	position: relative;
}

.main-top .owl-carousel .owl-item img,
.main-mobile .owl-carousel .owl-item img,
.main-content .owl-carousel .owl-item img,
.main-pc .owl-carousel .owl-item img {
	cursor: pointer;
}


.page__container {
	width: 100%;
	min-width: 320px;
	margin: 0 auto;
	box-sizing: border-box;
	overflow: hidden;
}


.order-block {
	display: none;
}


.counter {
	display: flex;
	width: 90px;
	height: 32px;
	align-items: center;
	justify-content: space-between;
	border: 1px solid #ccc;
	box-sizing: border-box;
}



.page__title {
	font-size: 26px;
	font-weight: bold;
	line-height: 26px;
	text-transform: uppercase;
	margin: 15px 0;
	position: relative;
	width: 100%;
	letter-spacing: 1.2px;
	color: #32373E;
	text-align: center;
}

.shadow-title {
	position: relative;
	z-index: 1;
}



.cart__list {
	margin-bottom: 15px;
}


.cart-list__empty {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 30vh;
}


.cart-list__empty-content {
	text-align: center;
}


.contacts {
	width: 100%;
	min-width: 320px;
	margin: 0 auto;
	padding: 0 20px;
	box-sizing: border-box;
	overflow: hidden;
	justify-content: center;
}

@media (min-width:768px) {
	.contacts {
		padding: 0;
		width: 720px;
	}
}

@media (min-width:1260px) {
	.contacts {
		width: 1056px;
	}
}

.contacts__part {
	text-align: center;
}

.contacts__part:last-child {
	margin-right: 0px;
	display: flex;
	flex-wrap: wrap;
	justify-content: center;
	width: 100%;
}

.contacts__subtitle {
	font-size: 18px;
	line-height: 22px;
	margin: 0;
	margin-bottom: 20px;
	width: 100%;
}

.contacts__item {
	margin-bottom: 25px;
}

.contacts__label {
	font-size: 15px;
	line-height: 18px;
	margin-bottom: 8px;
	color: #7b8084;
}

.contacts__label_title-style {
	font-size: 18px;
	line-height: 22px;
	color: #32373e;
}

.contacts__value {
	font-size: 18px;
	line-height: 22px;
}

.contacts__value a {
	color: inherit;
	text-decoration: none;
}

.contacts__value a:hover {
	color: #0D0DA0;
}

.contacts__value_grey {
	color: #7b8084;
	font-size: 15px;
}

.contacts__value_social {
	display: flex;
	justify-content: center;
}

.contacts__input {
	margin-bottom: 30px;
}

.contacts__button {
	margin: 0 auto;
	margin-top: 50px;
	margin-bottom: 20px;
}

.contacts__button button {
	padding: 10px 10px;
}

.contacts__item_requisites {
	margin-top: 20px;
	margin-bottom: 48px;
	order: -1;
}

@media (min-width:768px) {
	.contacts {
		display: flex;
		justify-content: space-between;
	}

	.contacts__item_requisites {
		order: 1;
		margin: 0;
	}

	.contacts__part {
		width: 50%;
		max-width: 290px;
		box-sizing: border-box;
		text-align: left;
	}

	.contacts__part:first-child {
		order: 2;
		padding-right: 25px;
	}

	.contacts__part:last-child {
		order: 1;
		padding-left: 25px;
	}

	.contacts__value_social {
		justify-content: flex-start;
	}

	.contacts__input {
		margin-bottom: 40px;
	}
}

@media (min-width:1260px) {
	.contacts {
		justify-content: center;
	}

	.contacts__part:last-child {
		margin-right: 200px;
	}

	.contacts__subtitle {
		margin-bottom: 30px;
	}
}

textarea,
input[type="text"],
input[type="button"],
input[type="search"] {
	-webkit-appearance: none;
}

.input {
	position: relative;
	text-align: left;
}

.input__input {
	background: #fff !important;
	width: 100%;
	min-height: 35px;
	padding: 0;
	border: none;
	border-bottom: 1px solid #7b8084;
	border-radius: 0;
	resize: none;
	outline: none;
	font-size: 18px;
	line-height: 35px;
	color: #32373e;
}

.input__input::-webkit-input-placeholder {
	color: #A2A6A9;
}

.input__input:-ms-input-placeholder {
	color: #A2A6A9;
}

.input__input::-ms-input-placeholder {
	color: #A2A6A9;
}

.input__input::placeholder {
	color: #A2A6A9;
}

.input__input::-ms-clear {
	display: none;
}

.input__input:-ms-input-placeholder {
	color: #A2A6A9;
}

.input__label {
	width: 100%;
	font-size: 13px;
	line-height: 16px;
	color: #32373e;
	font-weight: bold;
}


.input_radio .input__input:checked+.input__label:after {
	content: '';
	background-color: #32373e;
}





.input_radio .input__input {
	position: relative;
    width: 24px;
    height: 24px;
    border: 1px solid #32373e;
    border-radius: 50%;
}



.input_radio .input__error {
	bottom: -26px;
}

.input_checkbox {
	padding-bottom: 5px;
}

.input_checkbox .input__input {
	display: none;
}

.input_checkbox .input__input:checked+.input__label:after {
	opacity: 1;
}

.input_checkbox .input__label {
	position: relative;
	display: inline-block;
	font-size: 13px;
	line-height: 16px;
	padding-left: 30px;
	cursor: pointer;
	color: #7b8084;
}

.input_checkbox .input__label:before {
	content: '';
	box-sizing: border-box;
	position: absolute;
	top: 50%;
	left: 0;
	width: 20px;
	height: 20px;
	border: 1px solid #7b8084;
	-webkit-transform: translateY(-10px);
	transform: translateY(-10px);
}

.input_checkbox .input__label:after {
	content: '';
	box-sizing: border-box;
	position: absolute;
	top: calc(50% + 6px);
	left: 4px;
	width: 13px;
	height: 9px;
	background-image: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/check-box-arrow.svg");
	background-repeat: no-repeat;
	background-size: cover;
	-webkit-transform: translateY(-10px);
	transform: translateY(-10px);
	opacity: 0;
	transition: 0.2s;
}

.input_checkbox .input__error {
	bottom: -26px;
}

.input_file {
	display: flex;
	align-items: center;
}

.input_file .input__input {
	display: none;
}

.input_file .input__label {
	font-size: 18px;
	cursor: pointer;
}

.input_phone .input__select {
	width: 30%;
	max-width: 115px;
	margin-right: auto;
}

.input_phone .input__wrapper {
	width: 67%;
	position: relative;
}

.input__preview {
	width: 60px;
	height: 60px;
	background: #7b8084;
	margin-right: 20px;
}

.input__preview img {
	max-width: 100%;
	max-height: 100%;
	-o-object-fit: contain;
	object-fit: contain;
}

.input__description {
	margin-left: 30px;
	margin-top: 12px;
	font-size: 12px;
	line-height: 18px;
	color: #7b8084;
	font-style: italic;
}

.input__error {
	position: absolute;
	top: 100%;
	left: 0;
	font-size: 12px;
	color: #b2001a;
}

.input__warning {
	position: absolute;
	top: 100%;
	left: 0;
	font-size: 12px;
	color: #32373e;
}

.input__warning a {
	color: #32373e;
}

.input_required {
	position: relative;
}

.input_required:after {
	content: '*';
	position: absolute;
	top: 10px;
	right: 0;
	color: #7b8084;
	font-size: 18px;
}

.input__search-select.input_required:after {
	display: none;
}

.input_error .input__input {
	border-color: #b2001a;
}

.input_error .input__label {
	color: #b2001a;
}

.input_error:after {
	color: #b2001a;
}

.delivery__list {
	display: flex;
	flex-wrap: wrap;
	justify-content: center;
	margin-top: 30px;
	max-width: 500px;
	margin: 0 auto;
}

.delivery__item {
	width: 100%;
	max-width: 500px;
	margin-bottom: 25px;
}

.delivery__title {
	margin-bottom: 20px;
	font-size: 18px;
	line-height: 25px;
}

.delivery__text {
	margin: 0;
	font-size: 15px;
	line-height: 20px;
	color: #7B8084;
}

.delivery__text_black {
	color: #32373e;
	margin-top: 15px;
	margin-bottom: 10px;
}

.delivery__link {
	display: block;
	line-height: 25px;
	margin-bottom: 5px;
	color: #32373e;
	text-decoration: none;
	transition: 0.2s;
	font-size: 15px;
	cursor: pointer;
}

.delivery__link:hover {
	color: #0D0DA0;
}

.delivery__baselink {
	display: block;
	line-height: 25px;
	margin-bottom: 5px;
	transition: 0.2s;
	font-size: 15px;
	cursor: pointer;
}

.delivery__subtitle {
	font-size: 15px;
}

.delivery__description {
	max-width: 500px;
	margin: 0 auto;
	text-align: left;
	font-size: 15px;
	line-height: 20px;
}

@media (min-width:768px) {
	.delivery__item {
		width: 50%;
		margin-bottom: 65px;
	}

	.delivery__text,
	.delivery__title {
		max-width: 215px;
	}
}

@media (min-width:1260px) {
	.delivery__list {
		justify-content: space-between;
		max-width: 100%;
	}

	.delivery__item {
		width: 230px;
	}
}


.cart__discount {
	margin-bottom: 45px;
}

.cart__discount__warning {
	display: block;
	font-size: 12px;
	line-height: 16px;
}

@media (min-width:768px) {


	.cart__footer {
		display: flex;
		justify-content: space-between;
        margin-top: 35px;
	}

	.cart__discount {
		width: 420px;
	}
}

@media (min-width:1260px) {
	.cart__discount {
		width: 625px;
	}
}

.cart-entity__list {
	margin-bottom: 25px;
}

@media (min-width:768px) {
	.cart-entity__list {
		margin-bottom: 40px;
	}

	.cart-entity__footer {
		display: flex;
		justify-content: flex-end;
	}
}

.favorite {
	padding: 0;
	background-color: transparent;
	border: none;
	outline: none;
	cursor: pointer;
}

.favorite svg {
	fill: transparent;
	stroke: #525d66;
	transition: 0.3s;
}

.favorite_active svg {
	fill: #525d66;
}

.cart-list__header {
	display: none;
}

.cart-list__empty {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 30vh;
}

.cart-list__empty-content {
	text-align: center;
}

@media (min-width:1260px) {
	.cart-list__header {
		display: flex;
		padding-right: 16px;
		font-size: 0;
        padding: 0px 25px;
        background: #f5f5f5;
	}

	.cart-list__header-data {
		justify-content: flex-start;
	}

	.cart-list__header-item {
		display: inline-block;
		font-size: 16px;
		line-height: 46px;
		text-align: left;
	}

	.cart-list__header-item_name {
		width: 525px;
		text-align: center;
		box-sizing: border-box;
	}

	.cart-list__header-item_price {
		width: 128px;
		text-align: center;
	}

	.cart-list__header-item_counter {
		width: 130px;
        text-align: center;
	}

	.tabs .uliuliahuli-item_total {
		width: 201px;
        text-align: center;
	}

	.cart-list__header-item_discount {
		width: 110px;
	}

	.cart-list_empty .cart-list__header {
		margin-bottom: 0;
		height: 0;
	}

	.cart-list_empty .cart-list__header-item {
		font-size: 0;
	}
}

.cart-discount {
	display: flex;
}

.cart-discount__input {
	margin-right: 20px;
}

.cart-discount__button {
	width: 30px;
	height: 30px;
	padding: 1px 6px;
	margin-top: 6px;
	border: 1px solid #7b8084;
	background-color: transparent;
	outline: none;
}

.cart-discount__button-text {
	display: none;
}

.cart-discount__delete {
	width: 100%;
	padding: 10px 20px;
	background-color: #525d66;
	color: #fff;
	border: 1px solid #525d66;
	text-transform: uppercase;
	font-size: 16px;
	transition: 0.2s;
	cursor: pointer;
	display: inline-block;
	width: 140px;
	margin-top: 10px;
	margin-left: 20px;
	color: #525d66;
	background-color: transparent;
}

.cart-discount__delete:hover {
	color: #525d66;
	background-color: transparent;
}

.cart-discount__delete:hover {
	color: #fff;
	background-color: #525d66;
}

.cart-discount__footnote {
	padding-top: 12px;
	font-size: 12px;
	line-height: 16px;
	color: #32373e;
}

.cart-discount__button-icon svg {
	stroke: #7b8084;
}

@media (min-width:1260px) {
	.cart-discount__button {
		width: auto;
		padding: 0 15px;
		height: 40px;
		margin-top: 0;
	}

	.cart-discount__input {
		margin-top: 4px;
	}

	.cart-discount__button-icon {
		display: none;
	}

	.cart-discount__button-text {
		display: inline-block;
		font-size: 16px;
		line-height: 1;
		color: #7b8084;
		text-transform: uppercase;
	}
}

.cart-total__discount,
.cart-total__total {
	display: flex;
	justify-content: flex-end;
	align-items: center;
}

.cart-total__icon {
	width: 10px;
	height: 15px;
}

.cart-total__discount {
	color: #32373e;
	margin-bottom: 10px;
}

.cart-total__total {
	color: #32373e;
}

.cart-total__title {
	font-size: 16px;
}

.cart-total__value {
	font-size: 24px;
	min-width: 90px;
	text-align: right;
}

.cart-total__value_small {
	font-size: 18px;
	color: #7b8084;
}

.cart-total__value_small .cart-total__currency {
	font-size: 14px;
}

.cart-total__currency {
	font-size: 20px;
}

.cart-total__submit {
	width: 100%;
	padding: 10px 20px;
    background-color:  var(--color-primary-p3-dark);
    border: solid 1px  var(--color-primary-p3-dark);
	color: #fff;
	text-transform: uppercase;
	font-size: 14px;
	transition: 0.2s;
	cursor: pointer;
	margin-top: 30px;
	border-radius: 8px;
}

.cart-total__submit:hover {
	color: #394556;
	background-color: transparent;
}

.cart-total__submit:hover a {
	color: #525d66;
	background-color: transparent;
}

/*.cart-total__submit_basket{
	display:none;}*/

.cart-total__submit a {
	color: #fff;
	text-decoration: none;
}

.cart-total__submit a:hover {
	color: #525d66;
}

.order__need-prepayment+.cart-total__submit {
	margin-top: 0;
}

.cart-total__delivery_text {
	width: 300px;
	font-size: 12px;
	color: #7b8084;
	font-style: italic;
	display: inline-block;
	margin-bottom: 10px;
}

@media (min-width:768px) {
	.cart-total {
		text-align: right;
	}

	.cart-total__title {
		margin-right: 10px;
		font-size: 16px;
		line-height: 22px;
	}

	.cart-total__submit {
		width: 220px;
	}
}

@media (min-width:1260px) {
	.cart-total__submit {
		margin-top: 23px;
	}
}

.cart-item {
	padding-bottom: 30px;
	padding-top: 20px;
	border-bottom: 1px solid #eaecec;
}

.cart-item__grid {
	display: flex;
	flex-wrap: wrap;
	align-items: center;
}

.page__container:first-child .cart-item {
    border: 1px solid #eaecec;
    background: #fff;
	padding-top: 5px;
    padding-bottom: 5px;
    margin-bottom: 10px;
    position: relative;
    border-top-left-radius: 12px;
    border-bottom-right-radius: 12px;
}

.cart-item:last-child {
	margin-bottom: 0;
}

.cart-item__icon {
	height: 10px;
	width: 7px;
}

.cart-item__image {
	display: flex;
	align-items: center;
	justify-content: center;
	position: relative;
	width: 30%;
	min-width: 80px;
	margin-right: 1.5%;
	margin-left: 3.5%;
}

.cart-item__image img {
	display: inline-block;
	max-width: 100%;
	max-height: 100%;
	-o-object-fit: cover;
	object-fit: cover;
}

.cart-item__favorite {
	position: absolute;
	bottom: -3px;
	left: 6px;
}

.cart-item__infobox {
	flex: 1;
}

.cart-item__info {
	position: relative;
}

.cart-item__warning-msg {
	display: none;
}

.cart-item__name {
	margin-bottom: 12px;
	font-size: 13px;
	line-height: 17px;
}

.cart-item__name a {
	text-decoration: none;
	color: #394556;
	font-weight: bold;
}

.cart-item__addressee {
	color: #bdc4c9;
	font-size: 13px;
	line-height: 16px;
}

.cart-item__certificate-edit {
	border: none;
	background-color: transparent;
	padding: 0;
	color: #32373e;
	margin-top: 10px;
	border-bottom: 1px solid rgba(123, 128, 132, 0.6);
	outline: none;
	cursor: pointer;
}

.cart-item__minor {
	position: relative;
}

.cart-item__price {
	color: #7b8084;
	margin-bottom: 20px;
}

.cart-item__price-value {
	font-size: 16px;
	color: #32373e;
}

.cart-item__price-value_old {
	color: #7b8084;
	text-decoration: line-through;
	margin-right: 10px;
}

.cart-item__counter {
	margin-bottom: 20px;
	position: relative;
	max-width: 130px;
    width: 130px;
    margin: auto;
    padding: 0px 20px;
}

.cart-item__counter_gift {
	display: flex;
	width: 90px;
}

.cart-item__counter_gift svg {
	fill: #525d66;
}

.cart-item__counter-warning .counter {
	position: relative;
	border-color: #e23333;
}

.cart-item__counter-warning .counter .counter__button_increment {
	color: #e23333;
	cursor: not-allowed;
}

.cart-item__counter-warning .cart-item__counter-lock {
	display: block;
}

.cart-item__counter-lock {
	position: absolute;
	top: 50%;
	margin-top: -12px;
	right: -30px;
	display: none;
}

.cart-item__counter-lock svg {
	width: 24px;
	height: 24px;
}

.cart-item__discount {
	display: none;
}

.cart-item__total {
	color: #32373e;
	font-size: 16px;
}

.cart-item__total-title {
	display: inline-block;
	margin-right: 5px;
	font-size: 13px;
}

.cart-item__delete {
    position: absolute;
    width: 36px;
    height: 36px;
    right: 0;
    bottom: 1px;
    background: rgb(0 120 172);
    -webkit-border-top-left-radius: 12px;
    -webkit-border-bottom-right-radius: 12px;
    border-top-left-radius: 12px;
    border-bottom-right-radius: 12px;
    z-index: 7;
    font-size: 0px;
	opacity: 0.8;
}

.cart-item__delete:hover {
opacity: 1;
}



.cart-item__delete span {
    width: auto;
    height: auto;
}

.cart-item__delete span:after {
    content: "";
    background-image: url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIxLjkgMjEuOSIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAwIDAgMjEuOSAyMS45IiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KICA8cGF0aCBkPSJNMTQuMSwxMS4zYy0wLjItMC4yLTAuMi0wLjUsMC0wLjdsNy41LTcuNWMwLjItMC4yLDAuMy0wLjUsMC4zLTAuN3MtMC4xLTAuNS0wLjMtMC43bC0xLjQtMS40QzIwLDAuMSwxOS43LDAsMTkuNSwwICBjLTAuMywwLTAuNSwwLjEtMC43LDAuM2wtNy41LDcuNWMtMC4yLDAuMi0wLjUsMC4yLTAuNywwTDMuMSwwLjNDMi45LDAuMSwyLjYsMCwyLjQsMFMxLjksMC4xLDEuNywwLjNMMC4zLDEuN0MwLjEsMS45LDAsMi4yLDAsMi40ICBzMC4xLDAuNSwwLjMsMC43bDcuNSw3LjVjMC4yLDAuMiwwLjIsMC41LDAsMC43bC03LjUsNy41QzAuMSwxOSwwLDE5LjMsMCwxOS41czAuMSwwLjUsMC4zLDAuN2wxLjQsMS40YzAuMiwwLjIsMC41LDAuMywwLjcsMC4zICBzMC41LTAuMSwwLjctMC4zbDcuNS03LjVjMC4yLTAuMiwwLjUtMC4yLDAuNywwbDcuNSw3LjVjMC4yLDAuMiwwLjUsMC4zLDAuNywwLjNzMC41LTAuMSwwLjctMC4zbDEuNC0xLjRjMC4yLTAuMiwwLjMtMC41LDAuMy0wLjcgIHMtMC4xLTAuNS0wLjMtMC43TDE0LjEsMTEuM3oiIGZpbGw9IiNGRkZGRkYiLz4KPC9zdmc+Cg==);
    background-size: 16px;
    width: 16px;
    height: 16px;
    position: absolute;
    top: 10px;
    right: 10px;
    transition: .2s;
    transform: scale(.7);
}



.cart-item_warning {
	background-color: #fafafa;
	min-width: 320px;
	border-bottom: none;
	padding: 40px 0 100px;
	position: relative;
}

.cart-item_warning .page__container:first-child .cart-item {
	border-top: none;
}

.cart-item_warning__infobox {
	display: flex;
	flex-direction: column;
}

.cart-item_warning .cart-item__warning-msg {
	display: block;
	list-style-type: none;
	padding-left: 0;
	position: absolute;
	left: 20px;
	bottom: 40px;
	margin: 0;
}

.cart-item_warning .cart-item__warning-msg li {
	padding-left: 35px;
	position: relative;
	font-size: 13px;
	line-height: 17px;
}

.cart-item_warning .cart-item__warning-msg li .icon {
	position: absolute;
	left: 0;
	top: -2px;
	vertical-align: middle;
}

.cart-item_warning .cart-item__warning-msg li .icon svg {
	width: 24px;
	height: 24px;
}



@media (min-width:1260px) {
	.cart-item__image {
		width: 25%;
		height: 100px;
		margin-right: 0;
		margin-left: 0;
	}

	.cart-item__info {
	align-items: center;
    display: flex;
    justify-content: space-between;
    flex: 1;
	}

	.cart-item .cart-item__warning-msg {
		padding-left: 20px;
	}

	.cart-item__data {
		display: flex;
		align-items: center;
		flex: 1;
		flex-direction: row;
	}

	.cart-item__data-part {
		display: flex;
	}

	.cart-item__name {
		width: 50%;
		padding-right: 60px;
		box-sizing: border-box;
	}

	.cart-item__price {
		width: 128px;
	}

	.cart-item__price-value {
		display: block;
		width: auto;
	}

	.cart-item__price-value_old {
		margin-right: 0;
	}

	.cart-item__discount {
		display: block;
		line-height: 22px;
		color: #7b8084;
		width: 110px;
	}

	.cart-item__total {
		width: 130px;
		text-align: left;
	}

	.cart-item__total-title {
		display: none;
	}


}

.cart-icon {
	padding: 0;
	background-color: transparent;
	border: none;
	outline: none;
	cursor: pointer;
}

.cart-icon svg {
	fill: #f7f9f8;
	stroke: #2f2f2e;
	stroke-width: 3;
	stroke-miterlimit: 10;
	transition: 0.3s;
}

.cart-icon_popup svg {
	stroke: #22449f;
}

.cart-icon_subscribe svg {
	fill: #2f2f2e;
}

.cart-item-add {
	width: 100%;
	height: 35%;
	position: absolute;
	bottom: 0;
	left: 0;
	right: 0;
	background: #fff;
}

.cart-item-add__wrapper {
	position: absolute;
	height: 100%;
	width: 248px;
	left: calc(50% - 124px);
}

.cart-item-add__close {
	position: absolute;
	top: 0;
	right: 0;
	-webkit-transform: translateX(-50%);
	transform: translateX(-50%);
	cursor: pointer;
}

.cart-item-add__close svg {
	stroke: #000;
}

.cart-item-add__content {
	display: none;
	margin-top: 17px;
	flex-direction: column;
	height: calc(100% - 14px);
	justify-content: space-between;
}

.cart-item-add__content_visible {
	display: flex;
}

.cart-item-add__content svg {
	fill: #f7f9f8;
	stroke: #2f2f2e;
	stroke-width: 3;
	stroke-miterlimit: 10;
	transition: 0.3s;
	align-self: center;
}

.cart-item-add__content.cart-icon_popup svg {
	stroke: #22449f;
}

.cart-item-add__text {
	font-size: 15px;
	margin: 0;
}

.cart-item-add__switcher {
	display: flex;
	margin-top: auto;
}

.cart-item-add__switcher_disabled {
	opacity: 0.5;
	pointer-events: none;
}

.cart-item-add__input {
	box-sizing: border-box;
	width: 50%;
	height: 36px;
	border: 1px solid #545d65;
	text-align: center;
	cursor: pointer;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-bottom: 0;
	padding: 0 5px;
}

.cart-item-add__input:first-child {
	border-radius: 5px 0 0 5px;
	border-right: 0;
}

.cart-item-add__input:last-child {
	border-radius: 0 5px 5px 0;
	border-left: 0;
}

.cart-item-add__input .input__input {
	display: none;
}

.cart-item-add__input .input__input:checked+.input__label:after {
	content: none;
}

.cart-item-add__input .input__label {
	font-size: 13px;
	white-space: nowrap;
	cursor: pointer;
}

.cart-item-add__input .input__label::after,
.cart-item-add__input .input__label::before {
	content: none;
}

.cart-item-add__input_active {
	background: #545d65;
}

.cart-item-add__input_active .input__label {
	color: #fff;
}

.cart-item-add__input_disabled {
	pointer-events: none;
}

@media (min-width:768px) {
	.cart-item-add__wrapper {
		width: 100%;
		left: auto;
	}

	.cart-item-add .input__label {
		font-size: 12px;
	}
}

@media (min-width:1260px) {
	.cart-item-add .input__label {
		font-size: 13px;
	}
}

.counter {
	display: flex;
	width: 90px;
	height: 32px;
	align-items: center;
	justify-content: space-between;
	border: 1px solid #7b8084;
	box-sizing: border-box;
}

.counter__button {
	padding: 0 10px;
	height: 32px;
	background-color: transparent;
	color: #7b8084;
	border: none;
	outline: none;
	cursor: pointer;
}

.counter__value {
	font-size: 16px;
	color: #32373e;
}

.counter_limit {
	border-color: #e23333;
}

.counter_limit .counter__button:last-child {
	color: #e23333;
}

.counter_limit .counter__value {
	color: #e23333;
}


.order__fieldset {
	border: none;
	margin: 0;
	padding: 0;
}

.order__part.disabled {
	opacity: 0.5;
	pointer-events: none;
}

.order__input {
	margin-bottom: 30px;
}

.order__input .v-select .dropdown-toggle .clear {
	display: none;
}

.order__input .v-select .open-indicator {
	padding-bottom: 4px;
}

.order__input .v-select.open .open-indicator:before {
	-webkit-transform: rotate(133deg);
	transform: rotate(133deg);
}

.order__input .v-select .open-indicator:before {
	border-width: 1px 1px 0 0;
}

.order__input .v-select {
	margin-top: 3px;
}

.order__input .v-select .dropdown-toggle {
	border: none;
	border-bottom: 1px solid #7b8084;
	border-radius: 0px;
}

.order__input .v-select .dropdown-menu {
	border: 1px solid #7b8084;
	border-radius: 0px;
	margin-top: -1px;
	padding: 0;
}

.order__input .v-select .vs__selected-options {
	padding-left: 0;
}

.order__input .v-select li>a {
	padding: 9px 20px;
}

.order__input .v-select .dropdown-menu>.highlight>a {
	background: #525d66;
}

.order__input .v-select li {
	height: 40px;
}

.order__input .v-select li .active a {
	height: 40px;
	background: #525d66;
}

.order__input .v-select.single .selected-tag {
	padding-left: 0;
	margin-left: 0;
}

.order__input .v-select input[type=search],
.order__input .v-select input[type=search]:focus {
	padding-left: 0;
}

.order__legend {
	color: #32373e;
	font-size: 18px;
	line-height: 22px;
	margin: 20px 0;
}

.order__paytype {
	display: block;
}

.order__part_paytype {
	display: flex;
	flex-direction: column;
	justify-content: flex-start;
	margin-bottom: 8px;
}

.order__part_paytype .order__input_radio {
	box-sizing: border-box;
	height: 45px;
	line-height: 45px;
	border: 1px solid #7B8084;
	border-radius: 11px;
	margin-bottom: 8px;
}

.order__part_paytype .order__input_radio:hover {
	background: #525D66;
	border-radius: 11px;
}

.order__part_paytype .order__input_radio:hover .input__label {
	color: #fff;
}

.order__part_paytype .order__input_radio .input_radio {
	text-align: center;
	cursor: pointer;
	display: flex;
	align-items: center;
	justify-content: center;
	height: 100%;
}

.order__part_paytype .order__input_radio .input_radio .input__input:checked+.input__label:after {
	content: none;
}

.order__part_paytype .order__input_radio .input_radio .input__label::after,
.order__part_paytype .order__input_radio .input_radio .input__label::before {
	content: none;
}

.order__part_paytype .order__input_radio .order__input_radio-active {
	background: #525D66;
	border-radius: 11px;
}

.order__part_paytype .order__input_radio .order__input_radio-active .input__label {
	color: #fff;
}

.order__part_paytype .order__input_radio .order__input_radio-active .input__label::after {
	content: none;
}

.order__paytype-roboxchange .input__label {
	padding-left: 18px;
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/robokassa.svg") no-repeat;
}

.order__paytype-roboxchange.order__input_radio-active .input__label,
.order__paytype-roboxchange:hover .input__label {
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/robokassa-active.svg") no-repeat;
}

.order__paytype-paypal .input__label {
	padding-left: 22px;
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/paypal.svg") no-repeat;
}

.order__paytype-paypal.order__input_radio-active .input__label,
.order__paytype-paypal:hover .input__label {
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/paypal-active.svg") no-repeat;
}

.order__paytype-applepay .input__label {
	padding-left: 22px;
	line-height: 20px;
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/apple-pay.png") no-repeat;
}

.order__paytype-applepay.order__input_radio-active .input__label,
.order__paytype-applepay:hover .input__label {
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/apple-pay-active.png") no-repeat;
}

.order__paytype-cash .input__label {
	padding-left: 22px;
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/cash.svg") no-repeat;
}

.order__paytype-cash.order__input_radio-active .input__label,
.order__paytype-cash:hover .input__label {
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/cash-active.svg") no-repeat;
}

.order__notice {
	font-size: 12px;
	line-height: 16px;
	color: #32373E;
	margin-top: 2px;
	margin-bottom: 8px;
}

.order__phone_confirmed .input__label {
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/accept.svg") right no-repeat;
	padding-right: 22px;
}

.order__input-sms {
	display: flex;
	align-content: center;
	flex-direction: column-reverse;
}

.order__input-sms .input {
	width: 100%;
}

.order__input-sms_success .input__input {
	background: url(/templates/lifesport/local/templates/lundenilona/static/img/general/icons/accept.svg) right no-repeat;
}

.order__input-adress {
	display: flex;
	align-content: center;
	justify-content: space-between;
}

.order__input-adress .input {
	width: 48%;
}

.order__delivery-price {
	width: 7px;
	height: 9px;
}

.order__delivery-description {
	font-size: 13px;
	color: #a3aaaf;
}

.order__delivery-description a {
	font-size: 13px;
	color: #a3aaaf;
}

.order__delivery-description .pvz-not-selected {
	color: #b2001a;
}

.order__confirm-tel {
	margin-bottom: 30px;
	width: 100%;
}

.order__confirm-btn {
	width: 100%;
	height: 38px;
	font-size: 16px;
	line-height: 18px;
	text-align: center;
	text-transform: uppercase;
	color: #535E67;
	box-sizing: border-box;
	border: 1px solid;
	background: #fff;
	white-space: nowrap;
	border-radius: 5px;
	transition: 0.2s;
	cursor: pointer;
}

.order__confirm-btn:hover {
	background: #535E67;
	color: #fff;
}

.order__confirm-text {
	font-size: 12px;
	line-height: 16px;
	color: #32373E;
	margin-top: 8px;
	margin-bottom: 0;
	display: block;
}

.order__confirm-text_error {
	color: #b2001a;
}

.order__need-prepayment {
	margin-top: 30px;
}

.order__need-prepayment,
.order__need-prepayment a,
.order__possible_delay,
.order__delivery_text,
.order__agreement,
.order__agreement a {
	text-align: right;
	font-size: 13px;
	line-height: 18px;
	color: #7B8084;
}

.order__delivery_text {
	text-align: right;
	margin-top: 0px;
	margin-bottom: 10px;
}

.order__send-repeat {
	border: none;
	cursor: pointer;
	background: none;
	color: #7B8084;
	padding: 0;
}

.order__phone_confirm-enter-active,
.order__phone_confirm-leave-active {
	transition: opacity 3.5s;
}

.order__phone_confirm-enter,
.order__phone_confirm-leave-to {
	opacity: 0;
}

.order__total_info {
	display: none;
}

.order__total_recounted {
	box-sizing: border-box;
	background-color: #fafafa;
	padding: 35px 15px 20px;
	margin: 0 -20px;
}

.order__total_recounted .order__total_info {
	display: block;
	padding: 0 27px 11px 50px;
}

.order__total_recounted .order__total_info-title,
.order__total_recounted .order__total_info-text {
	margin: 0;
}

.order__total_recounted .order__total_info-title {
	font-size: 14px;
	margin-bottom: 27px;
	text-align: center;
}

.order__total_recounted .order__total_info-text {
	font-size: 12px;
	line-height: 15px;
	margin-bottom: 20px;
}

.order__total_recounted .order__total_info-text_with-icon {
	position: relative;
}

.order__total_recounted .order__total_info-text_with-icon::before {
	content: '';
	background: url("/templates/lifesport/local/templates/lundenilona/static/img/general/icons/alert.svg") center no-repeat;
	position: absolute;
	top: -8px;
	left: -44px;
	width: 33px;
	height: 33px;
	border-radius: 50%;
}

.order__total_recounted .cart-total {
	width: 260px;
	border-top: 1px solid #c8cbcd;
	padding-top: 28px;
	margin: auto;
}

.order__total_recounted .cart-total__btns {
	display: flex;
	justify-content: space-between;
}

.order__total_recounted .cart-total__btns .cart-total__submit {
	padding: 10px 15px;
	font-size: 12px;
	white-space: nowrap;
}

.order__total_recounted .cart-total__submit_basket {
	display: block;
	margin-right: 5px;
}

.order__delivery_interval_balloon {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 100%;
}

.order__interval {
	display: flex;
	justify-content: space-between;
	width: 312px;
}

.order__interval .select,
.order__interval .input,
.order__interval .input__input {
	width: 100px;
	height: 30px;
	min-height: 30px;
}

.order__interval .select,
.order__interval .input {
	margin-left: 8px;
}

.order__interval .order__input {
	width: 49%;
	display: flex;
	align-items: center;
	font-size: 13px;
	line-height: 20px;
}

.order__interval .input__input {
	padding: 0 15px;
}

.order__interval .input__input,
.order__interval .select__current {
	box-sizing: border-box;
	border: 1px solid #aaaaaa;
}

.order__interval .input_error .input__input {
	border-color: #b2001a;
}

.order__interval .select__item {
	padding: 0 10px;
	white-space: nowrap;
}

.order__interval .select__item:hover {
	color: #32373e;
	background-color: #f3f3f3;
}

.order__interval .input__input,
.order__interval .select__current,
.order__interval .select__label,
.order__interval .select__item {
	font-size: 13px;
	line-height: 30px;
}

.order__time .v-select {
	margin-top: 0;
}

.order__time .v-select .open-indicator {
	white-space: nowrap;
	padding-left: 17px;
}

.order__time .v-select .open-indicator:after {
	position: absolute;
	content: '';
	background-image: none;
	border: 3px solid transparent;
	border-top: 6px solid #000;
	right: auto;
	left: 6px;
	width: auto;
	height: auto;
	margin-top: -2px;
	top: 50%;
}

.order__time .v-select .open-indicator:before {
	content: none;
}

.order__time .v-select .dropdown-toggle {
	border: 0;
	padding: 0;
	cursor: pointer;
	position: relative;
	padding-left: 17px;
	height: 30px;
	width: 100px;
}

.order__time .v-select .vs__selected-options {
	min-width: 100%;
}

.order__time.select__current:after {
	content: none;
}

.order__time .dropdown {
	position: relative;
	width: 100px;
}

.order__time .dropdown .dropdown-menu {
	top: 29px;
	left: -1px;
	border: 1px solid #aaaaaa !important;
	margin-top: -1px;
	padding: 0;
	position: absolute;
	width: auto;
	box-sizing: border-box;
	background-color: #fff;
	z-index: 10000;
	opacity: 1;
	transition: 0.3s;
	min-width: 100px;
	overflow: hidden;
	text-align: center;
}

.order__time .dropdown .dropdown-menu li {
	height: 30px !important;
	width: 100px;
}

.order__time .dropdown .dropdown-menu li a {
	height: 30px !important;
	color: #32373e !important;
	width: 100px;
	padding: 0px !important;
	white-space: nowrap;
	font-size: 13px;
	line-height: 30px;
}

.order__time .dropdown .dropdown-menu li.highlight a {
	background-color: #f3f3f3 !important;
}

.order__time .dropdown .dropdown-menu li.active a {
	background: rgba(50, 50, 50, 0.1);
}

@media (min-width:768px) {
	.order__input_radio {
		margin-bottom: 10px;
	}

	.order__part_paytype {
		min-height: 127px;
	}

	.order__need-prepayment {
		display: flex;
		flex-direction: column;
	}

	.order__total_recounted {
		margin: 0;
	}

	.order__total_recounted .cart-total {
		width: 100%;
	}

	.order__total_recounted .cart-total__btns {
		justify-content: flex-end;
	}

	.order .order__agreement {
		font-size: 12px;
		margin-top: 36px;
	}

	.order__paytype {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
	}

	.order__paytype .order__input {
		display: flex;
		align-items: center;
		width: 100%;
	}
}

@media (min-width:1260px) {
	.order {
		position: relative;
	}

	.order__form {
		display: flex;
		justify-content: space-between;
	}

	.order__input {
		margin-bottom: 15px;
		width: 428px;
	}

	.order__input_radio {
		margin-bottom: 16px;
		width: auto;
	}

	.order__input_radio+.order__input_radio {
		margin-left: 16px;
	}

	.order__delivery {
		margin-bottom: 24px;
	}

	.order__delivery .order__input_radio+.order__input_radio {
		margin-left: 0;
	}

	.order__part_paytype {
		min-height: 100%;
		flex-direction: row;
		margin-bottom: 24px;
	}

	.order__part_paytype .order__input_radio {
		min-width: 100px;
		max-width: 150px;
		margin-bottom: 0;
		padding: 0 5px;
	}

	.order__part_paytype .order__input_radio .input_radio {
		text-align: center;
	}

	.order__part_paytype .order__input_radio-active {
		padding: 0 5px;
		margin: 0 -5px;
	}

	.order__input-sms {
		flex-direction: row;
	}

	.order__input-sms .input {
		width: 192px;
	}

	.order__input-sms_success .input__input {
		background-position: 165px;
	}

	.order__input-sms .input__error {
		top: 55px;
	}

	.order__paytype-cash {
		display: flex;
		align-items: center;
		height: 100%;
	}

	.order__paytype-cash .input__label {
		background-position: 10px;
	}

	.order__paytype-cash:hover .input__label,
	.order__paytype-cash.order__input_radio-active .input__label {
		background-position: 10px;
	}

	.order__confirm-tel {
		width: 240px;
		margin-left: 8px;
		margin-bottom: 0;
	}

	.order__need-prepayment,
	.order__need-prepayment a,
	.order__possible_delay,
	.order__delivery_text,
	.order__agreement,
	.order__agreement a {
		width: 377px;
		text-align: right;
	}

	.order__total_recounted {
		width: 415px;
		align-self: flex-start;
		padding: 50px 24px 34px;
	}

	.order__total_recounted .order__total_info {
		padding: 0 8px 17px 25px;
	}

	.order__total_recounted .order__total_info-title {
		font-size: 20px;
		margin-bottom: 38px;
		margin-left: -17px;
	}

	.order__total_recounted .order__total_info-text {
		font-size: 16px;
		line-height: 21px;
		margin-bottom: 25px;
	}

	.order__total_recounted .order__total_info-text_with-icon::before {
		left: -40px;
	}

	.order__total_recounted .cart-total {
		width: 355px;
		padding-top: 40px;
	}

	.order__total_recounted .cart-total__btns .cart-total__submit {
		padding: 10px 20px;
		font-size: 16px;
	}

	.order__total_recounted .cart-total__submit_basket {
		margin-right: 8px;
	}

	.order__total_recounted .cart-total__submit_basket a {
		text-decoration: none;
		color: inherit;
	}

	.order__total_recounted .order__agreement {
		width: 360px;
	}
}


#SDEK_delivInfo_PVZ {
	display: none !important;
}

#SDEK_wrapper {
	height: 440px !important;
}

.datepicker__order {
	margin-left: -40px;
	margin-top: 20px;
	width: 313px;
}

.datepicker__order .datepicker--day-name {
	color: #515152;
}

.order-entity__fieldset {
	border: none;
	margin: 0;
	padding: 0;
}

.order-entity__input {
	margin-bottom: 30px;
}

.order-entity__agreement,
.order-entity__agreement a {
	font-size: 13px;
	line-height: 18px;
	color: #7B8084;
}


.order .order__agreement {
	font-size: 12px;
	margin-top: 36px;
}

.carskid {
	padding-bottom: 20px;
	overflow: hidden;
	position: relative;
	width: 100%;
}


.filtr-rinok-desc table {
	border: 0;
	margin-top: 10px;
}

.filtr-rinok-desc table tr:first-child strong {
	font-size: 17px
}

.filtr-rinok-desc table tr:nth-child(odd) {
	background-color: #fafafa
}

.filtr-rinok-desc table tr td {
	vertical-align: top;
	padding: 5px;
	border-collapse: collapse;
	border: 0;
	border: 1px solid #e0e0e0;
}


.hUNmAo {
	margin-top: 24px;
	display: flex;
	-webkit-box-align: baseline;
	align-items: baseline;
	-webkit-box-pack: justify;
	justify-content: space-between;
	margin-bottom: 20px;
}


.hiJWno {
	max-width: 100%;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.jIrUYn {
	display: inline-block;
	vertical-align: baseline;
	font-weight: 500;
	line-height: 40px;
	font-size: 30px;
	color: rgb(51, 51, 51);
}


.catfleft {
	display: inline-block;
}

.footer_svg {
	width: 32px;
	height: 32px;
	opacity: 0.7;
}

.footer_svg:hover {
	opacity: 1;
}


.footer__logo {
	width: 148px;
	opacity: 0.7;
}

.footer__logo:hover {
	opacity: 1;
}/**
* @name KYLSHOP
*/
/* Default */


@media (min-width: 1260px) {
	.order__fixed {
		position: absolute;
		top: 0;
		right: 0;
		height: 100%;
	}
	.order__total {
		margin-top: 33px;
		position: -webkit-sticky;
		position: sticky;
		top: 159px;
	}
}

.selectpay {
    text-align: center;
    font-weight: bold;
}



.show_addon_goods{
	display:none!important;
}
.flex{
	display:flex;
	flex-wrap:wrap;
	justify-content:space-between;
}
.w50{
	width:50%;
}
.vc{ align-items:center; }
.tc{ text-align:center; }
.jcl{ justify-content:flex-start; }

/* ======= */


.ks_dinamic_count{
	background:  var(--color-primary-p3-light);
    width: 20px;
    height: 20px;
    padding-top: 2px;
    text-align: center;
    border-radius: 50px;
    color: #fff;
    position: absolute;
    top: -10px;
    left: -10px;
    font-size: 12px;
    font-weight: bold;
}


.bg_0{
	background:rgba(0,0,0,0.5);
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9990;
	display:none;
}

#ks_goods{
	background:rgba(16, 51, 80, 0.71);
	width:700px;
	max-height:80vh;
	color:#fff;
	position:fixed;
	top:5%;
	left:50%;
	letter-spacing:0.5px;
	overflow-y:auto;
	margin-left:-350px;
	z-index:99999;
	display:none;
}
.ks_total_cart{
	float:right;
	margin:7px 10px 0 0;
}
#dle-content .ks_total_cart{
	font-family:OpenSans,sans-serif;
	    margin: 7px 0px;
	text-align:right;
	font-size:16px;
}
/*.total_without_method{
	display:none;
}*/
#dle-content .ks_total_cart b{
	font-family:'Cochin-Bold', serif;
	color:#000000;
	font-size:18px;
}
.total_without_method b{
	color:#000000;
	font-size:21px;
}
#ks_goods table, .cart_table{
	width:100%;
	color:#000;
	border-collapse:collapse;
}
.cart_table_min{
	background:#fff;
}

.goods_link{
	text-decoration:none !important;
}

#ks_goods table th, #ks_goods table td, .cart_table th, .cart_table td{
	background:#fff;
	padding:5px 10px;
	border-bottom:1px solid #eaecec;
	position:relative;
}
#ks_goods table th, .cart_table th{
	font-family:OpenSans,sans-serif;
	font-weight:normal;
	font-size:18px;
	color:#32373E;
	padding:10px;
}
#ks_goods table th:first-child{
	text-align:left;
}
#ks_goods table img, .cart_table img{
	max-width:100px;
	max-height:120px;
}
.cart_table_min .jcl span, .cart_table .jcl span{
	width:calc(100% - 120px);
}

.ks_take_count, .ks_add_count{
	/* border-bottom:1px solid #7b8084;
	border-left:1px solid #7b8084;
	border-top:1px solid #7b8084; */
	background:#ffffff;
	display:block;
	width:35px;
	height:30px;
	margin-right:0px;
	line-height:26px;
	text-align:center;
	font-size:18px;
	font-weight:bold;
	color:#7b8084;
	text-decoration:none!important;
}
/* .ks_add_count{
	border-bottom:1px solid #7b8084;
	border-right:1px solid #7b8084;
	border-left:1px solid #ffffff;
	border-top:1px solid #7b8084;
	background:#ffffff;
	line-height:26px;
	font-size:18px;
	margin:0!important;
} */
/* .ks_take_count:hover{background:#ffbc45;}
.ks_add_count:hover{background:#57d000;} */

.ks_count_goods{
	border-bottom:0px solid #7b8084;
	border-top:0px solid #7b8084;
	border-right:1px solid #ffffff;
	border-left:1px solid #ffffff;
	width:35px;
	height:30px;
	line-height:normal !important;
	padding:0px 5px !important;
	text-align:center;
}

.ks_delete_goods{
	background:url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDk1LjkzOSA5NS45MzkiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDk1LjkzOSA5NS45Mzk7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8cGF0aCBkPSJNNjIuODE5LDQ3Ljk3bDMyLjUzMy0zMi41MzRjMC43ODEtMC43ODEsMC43ODEtMi4wNDcsMC0yLjgyOEw4My4zMzMsMC41ODZDODIuOTU4LDAuMjExLDgyLjQ0OCwwLDgxLjkxOSwwICAgYy0wLjUzLDAtMS4wMzksMC4yMTEtMS40MTQsMC41ODZMNDcuOTcsMzMuMTIxTDE1LjQzNSwwLjU4NmMtMC43NS0wLjc1LTIuMDc4LTAuNzUtMi44MjgsMEwwLjU4NywxMi42MDggICBjLTAuNzgxLDAuNzgxLTAuNzgxLDIuMDQ3LDAsMi44MjhMMzMuMTIxLDQ3Ljk3TDAuNTg3LDgwLjUwNGMtMC43ODEsMC43ODEtMC43ODEsMi4wNDcsMCwyLjgyOGwxMi4wMiwxMi4wMjEgICBjMC4zNzUsMC4zNzUsMC44ODQsMC41ODYsMS40MTQsMC41ODZjMC41MywwLDEuMDM5LTAuMjExLDEuNDE0LTAuNTg2TDQ3Ljk3LDYyLjgxOGwzMi41MzUsMzIuNTM1ICAgYzAuMzc1LDAuMzc1LDAuODg0LDAuNTg2LDEuNDE0LDAuNTg2YzAuNTI5LDAsMS4wMzktMC4yMTEsMS40MTQtMC41ODZsMTIuMDItMTIuMDIxYzAuNzgxLTAuNzgxLDAuNzgxLTIuMDQ4LDAtMi44MjhMNjIuODE5LDQ3Ljk3ICAgeiIgZmlsbD0iI0Q4MDAyNyIvPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=) no-repeat;
	background-size:16px;
	width:16px;
	height:16px;
	display:inline-block;
	opacity:0.5;
}
.ks_delete_goods:hover{
	opacity:1;
}

.goods_title{
	margin-left:10px;
	color:#525d66;
}

#ks_goods .close{
	background:url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIxLjkgMjEuOSIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAwIDAgMjEuOSAyMS45IiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KICA8cGF0aCBkPSJNMTQuMSwxMS4zYy0wLjItMC4yLTAuMi0wLjUsMC0wLjdsNy41LTcuNWMwLjItMC4yLDAuMy0wLjUsMC4zLTAuN3MtMC4xLTAuNS0wLjMtMC43bC0xLjQtMS40QzIwLDAuMSwxOS43LDAsMTkuNSwwICBjLTAuMywwLTAuNSwwLjEtMC43LDAuM2wtNy41LDcuNWMtMC4yLDAuMi0wLjUsMC4yLTAuNywwTDMuMSwwLjNDMi45LDAuMSwyLjYsMCwyLjQsMFMxLjksMC4xLDEuNywwLjNMMC4zLDEuN0MwLjEsMS45LDAsMi4yLDAsMi40ICBzMC4xLDAuNSwwLjMsMC43bDcuNSw3LjVjMC4yLDAuMiwwLjIsMC41LDAsMC43bC03LjUsNy41QzAuMSwxOSwwLDE5LjMsMCwxOS41czAuMSwwLjUsMC4zLDAuN2wxLjQsMS40YzAuMiwwLjIsMC41LDAuMywwLjcsMC4zICBzMC41LTAuMSwwLjctMC4zbDcuNS03LjVjMC4yLTAuMiwwLjUtMC4yLDAuNywwbDcuNSw3LjVjMC4yLDAuMiwwLjUsMC4zLDAuNywwLjNzMC41LTAuMSwwLjctMC4zbDEuNC0xLjRjMC4yLTAuMiwwLjMtMC41LDAuMy0wLjcgIHMtMC4xLTAuNS0wLjMtMC43TDE0LjEsMTEuM3oiIGZpbGw9IiNGRkZGRkYiLz4KPC9zdmc+Cg==) no-repeat center center;
	background-size:16px;
	width:16px;
	height:16px;
	position:absolute;
	top:14px;
	right:11px;
	transition:0.2s;
	transform:scale(0.7);
}
#ks_goods .close:hover{
	transform:scale(1);
}






.sort-torg .add_to_cart {
    position: absolute;
    width: 36px;
    height: 36px;
    right: 0;
    top: 0px;
    background:  var(--color-primary-p3-dark);
    -webkit-border-bottom-left-radius: 12px;
    -webkit-border-top-right-radius: 12px;
    border-bottom-left-radius: 12px;
    border-top-right-radius: 12px;
    z-index: 7;
    font-size: 0px;
}




.sort-torg .active_goods{
    background:  var(--color-primary-p3-dark);
}


.sort-torg .add_to_cart span {
  width: auto;
  height: auto;
}
.sort-torg .add_to_cart span:after {content:"";position:absolute;speak:never;line-height:1;width:24px;height:24px;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='white' width='24' height='24'%3E%3Cpath d='M18 13h-5v5c0 .55-.45 1-1 1h0c-.55 0-1-.45-1-1v-5H6c-.55 0-1-.45-1-1h0c0-.55.45-1 1-1h5V6c0-.55.45-1 1-1h0c.55 0 1 .45 1 1v5h5c.55 0 1 .45 1 1h0c0 .55-.45 1-1 1z'/%3E%3C/svg%3E");right:6px;bottom:6px}


 

.float-price-not .go_add_tg {
    color: #2196f3;
    font-weight: bold;
	font-size: 16px;
}











.sc-fzqPZZ .go_add_tg {
    display: block;
    height: 40px;
    padding: 4px 20px;
    border-radius: 4px;
    position: relative;
    font-size: 14px;
    word-wrap: break-word;
    color: #2196f3;
    font-weight: bold;
    background: rgb(255 255 255);
    border: 2px solid #2196f3;
    cursor: pointer;
    text-align: center;
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
    text-transform: uppercase;
    text-decoration: none !important;
}


.sc-fzqPZZ .go_add_tg:hover {
    color: #fff;
    background: #2196f3;
}

.sc-fzqPZZ .go_add_tg:hover p {
color: #ffe243;
}


.sc-fzqPZZ .go_add_tg p {
	font-size: 10px;
    margin-top: -3px;
    color: #f44336;
}





.sc-fzqPZZ .add_to_cart, .go_to_cart{
    display: block;
    height: 40px;
    padding: 12px 20px;
    font-weight: 500;
    border-radius: 4px;
    position: relative;
    color: #fff;
    font-size: 16px;
	background:  var(--color-primary-p3);
    word-wrap: break-word;
    cursor: pointer;
    text-align: center;
    box-shadow: rgb(0 0 0 / 4%) 0px 2px 4px 0px;
    font-size: 18px;
    text-transform: uppercase;
	top: 8px;
    text-decoration: none !important;
}
.sc-fzqPZZ .active_goods{
    background: var(--color-primary-p3-light);
}

.sc-fzqPZZ .active_goods:hover {  background: var(--color-primary-p3-light) !important;}



.sc-fzqPZZ .active_goods span{
    font-size: 12px;
    color: #fff;
}

.sc-fzqPZZ .add_to_cart:hover{
	background: var(--color-primary-p3-light);
	color:#fff;
}

.sc-fzqPZZ .go_to_cart:hover{
	background:rgba(0, 0, 0, 0);
	color:#525d66;
}

/* .active_goods{
	background:#5bb31b;
}
.active_goods span{
	font-size:12px;
	color:#d4ffb4;
} */

.order_kylshop, .clear_cart{
	background:#5BB31B;
	color:#fff;
	display:inline-block;
	padding:8px 17px;
	text-decoration:none !important;
	transition:0.2s;
}
.clear_cart{
	background:#041e33;
	color:#b4cbde;
	font-size:13px;
	margin-left:-5px;
}
.order_kylshop:hover{ background:#44920c; }
.clear_cart:hover{ background:#de3d2b; color:#fff; }

/*#ks_payment{
	border:1px solid #525d66;
	text-transform:uppercase;
	font-family:'Cochin', serif;
	background:#525d66;
	padding:15px 20px;
	text-align:center;
	transition:0.2s;
	margin:15px 0;
	font-size:16px;
	cursor:pointer;
	border:none;
	float:right;
	color:#fff;
}
#ks_payment:hover{
	border:1px solid #525d66;
	background:#fff;
	color:#525d66;
}*/
#cart_full{
	margin-bottom:30px;
	width:100%;
}
#ks_form{
	width:auto;
}
/*#ks_form input[type="text"], #ks_form input[type="email"], #ks_form select, #ks_form textarea{
	width:calc(100% - 22px);
	padding:7px 10px;
	border:1px #ccc solid;
}
#ks_form select{
	width:100%;
}
#ks_form textarea{
	min-height:100px;
}
#ks_form .ks_field label{
	display:block;
}
#ks_form .ks_field{
	display:block;
	clear:both;
	margin-bottom:15px;
}*/
.nlb label{
	display:inline-block !important;
}

.on_moder{
	background:#f68b1a;
	padding:7px 10px;
	color:#fff;
	display:inline-block;
	margin:10px 0;
}

#payments{
	display:flex;
	flex-wrap:wrap;
	justify-content:center;
	width:100%;
	margin:30px 0;
}
#payments > div{
	margin:0 auto 15px;
	padding:0 15px;
	text-align:center;
	width: 33%;
}

#payments .product-thumb {height: 185px !important;}

#payments .product-thumb .image {height: 120px;}


.payment_img{
	max-width:200px;
	max-height:65px;
	display:block;
	margin:0 auto 15px;
}
.payment_btn{
	background:#0078ac;
	color:#fff;
	width:100% !important;
	border-radius: 8px;
	margin:0 auto;
	display:inline-block;
	text-align:center;
	padding:10px 20px;
	border:none !important;
	text-decoration:none !important;
	cursor:pointer;
	transition:0.2s;
}
.payment_btn:hover{
	background:#000;
}




/* Scroll */
.scroll::-webkit-scrollbar-button {
	width:4px;
	height:0px
}
.scroll::-webkit-scrollbar-track {
	background-color:#32312e;
	box-shadow:0px 0px 3px #000 inset;
}
.scroll::-webkit-scrollbar-thumb {
	-webkit-border-radius:5px;
	border-radius:5px;
	background:#586b80 url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjkgMTI5IiBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCAxMjkgMTI5IiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KICA8Zz4KICAgIDxnPgogICAgICA8cGF0aCBkPSJtOTEuNCwzMy41aC01My44Yy0yLjMsMC00LjEsMS44LTQuMSw0LjEgMCwyLjMgMS44LDQuMSA0LjEsNC4xaDUzLjljMi4zLDAgNC4xLTEuOCA0LjEtNC4xLTAuMS0yLjMtMS45LTQuMS00LjItNC4xeiIgZmlsbD0iI0ZGRkZGRiIvPgogICAgICA8cGF0aCBkPSJtOTEuNCw4Ny40aC01My44Yy0yLjMsMC00LjEsMS44LTQuMSw0LjEgMCwyLjMgMS44LDQuMSA0LjEsNC4xaDUzLjljMi4zLDAgNC4xLTEuOCA0LjEtNC4xLTAuMS0yLjMtMS45LTQuMS00LjItNC4xeiIgZmlsbD0iI0ZGRkZGRiIvPgogICAgICA8cGF0aCBkPSJtOTEuNCw2MC40aC01My44Yy0yLjMsMC00LjEsMS44LTQuMSw0LjEgMCwyLjMgMS44LDQuMSA0LjEsNC4xaDUzLjljMi4zLDAgNC4xLTEuOCA0LjEtNC4xLTAuMS0yLjMtMS45LTQuMS00LjItNC4xeiIgZmlsbD0iI0ZGRkZGRiIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+Cg==) no-repeat center center;
}
.scroll::-webkit-resizer{
	background:none;
	width:4px;
	height:0px
}
.scroll::-webkit-scrollbar{
	width:5px;
}
/* Scroll END */


.is_goods{
	border:2px #3394e6 solid;
	padding:5px 15px;
	margin:15px 0;
	display:none;
}
#count_goods{
	margin:15px 0;
}
.is_goods input[type="text"], .is_goods select{
	height:auto;
	padding:5px;
}
.is_goods textarea{
	width:calc(100% - 15px);
	clear:both;
}
.is_goods .flex{
	margin:10px 0;
	justify-content:flex-start;
}
.is_goods > .flex > label{
	font-weight:bold;
	width:130px;
}
.pad_min{
	margin-left:10px;
}
#ks_sale_type{
	width:100px;
}
.ks_right_box{
	width:calc(100% - 130px);
}
.is_goods .description_min{
	font-size:12px;
	color:#9e9e9e;
	margin:5px 0;
}
#source_title{
	display:inline-block;
	margin:10px 0 0 10px;
	text-decoration:none !important;
}
#source_title:hover{
	color:#0a68b4;
}

.w33{
	width:calc(33.3% - 40px);
	margin:10px 20px 10px;
}

#filter{
	background:#f6f6f6;
	border:1px #dddddd solid;
	padding:15px;
	border-radius:2px;
	display:none;
}

#filter .w33 > label{
	font-weight:600;
	margin-bottom:10px;
}

#filter ul{
	padding-left:0;
}
#filter li{
	list-style:none;
}

#filter .border-teal-600{
	border-color:#f6f6f6;
}

.filter_short, .filter_full{
	padding:0;
	display:inline-block;
}
.filter_short ul, .filter_full ul{
	display:inline-block;
	padding:0;
	margin:0 5px 0 0 !important;
}
.filter_short p, .filter_full p{
	color:#778890;
	padding:0 5px;
	font-size:12px;
	font-weight:600;
	letter-spacing:0.5px;
	display:inline-block;
	border-radius:2px;
}
.filter_short li, .filter_full li{
	display:inline-block;
}
.filter_short > li li, .filter_full > li li{
	background:#edf1f3;
	color:#4e6169;
	border:1px #d0dde2 solid;
	padding:1px 5px;
	display:inline-block;
	font-size:12px;
	margin-right:5px;
	border-radius:2px;
	cursor:pointer;
}
.filter_short > li li.active, .filter_full > li li.active{
	background:#4e6169;
	color:#fff;
	border:1px #4e6169 solid;
}

#ks_filter{
	background:#fff;
	padding:10px;
	border-radius:2px;
	position:relative;
}
#dle-content{ 
}
#clear_filter{
	background:#8b989e;
	color:#fff;
	border:none;
	text-decoration:none;
	padding:3px 10px;
	font-size:13px;
	margin:10px 0 0;
	border-radius:2px;
	display:inline-block;
}

.bg_00{
	background:rgba(255,255,255,0.9);
	width:100%;
	height:100%;
	position:absolute;
	top:0;
	left:0;
	z-index:100;
	display:none;
}
.la-fire,
.la-fire > div {
	position:relative;
	-webkit-box-sizing:border-box;
	-moz-box-sizing:border-box;
	box-sizing:border-box;
}
.la-fire {
	display:none;
	font-size:0;
	color:#7b99b37a;
	position:absolute;
	top:50%;
	left:50%;
	margin-left:-15px;
	z-index:1000;
}
.la-fire.la-dark {
	color:#333;
}
.la-fire > div {
	display:inline-block;
	float:none;
	background-color:currentColor;
	border:0 solid currentColor;
}
.la-fire {
	width:30px;
	height:30px;
}
.la-fire > div {
	position:absolute;
	bottom:0;
	left:50%;
	width:30px;
	height:30px;
	border-radius:0;
	border-radius:2px;
	-webkit-transform:translateY(0) translateX(-50%) rotate(45deg) scale(0);
	-moz-transform:translateY(0) translateX(-50%) rotate(45deg) scale(0);
	-ms-transform:translateY(0) translateX(-50%) rotate(45deg) scale(0);
	-o-transform:translateY(0) translateX(-50%) rotate(45deg) scale(0);
	transform:translateY(0) translateX(-50%) rotate(45deg) scale(0);
	-webkit-animation:fire-diamonds 1.5s infinite linear;
	-moz-animation:fire-diamonds 1.5s infinite linear;
	-o-animation:fire-diamonds 1.5s infinite linear;
	animation:fire-diamonds 1.5s infinite linear;
}
.la-fire > div:nth-child(1) {
	-webkit-animation-delay:-.85s;
	-moz-animation-delay:-.85s;
	-o-animation-delay:-.85s;
	animation-delay:-.85s;
}
.la-fire > div:nth-child(2) {
	-webkit-animation-delay:-1.85s;
	-moz-animation-delay:-1.85s;
	-o-animation-delay:-1.85s;
	animation-delay:-1.85s;
}
.la-fire > div:nth-child(3) {
	-webkit-animation-delay:-2.85s;
	-moz-animation-delay:-2.85s;
	-o-animation-delay:-2.85s;
	animation-delay:-2.85s;
}
.la-fire.la-sm {
	width:16px;
	height:16px;
}
.la-fire.la-sm > div {
	width:6px;
	height:6px;
}
.la-fire.la-2x {
	width:64px;
	height:64px;
}
.la-fire.la-2x > div {
	width:24px;
	height:24px;
}
.la-fire.la-3x {
	width:96px;
	height:96px;
}
.la-fire.la-3x > div {
	width:36px;
	height:36px;
}
/*
 * Animation
 */
@-webkit-keyframes fire-diamonds {
	0% {
		-webkit-transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
	}
	50% {
		-webkit-transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
		transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
	}
	100% {
		-webkit-transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
	}
}
@-moz-keyframes fire-diamonds {
	0% {
		-moz-transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
	}
	50% {
		-moz-transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
		transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
	}
	100% {
		-moz-transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
	}
}
@-o-keyframes fire-diamonds {
	0% {
		-o-transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
	}
	50% {
		-o-transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
		transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
	}
	100% {
		-o-transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
	}
}
@keyframes fire-diamonds {
	0% {
		-webkit-transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
		-moz-transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
		-o-transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(75%) translateX(-50%) rotate(45deg) scale(0);
	}
	50% {
		-webkit-transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
		-moz-transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
		-o-transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
		transform:translateY(-87.5%) translateX(-50%) rotate(45deg) scale(1);
	}
	100% {
		-webkit-transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
		-moz-transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
		-o-transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
		transform:translateY(-212.5%) translateX(-50%) rotate(45deg) scale(0);
	}
}
.load-bar {
	position:absolute;
	width:100%;
	height:5px;
	top:0;
	left:50%;
	margin-left:-50%;
	z-index:1000;
	background-color:#fdba2c;
}
.bar {
	content:"";
	display:inline;
	position:absolute;
	width:0;
	height:100%;
	left:50%;
	text-align:center;
}
.bar:nth-child(1) {
	background-color:#da4733;
	animation:loading 3s linear infinite;
}
.bar:nth-child(2) {
	background-color:#3b78e7;
	animation:loading 3s linear 1s infinite;
}
.bar:nth-child(3) {
	background-color:#fdba2c;
	animation:loading 3s linear 2s infinite;
}


#ks_filter li{
	list-style:none;
}
#ks_filter > ul > li{
	margin-bottom:10px;
}
#ks_filter p{
	font-weight:bold;
}
#ks_filter ul{
	padding:5px 0 0 10px !important;
	margin:0 !important;
}
#ks_filter_price{
	margin:5px 5px 25px;
}
.ks_filter_price, .ks_filter_slider_box{
	margin:10px 5px 0;
}
.ks_filter_price .ks_filter_to, .ks_filter_slider_box .ks_slider_to{
	float:right;
}

.price_show{
	font-weight:bold;
	color:#4ca20d;
	font-size:21px;
	margin:5px 0;
}

.ks_sale{
	font-size:16px;
	color:#e23535;
}

#ks_map{
	height:470px;
}

.cart_title{
	width:100%;
}
.redirect_payments{
	text-align:center;
	display:block;
	width:100%;
	margin:50px 0;
	color:#1db31b;
	font-size:17px;
	font-weight:500;
}

.map_cart{
	width:calc(100% - 500px);
	height:570px;
}

#cart_full .map_cart{
	display:none;
}

#cart_full .map_cart #ks_map{
	border:1px #ccc solid;
}

.title_over_map{
	background:#ce2222;
	color:#fff;
	font-weight:400;
	padding:5px 10px;
	font-size:14px;
}

.select_delivery{
	background:#10b5da;
	color:#fff;
	text-decoration:none;
	display:inline-block;
	clear:both;
	padding:3px 10px;
	margin-top:10px;
	border-radius:2px;
	transition:0.2s;
}
.select_delivery:hover{
	background:#0f3d58;
}

.img_map{
	display:inline-block;
	margin:5px 5px 5px 0;
}
.img_map img{
	max-width:250px;
	max-height:250px;
}

.checked_location{
	background:url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTcuMS4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDE5MS42NjcgMTkxLjY2NyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMTkxLjY2NyAxOTEuNjY3OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCI+CjxwYXRoIGQ9Ik05NS44MzMsMEM0Mi45OTEsMCwwLDQyLjk5LDAsOTUuODMzczQyLjk5MSw5NS44MzQsOTUuODMzLDk1LjgzNHM5NS44MzMtNDIuOTkxLDk1LjgzMy05NS44MzRTMTQ4LjY3NiwwLDk1LjgzMywweiAgIE0xNTAuODYyLDc5LjY0NmwtNjAuMjA3LDYwLjIwN2MtMi41NiwyLjU2LTUuOTYzLDMuOTY5LTkuNTgzLDMuOTY5Yy0zLjYyLDAtNy4wMjMtMS40MDktOS41ODMtMy45NjlsLTMwLjY4NS0zMC42ODUgIGMtMi41Ni0yLjU2LTMuOTctNS45NjMtMy45Ny05LjU4M2MwLTMuNjIxLDEuNDEtNy4wMjQsMy45Ny05LjU4NGMyLjU1OS0yLjU2LDUuOTYyLTMuOTcsOS41ODMtMy45N2MzLjYyLDAsNy4wMjQsMS40MSw5LjU4MywzLjk3MSAgbDIxLjEwMSwyMS4xbDUwLjYyMy01MC42MjNjMi41Ni0yLjU2LDUuOTYzLTMuOTY5LDkuNTgzLTMuOTY5YzMuNjIsMCw3LjAyMywxLjQwOSw5LjU4MywzLjk2OSAgQzE1Ni4xNDYsNjUuNzY1LDE1Ni4xNDYsNzQuMzYyLDE1MC44NjIsNzkuNjQ2eiIgZmlsbD0iIzMxYjExMiIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K) no-repeat left 0;
	color:#31b112;
	font-weight:500;
	display:inline-block;
	margin-left:10px;
	padding:1px 0 2px 21px;
}

.is_location_selected{
	color:#0a68b4;
	font-style:italic;
	margin:5px 0;
}

.delivery_city{
	margin-top:15px;
}

.total_width_delivery p{
	font-size:19px;
}
.total_width_delivery p b{
	color:#4eab0a;
}
.delivery_method_container{
	padding:10px;
}

.table_goods{
	background:#fff;
	width:100%;
	margin:20px 0;
	border-collapse:collapse;
}
.table_goods th, .table_goods td{
	padding:10px;
	text-align:center;
}
.table_goods th{
	background:#ffffff;
	color:#525d66;
	font-weight:400;
}
.table_goods td{
	border-bottom:1px #e8eff5 solid;
}
.table_goods td a{
	color:#525d66;
	display:inline-block;
	display:flex;
	align-items:center;
}
.table_goods td a:hover{
	color:#41af16;
}

.img_g{
	display:inline-block;
	width:50px;
	margin-right:10px;
}

.status_1{
	background:#92c73c;
	color:#fff !important;
}
.status_2{
	background:#f7a407;
	color:#fff !important;
}
.status_3{
	background:#00abff;
	color:#fff !important;
}

/*.method_total{
	display:none;
}*/
.sale_empty{
	color:#e24f4f !important;
}
#promo_code{
    background: #fff;
    border-bottom: 1px solid #7b8084;
    border-right: 1px solid #fff;
    border-left: 1px solid #fff;
    border-top: 1px solid #fff;
    -webkit-appearance: none;
    line-height: 35px;
    min-height: 35px;
    border-radius: 0;
    color: #32373e;
    font-size: 16px;
    outline: none;
    resize: none;
    width: 70%;
    padding: 0;
    float: left;
}
#apply_promo_code{
    border: 1px solid #7b8084;
    text-transform: uppercase;
    text-decoration: none;
    display: inline-block;
    border-radius: 8px;
    padding: 8px 8px;
    color: #7b8084;
    font-size: 14px;
}
#apply_promo_code:hover{
	background:#415260;
	color:#ffffff;
}
.carskid .without_sale{
	margin-bottom:10px;
	position:absolute;
	overflow:hidden;
	text-align:right;
	display:block;
	margin:5px 0;
	top:35px;
	float:left;
}
.without_sale span{
	color:#a2a2a2;
}
.total_with_sale{
	font-size:17px;
	color:#4eab0a;
}

.present{
	background:#ea4949;
	color:#fff;
	font-size:12px;
	display:inline-block;
	padding:0 5px;
}
.one_plus_one{
	background:#5bb31b;
	height:14px;
	line-height:15px;
	color:#ffffff;
	font-size:11px;
	display:inline-block;
	text-align:center;
	width:calc(100% - 6px);
	padding:1px 3px;
	position:absolute;
	bottom:-1px;
	left:0;
}
.with_pickup_sale{
	display:inline-block;
	margin:10px 0 5px;
}
.with_pickup_sale b{
	color:#4eab0a;
	font-size:17px;
}

.show_addon_goods{
	background:#7290b1 url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgNTMgNTMiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUzIDUzOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjUxMiIgaGVpZ2h0PSI1MTIiPjxnPjxnPgoJPGc+CgkJPHBhdGggZD0iTTIsMTMuNWg0OWMxLjEwNCwwLDItMC44OTYsMi0ycy0wLjg5Ni0yLTItMkgyYy0xLjEwNCwwLTIsMC44OTYtMiwyUzAuODk2LDEzLjUsMiwxMy41eiIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgY2xhc3M9ImFjdGl2ZS1wYXRoIiBzdHlsZT0iZmlsbDojRkZGRkZGIiBkYXRhLW9sZF9jb2xvcj0iIzAwMDAwMCI+PC9wYXRoPgoJCTxwYXRoIGQ9Ik0yLDI4LjVoNDljMS4xMDQsMCwyLTAuODk2LDItMnMtMC44OTYtMi0yLTJIMmMtMS4xMDQsMC0yLDAuODk2LTIsMlMwLjg5NiwyOC41LDIsMjguNXoiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIGNsYXNzPSJhY3RpdmUtcGF0aCIgc3R5bGU9ImZpbGw6I0ZGRkZGRiIgZGF0YS1vbGRfY29sb3I9IiMwMDAwMDAiPjwvcGF0aD4KCQk8cGF0aCBkPSJNMiw0My41aDQ5YzEuMTA0LDAsMi0wLjg5NiwyLTJzLTAuODk2LTItMi0ySDJjLTEuMTA0LDAtMiwwLjg5Ni0yLDJTMC44OTYsNDMuNSwyLDQzLjV6IiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBjbGFzcz0iYWN0aXZlLXBhdGgiIHN0eWxlPSJmaWxsOiNGRkZGRkYiIGRhdGEtb2xkX2NvbG9yPSIjMDAwMDAwIj48L3BhdGg+Cgk8L2c+CjwvZz48L2c+IDwvc3ZnPg==) no-repeat center center;
	background-size:17px;
	color:#fff;
	text-align:center;
	display:block;
	width:7px !important;
	height:17px;
	padding:3px 10px;
	border-radius:2px;
	position:absolute;
	top:15px;
	right:20px;
}
.addon_goods{
	border:1px #c0d6e8 solid !important;
	display:none;
}
.addon_goods td{
	background:#edf7ff !important;
	border:none !important;
	padding:0 10px;
}
.addon_goods td:first-child{
	position:relative;
	padding-left:53px !important;
	display:flex;
	align-items:center;
	top:0;
}
.addon_goods td:first-child:before{
	content:"";
	background:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iNTEyIiB2ZXJzaW9uPSIxLjEiIGhlaWdodD0iNTEyIiB2aWV3Qm94PSIwIDAgNjQgNjQiIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDY0IDY0IiBjbGFzcz0iIj48ZyB0cmFuc2Zvcm09Im1hdHJpeCg2LjEyMzIzZS0xNyAtMSAxIDYuMTIzMjNlLTE3IDAgNjQpIj48Zz4KICAgIDxwYXRoIGZpbGw9IiMxRDFEMUIiIGQ9Im02My4zODYsMTYuMTkzbC4wMDItLjAwMmMwLjAwMi0wLjAwMyAwLjAwNC0wLjAwNiAwLjAwNi0wLjAxIDAuMTcyLTAuMTk1IDAuMjk4LTAuNDMgMC4zOTktMC42NzggMC4wMzItMC4wNzYgMC4wNTMtMC4xNDggMC4wNzYtMC4yMjUgMC4wNTgtMC4xOTEgMC4wOTQtMC4zODkgMC4xMDYtMC41OTYgMC4wMDYtMC4wNzYgMC4wMTgtMC4xNDggMC4wMTYtMC4yMjYgMC0wLjA0IDAuMDEtMC4wNzYgMC4wMDgtMC4xMTUtMC4wMTQtMC4yMzktMC4wNjItMC40Ny0wLjEzNi0wLjY4Ny0wLjAwNi0wLjAyMy0wLjAyMi0wLjA0MS0wLjAzLTAuMDY0LTAuMDg4LTAuMjM5LTAuMjE0LTAuNDUxLTAuMzYzLTAuNjQ1LTAuMDIxLTAuMDI3LTAuMDI4LTAuMDYzLTAuMDUtMC4wOWwtMTAuMzExLTEyLjE0NmMtMC43ODktMC45My0yLjA4NC0wLjk0OC0yLjg5NC0wLjAzNy0wLjgwOCwwLjkxLTAuODIzLDIuNDAyLTAuMDMyLDMuMzM0bDUuNTU4LDYuNTQ5Yy04LjEyMS0xLjA3Ni0xNi4xMDQsMC42MzMtMTYuNDgxLDAuNzE3LTI0LjY0Niw0LjQ2Ny00Mi4wODcsMjcuMjI3LTM4Ljg4LDUwLjczNiAwLjE1OSwxLjE2NCAxLjAyOCwxLjk5MiAyLjAxOSwxLjk5MiAwLjEwNiwwIDAuMjEyLTAuMDA5IDAuMzItMC4wMjcgMS4xMTYtMC4yMDMgMS44NzgtMS40MDkgMS43MDQtMi42OTYtMi44NTctMjAuOTQgMTMuMDU2LTQxLjI4MiAzNS41MzctNDUuMzU4IDAuMTAzLTAuMDI0IDguMzUxLTEuNzk0IDE2LjExNy0wLjU3NGwtOC41NzcsNS4wOTNjLTEuMDA1LDAuNTk4LTEuMzk4LDIuMDItMC44ODEsMy4xNzcgMC41MTYsMS4xNTkgMS43NDgsMS42MDggMi43NTYsMS4wMTdsMTMuNTItOC4wMjhjMC4xODMtMC4xMTEgMC4zNDctMC4yNSAwLjQ5MS0wLjQxMXoiIGRhdGEtb3JpZ2luYWw9IiMxRDFEMUIiIGNsYXNzPSJhY3RpdmUtcGF0aCIgc3R5bGU9ImZpbGw6I0IzQjNCMyIgZGF0YS1vbGRfY29sb3I9IiMxRDFEMUIiPjwvcGF0aD4KICA8L2c+PC9nPiA8L3N2Zz4=) no-repeat;
	background-size:17px;
	width:24px;
	height:24px;
	position:absolute;
	top:15px;
	left:20px;
}

.my_price input{
	display:inline-block;
	width:100px;
	padding:7px 10px;
}

.pay_by_balance{
	padding:12.5px 0;
}
.pay_by_balance b{
	font-size:18px;
}

.no_list{
	list-style:none;
	padding:0;
	margin:0;
}
.ks_counter{
	display:inline-block;
}
.ks_counter input[type="number"]{
	width:70px;
	height:auto;
	padding:3px 7px;
	border-radius:30px;
}
[name="pay_my_balance"]{
	width:200px !important;
	height:auto;
	padding:3px 10px !important;
}


/* Media */
@media screen and (max-width:700px){
	#ks_goods{
		max-width:100%;
		top:0;
		left:0;
		margin:0 !important;
	}
}
@media screen and (max-width:490px){
	#ks_goods table img, .cart_table img{
		max-width: 100px;
    max-height: 120px;
	}
	.ks_take_count, .ks_add_count{
		margin:0px auto !important;
		width:100% !important;
	}
}

.test{
	visibility:hidden !important;
	display:none !important;
	text-indent:-99999px;
}
.opoplus {
    font-size: 15px;
}


.cart_clear .title {font-size: 22px;font-weight: 600; line-height: 1.2em; margin-top: 24px;}
.cart_clear .info {font-size: 16px; font-weight: 400; line-height: 1.4em; margin-top: 16px;}