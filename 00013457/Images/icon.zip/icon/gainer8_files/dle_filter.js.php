let dleFilter = {
	path: window.location.pathname,
	title: document.title,
	content: false,
	speedbar: false,
	reset: false,
	id: '',
	original: {},
	ajax: 0,
	lazy: 0,
	ajaxUrl: 0,
	hideLoading: 0,
	button: 0,
	jsSelect: 0,
	ajaxNav: 0,
	ajaxPage: 0,
	ajaxAnim: 0,
	ionSlider: 0,
	navApart: 0,
	filterUrl: 'filter',
	defaultUrl: '/filter/sort=date/order=desc/'
};


